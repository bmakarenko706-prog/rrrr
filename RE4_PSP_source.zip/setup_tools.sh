#!/bin/bash
# Restores the build environment after a sandbox reset (idempotent).
T=/data/tools; mkdir -p $T; cd $T
python3 -c "import capstone, elftools" 2>/dev/null || pip3 install --quiet capstone pyelftools patchelf
export PATH=$HOME/.local/bin:$PATH
which patchelf >/dev/null || pip3 install --quiet patchelf
# --- PSPSDK (pspdev) built for Debian; needs glibc >= 2.38, so use a Debian trixie sysroot
if [ ! -x $T/pspdev/bin/psp-gcc ]; then
  [ -f pspdev-debian.tar.gz ] || curl -sL -o pspdev-debian.tar.gz https://github.com/pspdev/pspdev/releases/download/v20261101/pspdev-debian-latest.tar.gz
  tar xzf pspdev-debian.tar.gz
fi
SR=$T/sysroot/usr/lib/x86_64-linux-gnu
if [ ! -f $SR/libc.so.6 ]; then
  mkdir -p debs sysroot && cd debs
  curl -sL -o Packages.xz https://deb.debian.org/debian/dists/trixie/main/binary-amd64/Packages.xz && xz -dkf Packages.xz
  python3 - <<'PY'
want = {'libc6','libstdc++6','libgcc-s1','libzstd1','libgmp10','libmpfr6','libmpc3','zlib1g'}
pk = {}; cur = {}
for line in open('Packages', encoding='utf-8', errors='replace'):
    line = line.rstrip('\n')
    if not line:
        if cur.get('Package') in want: pk[cur['Package']] = cur['Filename']
        cur = {}; continue
    if ':' in line and not line.startswith(' '):
        k, v = line.split(':', 1); cur[k] = v.strip()
open('urls.txt','w').write('\n'.join('https://deb.debian.org/debian/' + f for f in pk.values()))
PY
  xargs -n1 curl -sLO < urls.txt
  for d in *.deb; do mkdir -p x && (cd x && ar x ../$d && tar xf data.tar.* -C $T/sysroot && rm -f data.tar.* control.tar.* debian-binary); done
  cd $T
fi
if [ ! -f $T/pspdev/.patched ]; then
  python3 - <<PY
import os, subprocess
from elftools.elf.elffile import ELFFile
sr = "$SR"; n = 0
for root, _, fs in os.walk('$T/pspdev'):
    for f in fs:
        p = os.path.join(root, f)
        if os.path.islink(p) or not os.path.isfile(p): continue
        with open(p,'rb') as fh:
            if fh.read(4) != b'\x7fELF': continue
            fh.seek(0); e = ELFFile(fh)
            if e['e_machine'] != 'EM_X86_64' or not e.get_section_by_name('.dynamic'): continue
            interp = any(s['p_type'] == 'PT_INTERP' for s in e.iter_segments())
        cmd = ['patchelf', '--set-rpath', sr]
        if interp: cmd += ['--set-interpreter', sr + '/ld-linux-x86-64.so.2']
        r = subprocess.run(cmd + [p], capture_output=True, text=True)
        n += (r.returncode == 0)
print("patched", n)
PY
  touch $T/pspdev/.patched
fi
echo "PSPSDK: $($T/pspdev/bin/psp-gcc --version | head -1)"
