"""annot.py ADDR... : print generated C for functions with selector/class/cfstring constants annotated"""
import sys, re, glob
sys.path.insert(0, '/data/re4psp/recomp')
from macho import MachO
m = MachO('/data/re4psp/ipa/Payload/Res4.app/Res4')
def cstr(a):
    b = m.read(a, 200); return b[:b.index(b'\0')].decode('latin1')
names = {}
for (seg, sec), s in m.sectseg.items():
    a0, n = s['addr'], s['size']
    if sec == '__objc_selrefs':
        for a in range(a0, a0 + n, 4): names[a] = '@' + cstr(m.u32(a))
    elif sec in ('__objc_classrefs', '__objc_superrefs'):
        for a in range(a0, a0 + n, 4):
            v = m.u32(a)
            try: names[a] = '#' + cstr(m.u32((m.u32(v + 16) & ~3) + 16)) if v else '#?'
            except Exception: names[a] = '#?'
    elif sec == '__cfstring':
        for a in range(a0, a0 + n, 16): names[a] = '"%s"' % cstr(m.u32(a + 8))
# extern relocations give names for class refs
for r in m.extrel:
    a = r['addr'] if isinstance(r, dict) else r[0]
    nm = r.get('name') if isinstance(r, dict) else None
    if nm: names[a] = '#' + nm
src = ''.join(open(f).read() for f in sorted(glob.glob('/data/re4psp/build/gen/gen_*.c')))
for a in sys.argv[1:]:
    a = int(a, 16)
    mt = re.search(r'^u64 F_%06x\(.*?^}\n' % a, src, re.S | re.M)
    if not mt: print('no func', hex(a)); continue
    for line in mt.group(0).splitlines():
        if re.search(r'WR32A\(sp - |RD32A\(sp( \+ \d+)?\)|RC_ENTER|u32 lr =|u64 rv = 0', line): continue
        c = [names[int(x, 16)] for x in re.findall(r'0x([0-9a-f]+)u', line) if int(x, 16) in names]
        print(line + ('   // ' + ' '.join(c) if c else ''))
