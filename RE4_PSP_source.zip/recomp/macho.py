"""Minimal Mach-O (32-bit ARM) reader for the RE4 static recompiler."""
import struct, bisect

LC_SEGMENT, LC_SYMTAB, LC_UNIXTHREAD, LC_DYSYMTAB, LC_LOAD_DYLIB = 1, 2, 5, 0xb, 0xc
S_NON_LAZY, S_LAZY, S_STUBS, S_MOD_INIT = 6, 7, 8, 9
INDIRECT_LOCAL, INDIRECT_ABS = 0x80000000, 0x40000000


class MachO:
    def __init__(self, path):
        self.path = path
        b = self.b = open(path, 'rb').read()
        magic, self.cputype, self.cpusub, self.filetype, ncmds, _, self.flags = struct.unpack_from('<IiiIIII', b, 0)
        assert magic == 0xfeedface, 'need thin 32-bit Mach-O'
        self.segments, self.sections, self.dylibs = [], [], []
        self.entry = None; symtab = dysym = None
        p = 28
        for _ in range(ncmds):
            cmd, cs = struct.unpack_from('<II', b, p)
            if cmd == LC_SEGMENT:
                name = b[p+8:p+24].rstrip(b'\0').decode()
                va, vs, fo, fs, maxp, initp, ns, fl = struct.unpack_from('<IIIIiiII', b, p+24)
                self.segments.append(dict(name=name, addr=va, size=vs, off=fo, fsize=fs, prot=initp))
                q = p + 56
                for _ in range(ns):
                    sn = b[q:q+16].rstrip(b'\0').decode(); sg = b[q+16:q+32].rstrip(b'\0').decode()
                    a, sz, off, al, ro, nr, f, r1, r2 = struct.unpack_from('<IIIIIIIII', b, q+32)
                    self.sections.append(dict(seg=sg, name=sn, addr=a, size=sz, off=off, align=al,
                                              reloff=ro, nreloc=nr, flags=f, r1=r1, r2=r2, index=len(self.sections)+1))
                    q += 68
            elif cmd == LC_SYMTAB:
                symtab = struct.unpack_from('<IIII', b, p+8)
            elif cmd == LC_DYSYMTAB:
                dysym = struct.unpack_from('<18I', b, p+8)
            elif cmd == LC_LOAD_DYLIB:
                off = struct.unpack_from('<I', b, p+8)[0]
                self.dylibs.append(b[p+off:p+cs].split(b'\0')[0].decode())
            elif cmd == LC_UNIXTHREAD:
                flavor, count = struct.unpack_from('<II', b, p+8)
                regs = struct.unpack_from('<%dI' % count, b, p+16)
                self.entry = regs[15]
            p += cs
        # symbols
        so, nsy, sto, _ = symtab
        self.syms = []
        for i in range(nsy):
            strx, ty, sect, desc, val = struct.unpack_from('<IBBHI', b, so + i*12)
            name = b[sto+strx:b.index(b'\0', sto+strx)].decode('latin1')
            self.syms.append((name, ty, sect, desc, val))
        self.sect = {s['name']: s for s in self.sections}
        self.sectseg = {(s['seg'], s['name']): s for s in self.sections}
        text = self.sectseg[('__TEXT', '__text')]
        self.text_lo, self.text_hi = text['addr'], text['addr'] + text['size']
        # defined symbols
        self.defsyms = {}   # name -> addr
        self.addr2name = {}
        fn = {}
        for name, ty, sect, desc, val in self.syms:
            if ty & 0xe0 or (ty & 0x0e) != 0x0e or sect == 0:
                continue
            self.defsyms.setdefault(name, val)
            s = self.sections[sect-1]
            if s['seg'] == '__TEXT' and s['name'] == '__text':
                # prefer external names over local duplicates
                if val not in fn or (ty & 1 and not fn[val][1]):
                    fn[val] = (name, ty & 1)
            else:
                self.addr2name.setdefault(val, name)
        self.funcs = sorted((a, n) for a, (n, _) in fn.items())
        self.func_addrs = [a for a, _ in self.funcs]
        self.func_name = {a: n for a, n in self.funcs}
        for a, n in self.funcs:
            self.addr2name.setdefault(a, n)
        # indirect symbols: stubs / lazy & non-lazy pointers
        self.indirect = []
        self.stubs, self.ptrs, self.ptr_kind = {}, {}, {}
        self.extrel, self.locrel = [], []
        if dysym:
            (ilocal, nlocal, iext, next_, iundef, nundef, tocoff, ntoc, modtaboff, nmodtab,
             extrefoff, nextref, indoff, nind, extreloff, nextrel, locreloff, nlocrel) = dysym
            self.indirect = list(struct.unpack_from('<%dI' % nind, b, indoff))
            self.extrel = [self._rel(extreloff + 8*i) for i in range(nextrel)]
            self.locrel = [self._rel(locreloff + 8*i) for i in range(nlocrel)]
        for s in self.sections:
            t = s['flags'] & 0xff
            if t == S_STUBS:
                n = s['size'] // s['r2']
                for i in range(n):
                    self.stubs[s['addr'] + i*s['r2']] = self._indname(s['r1'] + i)
            elif t in (S_LAZY, S_NON_LAZY):
                for i in range(s['size'] // 4):
                    a = s['addr'] + 4*i
                    self.ptrs[a] = self._indname(s['r1'] + i)
                    self.ptr_kind[a] = 'lazy' if t == S_LAZY else 'nonlazy'
        self.mod_init = []
        for s in self.sections:
            if (s['flags'] & 0xff) == S_MOD_INIT:
                self.mod_init += [self.u32(s['addr'] + 4*i) for i in range(s['size'] // 4)]
        # undefined (imported) symbol -> library ordinal
        self.imp_lib = {}
        for name, ty, sect, desc, val in self.syms:
            if not (ty & 0xe0) and (ty & 0x0e) == 0 and ty & 1:
                o = desc >> 8
                self.imp_lib[name] = self.dylibs[o-1] if 0 < o <= len(self.dylibs) else '?'

    def _rel(self, off):
        a, info = struct.unpack_from('<iI', self.b, off)
        if a & 0x80000000:  # scattered
            ua = a & 0xffffffff
            return dict(scattered=True, addr=ua & 0xffffff, type=(ua >> 24) & 0xf, length=(ua >> 28) & 3,
                        pcrel=(ua >> 30) & 1, value=info)
        return dict(scattered=False, addr=a, sym=info & 0xffffff, pcrel=(info >> 24) & 1,
                    length=(info >> 25) & 3, ext=(info >> 27) & 1, type=(info >> 28) & 0xf,
                    name=self.syms[info & 0xffffff][0] if (info >> 27) & 1 else None)

    def _indname(self, i):
        v = self.indirect[i]
        if v & (INDIRECT_LOCAL | INDIRECT_ABS):
            return None
        return self.syms[v][0]

    def seg_of(self, addr):
        for s in self.segments:
            if s['addr'] <= addr < s['addr'] + s['size']:
                return s
        return None

    def sect_of(self, addr):
        for s in self.sections:
            if s['addr'] <= addr < s['addr'] + s['size']:
                return s
        return None

    def read(self, addr, n):
        s = self.seg_of(addr)
        if s is None:
            raise KeyError(hex(addr))
        o = addr - s['addr']
        data = self.b[s['off'] + o: s['off'] + min(o + n, s['fsize'])]
        return data + b'\0' * (n - len(data))

    def u32(self, addr):
        return struct.unpack('<I', self.read(addr, 4))[0]

    def in_text(self, addr):
        return self.text_lo <= addr < self.text_hi

    def func_end(self, addr):
        i = bisect.bisect_right(self.func_addrs, addr)
        return self.func_addrs[i] if i < len(self.func_addrs) else self.text_hi

    def func_containing(self, addr):
        i = bisect.bisect_right(self.func_addrs, addr) - 1
        return self.func_addrs[i] if i >= 0 else None
