"""Per-function control-flow discovery and CPSR flag liveness."""
from armdec import decode

NF, ZF, CF, VF = 1, 2, 4, 8
COND_READS = {0: ZF, 1: ZF, 2: CF, 3: CF, 4: NF, 5: NF, 6: VF, 7: VF, 8: CF | ZF, 9: CF | ZF,
              10: NF | VF, 11: NF | VF, 12: NF | ZF | VF, 13: NF | ZF | VF, 14: 0, 15: 0}
NORETURN = {'___assert_rtn', '_exit', '_abort', '__Unwind_SjLj_Resume', '___cxa_throw', '___cxa_rethrow',
            '__ZSt9terminatev', '___stack_chk_fail', '_longjmp', '__exit', '__ZSt17__throw_bad_allocv',
            '__ZSt20__throw_length_errorPKc', '__ZSt19__throw_logic_errorPKc', '__ZSt20__throw_out_of_rangePKc',
            '__ZSt16__throw_bad_castv', '__ZSt21__throw_bad_exceptionv', '_siglongjmp'}
LOGIC = ('and', 'eor', 'tst', 'teq', 'orr', 'mov', 'bic', 'mvn')
CMPS = ('tst', 'teq', 'cmp', 'cmn')


def is_mov_lr_pc(d):
    return d['k'] == 'dp' and d['op'] == 'mov' and d['rd'] == 14 and d['op2'] == ('reg', 15, 'lsl', 0)


def writes_reg(d, r):
    k = d['k']
    if k == 'dp':
        return d['op'] not in CMPS and d['rd'] == r
    if k == 'mem':
        return (d['load'] and d['rd'] == r) or ((d['w'] or not d['p']) and d['rn'] == r)
    if k == 'ldm':
        return (d['load'] and r in d['regs']) or (d['w'] and d['rn'] == r)
    if k in ('mul', 'smulxy', 'smlaxy', 'ext', 'rev', 'clz'):
        return d['rd'] == r
    if k == 'mull':
        return r in (d['rdlo'], d['rdhi'])
    if k in ('vmov_rs', 'vmov_rdh'):
        return d['load'] and d['rt'] == r
    if k in ('vmov_rrd', 'vmov_rrss'):
        return d['load'] and r in (d['rt'], d['rt2'])
    if k == 'b':
        return d['link'] and r <= 3
    return k in ('blx_r',) and r <= 3


def flag_rw(d):
    """(reads, writes) CPSR flag masks; conditional instructions write nothing (may not execute)."""
    r = COND_READS.get(d['cond'], 0); w = 0; k = d['k']
    if k == 'dp' and d['rd'] != 15:
        op = d['op']; s = d['s'] or op in CMPS; o2 = d['op2']
        if op in ('adc', 'sbc', 'rsc'):
            r |= CF
        if o2[0] == 'reg' and o2[2] == 'ror' and o2[3] == 0:
            r |= CF   # rrx
        if s:
            if op in LOGIC:
                w = NF | ZF
                if o2[0] == 'imm' and o2[2] is not None:
                    w |= CF
                elif o2[0] == 'reg' and not (o2[2] == 'lsl' and o2[3] == 0):
                    w |= CF
                elif o2[0] == 'regs':
                    r |= CF; w |= CF
            else:
                w = NF | ZF | CF | VF
    elif k in ('mul', 'mull') and d['s']:
        w = NF | ZF
    elif k == 'fmstat':
        w = NF | ZF | CF | VF
    if d['cond'] != 14:
        w = 0
    return r, w


def sets_cpsr(d):
    k = d['k']
    if k == 'dp':
        return d['rd'] != 15 and (d['s'] or d['op'] in CMPS)
    if k in ('mul', 'mull'):
        return bool(d['s'])
    return k == 'fmstat'


class FuncCFG:
    def __init__(self, m, fa):
        self.m, self.fa, self.fe = m, fa, m.func_end(fa)
        self.notes = []
        data = set()
        for _ in range(6):
            self.code, self.labels, self.jts = {}, set(), {}
            self.ft, self.br, self.call_next = {}, {}, set()
            self.data = data
            work = [fa]
            while work:
                a = work.pop()
                while self.fa <= a < self.fe and a not in self.code and a not in data:
                    d = decode(m.u32(a), a)
                    self.code[a] = d
                    term = self.analyze(d, a, work)
                    self.ft[a] = not term
                    if term:
                        break
                    a += 4
            if not any(a in data for a in self.code):
                break
        self.addrs = sorted(self.code)
        self.liveness()

    def add_target(self, t, work, src):
        if self.fa <= t < self.fe:
            self.labels.add(t); work.append(t)
            self.br.setdefault(src, []).append(t)
            return True
        return False

    def jt_count(self, a, reg):
        for back in range(1, 10):
            p = a - 4 * back
            if p < self.fa:
                break
            d = decode(self.m.u32(p), p)
            if d['k'] == 'dp' and d['op'] == 'cmp' and d['rn'] == reg and d['op2'][0] == 'imm':
                return d['op2'][1] + 1
            if writes_reg(d, reg) or d['k'] == 'b':
                break
        return None

    def analyze(self, d, a, work):
        m = self.m; k = d['k']; c = d['cond']
        prev = decode(m.u32(a - 4), a - 4) if a - 4 >= self.fa else None
        callish = prev is not None and is_mov_lr_pc(prev) and prev['cond'] in (c, 14)
        if k == 'mem' and d['load'] and d['rn'] == 15 and d['off'][0] == 'imm':
            lit = a + 8 + (d['off'][1] if d['u'] else -d['off'][1])
            self.data.add(lit & ~3)
        if k == 'memd' and d['load'] and d['rn'] == 15 and d['off'][0] == 'imm':
            lit = a + 8 + (d['off'][1] if d['u'] else -d['off'][1])
            self.data.update((lit & ~3, (lit & ~3) + 4))
        if k == 'vldr' and d['rn'] == 15:
            lit = (a + 8 + d['off']) & ~3
            self.data.add(lit)
            if d['dbl']:
                self.data.add(lit + 4)
        if k == 'mem' and d['load'] and d['rd'] == 15:
            o = d['off']
            if d['rn'] == 15 and o[0] == 'reg' and o[2] == 'lsl' and o[3] == 2 and d['p'] and d['u'] and not d['w']:
                n = self.jt_count(a, o[1])
                if n is None:
                    self.notes.append('jt-no-bound %x' % a)
                    return c == 14
                tbl = a + 8
                tg = [m.u32(tbl + 4 * i) for i in range(n)]
                for i in range(n):
                    self.data.add(tbl + 4 * i)
                self.jts[a] = ('ldr', o[1], n, tg)
                for t in tg:
                    if not self.add_target(t, work, a):
                        self.notes.append('jt-ext %x->%x' % (a, t))
                return c == 14
            if callish:
                self.call_next.add(a)
                return False
            return c == 14
        if k == 'b':
            t = d['target']
            if d['link']:
                if c == 14 and m.stubs.get(t) in NORETURN:
                    return True
                return False
            self.add_target(t, work, a)
            return c == 14
        if k == 'bx':
            if callish and d['rm'] != 14:
                self.call_next.add(a)
                return False
            return c == 14
        if k == 'blx_r':
            return False
        if k == 'ldm' and d['load'] and 15 in d['regs']:
            return c == 14
        if k == 'dp' and d['rd'] == 15 and d['op'] not in CMPS:
            o = d['op2']
            if d['op'] == 'add' and d['rn'] == 15 and o[0] == 'reg' and o[2] == 'lsl' and o[3] == 2:
                n = self.jt_count(a, o[1])
                if n is None:
                    self.notes.append('bt-no-bound %x' % a)
                    return c == 14
                tg = [a + 8 + 4 * i for i in range(n)]
                self.jts[a] = ('add', o[1], n, tg)
                for t in tg:
                    self.add_target(t, work, a)
                return c == 14
            if callish and d['op'] == 'mov':
                self.call_next.add(a)
                return False
            return c == 14
        if k in ('undef', 'svc', 'blx_imm', 'memd_bad'):
            return c == 14
        return False

    def succs(self, a):
        s = list(self.br.get(a, []))
        if a in self.jts:
            s += [t for t in self.jts[a][3] if t in self.code]
        if self.ft.get(a) and (a + 4) in self.code:
            s.append(a + 4)
        return s

    def liveness(self):
        rw = {a: flag_rw(self.code[a]) for a in self.addrs}
        sc = {a: self.succs(a) for a in self.addrs}
        li = {a: 0 for a in self.addrs}
        changed = True
        while changed:
            changed = False
            for a in reversed(self.addrs):
                lo = 0
                for s in sc[a]:
                    lo |= li[s]
                r, w = rw[a]
                v = r | (lo & ~w)
                if v != li[a]:
                    li[a] = v; changed = True
        self.li = li
        self.lo = {a: (lambda l: l)(0) for a in self.addrs}
        for a in self.addrs:
            lo = 0
            for s in sc[a]:
                lo |= li[s]
            self.lo[a] = lo
