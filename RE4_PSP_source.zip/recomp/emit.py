"""C emitter for one function (ARM ABI: u64 F(r0,r1,r2,r3,sp) returning r0|r1<<32)."""
import struct
from cfg import FuncCFG, NF, ZF, CF, VF, LOGIC, CMPS, sets_cpsr, NORETURN

RN = ['r0', 'r1', 'r2', 'r3', 'r4', 'r5', 'r6', 'r7', 'r8', 'r9', 'r10', 'r11', 'r12', 'sp', 'lr', 'pc']
ARGS = 'r0, r1, r2, r3, sp'
GEN_COND = {0: 'Z', 1: '!Z', 2: 'C', 3: '!C', 4: 'N', 5: '!N', 6: 'V', 7: '!V', 8: '(C && !Z)',
            9: '(!C || Z)', 10: '(N == V)', 11: '(N != V)', 12: '(!Z && N == V)', 13: '(Z || N != V)'}


def fname(a):
    return 'F_%06x' % a


class Ctx:
    """Shared generator context (binary + import naming)."""
    def __init__(self, m, imp_cid):
        self.m, self.imp_cid = m, imp_cid
        self.stats = {}

    def stat(self, k, n=1):
        self.stats[k] = self.stats.get(k, 0) + n


class FuncEmitter:
    def __init__(self, ctx, fa):
        self.ctx, self.m, self.fa = ctx, ctx.m, fa
        self.g = FuncCFG(self.m, fa)
        self.out = []
        self.state = None     # CPSR: None (vars N/Z/C/V) | (kind, a, b, set)
        self.fpst = None      # FPSCR compare: None | 'vars' | ('fcmp', x, y, set)
        self.tog = 0
        self.ftog = 0
        self.has_vcmp = any(d['k'] == 'vfp' and d['op'].startswith('cmp') for d in self.g.code.values())

    # ---------- helpers
    def R(self, n, a):
        return RN[n] if n != 15 else '0x%xu' % ((a + 8) & 0xffffffff)

    def unimpl(self, a, why):
        self.ctx.stat('unimpl:' + why)
        return ['return rc_unimpl(0x%x);' % a]

    def newset(self):
        cur = self.state[3] if self.state else None
        k = 1 - cur if cur is not None else self.tog
        self.tog = 1 - k
        return k

    def cflag(self):
        st = self.state
        if st is None:
            return 'C'
        k, A, B = st[0], st[1], st[2]
        if k == 'sub':
            return '(u32)(%s >= %s)' % (A, B)
        if k == 'add':
            return '(u32)((u32)(%s + %s) < %s)' % (A, B, A)
        if k == 'logic':
            return B if B else 'C'
        return '(u32)!(%s < %s)' % (A, B)

    def cond(self, c):
        st = self.state
        if st is None:
            return GEN_COND[c]
        k, A, B = st[0], st[1], st[2]
        if k == 'sub':
            return {0: '%s == %s', 1: '%s != %s', 2: '%s >= %s', 3: '%s < %s',
                    4: '(s32)(%s - %s) < 0', 5: '(s32)(%s - %s) >= 0', 6: 'SUB_V(%s, %s)', 7: '!SUB_V(%s, %s)',
                    8: '%s > %s', 9: '%s <= %s', 10: '(s32)%s >= (s32)%s', 11: '(s32)%s < (s32)%s',
                    12: '(s32)%s > (s32)%s', 13: '(s32)%s <= (s32)%s'}[c] % (A, B)
        if k == 'add':
            sm = '(u32)(%s + %s)' % (A, B); ss = '((s64)(s32)%s + (s32)%s)' % (A, B)
            return {0: sm + ' == 0', 1: sm + ' != 0', 2: '%s < %s' % (sm, A), 3: '%s >= %s' % (sm, A),
                    4: '(s32)%s < 0' % sm, 5: '(s32)%s >= 0' % sm, 6: 'ADD_V(%s, %s)' % (A, B),
                    7: '!ADD_V(%s, %s)' % (A, B), 8: '(%s < %s && %s != 0)' % (sm, A, sm),
                    9: '(%s >= %s || %s == 0)' % (sm, A, sm), 10: ss + ' >= 0', 11: ss + ' < 0',
                    12: ss + ' > 0', 13: ss + ' <= 0'}[c]
        if k == 'logic':
            Cx = B if B else 'C'
            return {0: '%s == 0' % A, 1: '%s != 0' % A, 2: Cx, 3: '!%s' % Cx, 4: '(s32)%s < 0' % A,
                    5: '(s32)%s >= 0' % A, 6: 'V', 7: '!V', 8: '(%s && %s != 0)' % (Cx, A),
                    9: '(!%s || %s == 0)' % (Cx, A), 10: '(%s >> 31) == V' % A, 11: '(%s >> 31) != V' % A,
                    12: '(%s != 0 && (%s >> 31) == V)' % (A, A), 13: '(%s == 0 || (%s >> 31) != V)' % (A, A)}[c]
        X, Y = A, B   # fcmp
        return {0: '%s == %s', 1: '!(%s == %s)', 2: '!(%s < %s)', 3: '%s < %s', 4: '%s < %s', 5: '!(%s < %s)',
                6: 'UNORD(%s, %s)', 7: '!UNORD(%s, %s)', 8: '!(%s <= %s)', 9: '%s <= %s', 10: '%s >= %s',
                11: '!(%s >= %s)', 12: '%s > %s', 13: '!(%s > %s)'}[c] % (X, Y)

    def mat(self, mask):
        st = self.state
        if st is None or not mask:
            return []
        k, A, B = st[0], st[1], st[2]; L = []
        if k == 'sub':
            f = {NF: 'N = (u32)(%s - %s) >> 31;', ZF: 'Z = %s == %s;', CF: 'C = %s >= %s;', VF: 'V = SUB_V(%s, %s);'}
            L = [f[b] % (A, B) for b in (NF, ZF, CF, VF) if mask & b]
        elif k == 'add':
            f = {NF: 'N = (u32)(%s + %s) >> 31;' % (A, B), ZF: 'Z = (u32)(%s + %s) == 0;' % (A, B),
                 CF: 'C = (u32)(%s + %s) < %s;' % (A, B, A), VF: 'V = ADD_V(%s, %s);' % (A, B)}
            L = [f[b] for b in (NF, ZF, CF, VF) if mask & b]
        elif k == 'logic':
            if mask & NF: L.append('N = %s >> 31;' % A)
            if mask & ZF: L.append('Z = %s == 0;' % A)
            if mask & CF and B: L.append('C = %s;' % B)
        else:
            f = {NF: 'N = %s < %s;', ZF: 'Z = %s == %s;', CF: 'C = !(%s < %s);', VF: 'V = UNORD(%s, %s);'}
            L = [f[b] % (A, B) for b in (NF, ZF, CF, VF) if mask & b]
        return L

    def fp_flush(self):
        """Before control flow: spill pending FPSCR compare into FN/FZ/FC/FV."""
        st = self.fpst
        if not isinstance(st, tuple):
            return []
        X, Y = st[1], st[2]
        return ['FN = %s < %s; FZ = %s == %s; FC = !(%s < %s); FV = UNORD(%s, %s);' % (X, Y, X, Y, X, Y, X, Y)]

    def goto(self, t):
        return self.mat(self.g.li.get(t, 15)) + self.fp_flush() + ['goto L_%x;' % t]

    def op2(self, d, want_carry):
        a = d['addr']; o = d['op2']
        if o[0] == 'imm':
            return '0x%xu' % o[1], (('%du' % o[2]) if (want_carry and o[2] is not None) else None)
        if o[0] == 'reg':
            _, rm, st, n = o; R = self.R(rm, a)
            if st == 'lsl':
                if n == 0:
                    return R, None
                return '(%s << %d)' % (R, n), '((%s >> %d) & 1)' % (R, 32 - n)
            if st == 'lsr':
                if n == 0:
                    return '0u', '(%s >> 31)' % R
                return '(%s >> %d)' % (R, n), '((%s >> %d) & 1)' % (R, n - 1)
            if st == 'asr':
                if n == 0:
                    return '(u32)((s32)%s >> 31)' % R, '(%s >> 31)' % R
                return '(u32)((s32)%s >> %d)' % (R, n), '((%s >> %d) & 1)' % (R, n - 1)
            if n == 0:
                return '((%s << 31) | (%s >> 1))' % (self.cflag(), R), '(%s & 1)' % R
            return 'ROR(%s, %d)' % (R, n), '((%s >> %d) & 1)' % (R, n - 1)
        _, rm, st, rs = o; R = self.R(rm, a); S = self.R(rs, a)
        return ('%s_R(%s, %s)' % (st.upper(), R, S),
                ('%s_C(%s, %s, %s)' % (st.upper(), R, S, self.cflag())) if want_carry else None)

    def call(self, target_expr, a, tail=False, direct=None):
        """direct: C function name for a direct call."""
        if direct:
            ce = '%s(%s)' % (direct, ARGS)
        else:
            ce = 'RC_ICALL(%s, %s)' % (target_expr, ARGS)
        if tail:
            return ['return %s;' % ce]
        return ['rv = %s; r0 = (u32)rv; r1 = (u32)(rv >> 32);' % ce]

    def direct_target(self, t):
        """C name for a direct call/branch target outside the function, or None."""
        m = self.m
        if t in m.stubs and m.stubs[t]:
            return 'IMP_' + self.ctx.imp_cid[m.stubs[t]]
        if t in m.func_name:
            return fname(t)
        return None

    # ---------- integer instruction bodies
    def b_dp(self, d):
        from cfg import is_mov_lr_pc
        a = d['addr']; op = d['op']; rd = d['rd']; rn = d['rn']
        s = d['s'] or op in CMPS
        if rd == 15 and op not in CMPS:
            return self.b_dp_pc(d)
        if is_mov_lr_pc(d) and (a + 4) in self.g.call_next:
            return []
        logic = op in LOGIC
        o2, carry = self.op2(d, s and logic)
        Rn = self.R(rn, a); Rd = RN[rd]; L = []
        if logic:
            if op == 'mov':
                e = o2
            elif op == 'mvn':
                e = '~%s' % o2
            else:
                e = {'and': '%s & %s', 'tst': '%s & %s', 'eor': '%s ^ %s', 'teq': '%s ^ %s',
                     'orr': '%s | %s', 'bic': '%s & ~%s'}[op] % (Rn, o2)
            if not s:
                return ['%s = %s;' % (Rd, e)]
            w = NF | ZF | (CF if carry else 0)
            L += self.mat(self.g.lo[a] & ~w)
            k = self.newset(); fr = 'fr%d' % k; fc = ('fc%d' % k) if carry else None
            if carry:
                L.append('%s = %s;' % (fc, carry))
            L.append('%s = %s;' % (fr, e))
            if op not in CMPS:
                L.append('%s = %s;' % (Rd, fr))
            self.state = ('logic', fr, fc, k)
            return L
        A, B = (o2, Rn) if op in ('rsb', 'rsc') else (Rn, o2)
        if op in ('adc', 'sbc', 'rsc'):
            cin = self.cflag()
            if not s:
                if op == 'adc':
                    return ['%s = %s + %s + %s;' % (Rd, A, B, cin)]
                return ['%s = %s - %s - (1u - %s);' % (Rd, A, B, cin)]
            Y = B if op == 'adc' else '~(%s)' % B
            L += ['ta = %s; tb = %s; tc = %s;' % (A, Y, cin), 't64 = (u64)ta + tb + tc; tr = (u32)t64;',
                  'N = tr >> 31; Z = tr == 0; C = (u32)(t64 >> 32); V = (~(ta ^ tb) & (ta ^ tr)) >> 31;',
                  '%s = tr;' % Rd]
            self.state = None
            return L
        opc = '+' if op in ('add', 'cmn') else '-'
        if not s:
            return ['%s = %s %s %s;' % (Rd, A, opc, B)]
        k = self.newset(); fa, fb = 'fa%d' % k, 'fb%d' % k
        L.append('%s = %s; %s = %s;' % (fa, A, fb, B))
        if op not in CMPS:
            L.append('%s = %s %s %s;' % (Rd, fa, opc, fb))
        self.state = ('add' if opc == '+' else 'sub', fa, fb, k)
        return L

    def b_dp_pc(self, d):
        a = d['addr']; op = d['op']; o = d['op2']
        if a in self.g.jts:
            return self.b_switch(d)
        if op == 'mov' and o[0] == 'reg' and o[2] == 'lsl' and o[3] == 0 and not d['s']:
            rm = o[1]
            if rm == 14:
                return ['return RV(r0, r1);']
            return self.call(RN[rm], a, tail=a not in self.g.call_next)
        return self.unimpl(a, 'dp-pc')

    def b_switch(self, d):
        a = d['addr']; kind, reg, n, tg = self.g.jts[a]
        mask = 0
        for t in tg:
            mask |= self.g.li.get(t, 0)
        L = self.mat(mask) + self.fp_flush() + ['switch (%s) {' % RN[reg]]
        for i, t in enumerate(tg):
            L.append(('case %d: goto L_%x;' % (i, t)) if t in self.g.code else
                     ('case %d: return rc_unimpl(0x%x);' % (i, t)))
        return L + ['default: break;', '}']

    def addr_off(self, d):
        a = d['addr']; o = d['off']
        if o[0] == 'imm':
            return o[1], '%du' % o[1]
        _, rm, st, n = o
        if st == 'lsl':
            return None, (self.R(rm, a) if n == 0 else '(%s << %d)' % (self.R(rm, a), n))
        return None, self.op2({'addr': a, 'op2': ('reg', rm, st, n)}, False)[0]

    def b_mem(self, d):
        a = d['addr']; rn, rd, ld = d['rn'], d['rd'], d['load']; size, sg = d['size'], d['signed']
        if ld and rd == 15 and a in self.g.jts:
            return self.b_switch(d)
        immv, oe = self.addr_off(d); sign = '+' if d['u'] else '-'
        if rn == 15 and immv is not None and ld and d['p'] and not d['w']:
            lit = (a + 8 + (immv if d['u'] else -immv)) & 0xffffffff
            v = int.from_bytes(self.m.read(lit, size), 'little')
            if sg and v >> (8 * size - 1):
                v = (v - (1 << (8 * size))) & 0xffffffff
            if rd == 15:
                dt = self.direct_target(v)
                if dt is None:
                    return self.unimpl(a, 'ldr-pc-const')
                return self.call(None, a, tail=a not in self.g.call_next, direct=dt)
            self.ctx.stat('litload')
            return ['%s = 0x%xu;' % (RN[rd], v)]
        base = self.R(rn, a)
        sfx = 'A' if (rn == 13 and size == 4) else ''
        fn = {(4, 0): 'RD32', (2, 0): 'RD16', (2, 1): 'RDS16', (1, 0): 'RD8', (1, 1): 'RDS8'}[(size, sg)] + sfx
        wfn = {4: 'WR32', 2: 'WR16', 1: 'WR8'}[size] + sfx
        val = self.R(rd, a)
        L = []
        off_e = base if immv == 0 else '%s %s %s' % (base, sign, oe)
        if d['p'] and not d['w']:
            ea = off_e
        elif d['p']:
            if ld:
                L.append('%s = %s;' % (RN[rn], off_e)); ea = RN[rn]
            else:
                L.append('t32 = %s;' % off_e)
                return L + ['%s(t32, %s);' % (wfn, val), '%s = t32;' % RN[rn]]
        else:
            if ld:
                L.append('t32 = %s; %s = t32 %s %s;' % (base, RN[rn], sign, oe)); ea = 't32'
            else:
                return ['%s(%s, %s);' % (wfn, base, val), '%s = %s %s %s;' % (RN[rn], RN[rn], sign, oe)]
        if not ld:
            return L + ['%s(%s, %s);' % (wfn, ea, val)]
        if rd == 15:
            L.append('t32 = %s(%s);' % (fn, ea))
            if a in self.g.call_next:
                return L + self.call('t32', a)
            if rn == 13:
                return L + ['return RV(r0, r1);']
            return L + self.call('t32', a, tail=True)
        return L + ['%s = %s(%s);' % (RN[rd], fn, ea)]

    def b_memd(self, d):
        return self.unimpl(d['addr'], 'ldrd')

    def b_ldm(self, d):
        a = d['addr']; regs = d['regs']; n = len(regs); rn = d['rn']; mode = d['mode']
        if d['user'] or rn == 15:
            return self.unimpl(a, 'ldm-user')
        start = {'ia': 0, 'ib': 4, 'da': -4 * n + 4, 'db': -4 * n}[mode]
        delta = 4 * n if mode in ('ia', 'ib') else -4 * n
        L = []; base = RN[rn]
        if rn != 13:
            L.append('t32 = %s;' % base); base = 't32'

        def ea(i):
            off = start + 4 * i
            return base if off == 0 else '%s %s %d' % (base, '+' if off > 0 else '-', abs(off))
        wb = ['%s = %s %s %d;' % (RN[rn], base, '+' if delta > 0 else '-', abs(delta))] if d['w'] else []
        if not d['load']:
            for i, r in enumerate(regs):
                L.append('WR32A(%s, %s);' % (ea(i), self.R(r, a)))
            return L + wb
        pcea = None
        for i, r in enumerate(regs):
            if r == 15:
                pcea = ea(i)
            else:
                L.append('%s = RD32A(%s);' % (RN[r], ea(i)))
        if rn in regs:
            wb = []
        if pcea is None:
            return L + wb
        if rn == 13:
            return L + wb + ['return RV(r0, r1);']
        return L + ['tc = RD32A(%s);' % pcea] + wb + self.call('tc', a, tail=True)

    def b_b(self, d):
        a = d['addr']; t = d['target']
        if d['link']:
            dt = self.direct_target(t)
            if dt is None:
                return self.unimpl(a, 'bl-mid')
            L = self.call(None, a, direct=dt)
            if self.m.stubs.get(t) in NORETURN:
                L.append('return RV(r0, r1);')
            return L
        if t in self.g.code:
            return self.goto(t)
        dt = self.direct_target(t)
        if dt:
            return self.call(None, a, tail=True, direct=dt)
        return self.unimpl(a, 'b-ext')

    def b_bx(self, d):
        a = d['addr']; rm = d['rm']
        if rm == 14:
            return ['return RV(r0, r1);']
        return self.call(RN[rm], a, tail=a not in self.g.call_next)

    def b_blx_r(self, d):
        return self.call(RN[d['rm']], d['addr'])

    def b_mul(self, d):
        a = d['addr']; e = '%s * %s' % (RN[d['rm']], RN[d['rs']])
        if d['op'] == 'mla':
            e += ' + %s' % RN[d['rn']]
        if not d['s']:
            return ['%s = %s;' % (RN[d['rd']], e)]
        L = self.mat(self.g.lo[a] & (CF | VF))
        k = self.newset(); fr = 'fr%d' % k
        self.state = ('logic', fr, None, k)
        return L + ['%s = %s;' % (fr, e), '%s = %s;' % (RN[d['rd']], fr)]

    def b_mull(self, d):
        a = d['addr']; op = d['op']; lo, hi = RN[d['rdlo']], RN[d['rdhi']]; rm, rs = RN[d['rm']], RN[d['rs']]
        e = ('(u64)%s * %s' % (rm, rs)) if op[0] == 'u' else ('(u64)((s64)(s32)%s * (s32)%s)' % (rm, rs))
        if op.endswith('lal'):
            e = '(%s) + (((u64)%s << 32) | %s)' % (e, hi, lo)
        L = []
        if d['s']:
            L += self.mat(self.g.lo[a] & (CF | VF))
        L += ['t64 = %s;' % e, '%s = (u32)t64; %s = (u32)(t64 >> 32);' % (lo, hi)]
        if d['s']:
            L.append('N = (u32)(t64 >> 63); Z = t64 == 0;')
            self.state = None
        return L

    def half(self, r, top):
        return ('(s32)(s16)(%s >> 16)' if top else '(s32)(s16)%s') % RN[r]

    def b_smulxy(self, d):
        return ['%s = (u32)(%s * %s);' % (RN[d['rd']], self.half(d['rm'], d['x']), self.half(d['rs'], d['y']))]

    def b_smlaxy(self, d):
        return ['%s = (u32)(%s * %s) + %s;' % (RN[d['rd']], self.half(d['rm'], d['x']), self.half(d['rs'], d['y']),
                                               RN[d['rn']])]

    def b_ext(self, d):
        Rm = RN[d['rm']]; rot = d['rot']
        v = Rm if rot == 0 else 'ROR(%s, %d)' % (Rm, rot)
        cast = {'sxtab': '(u32)(s32)(s8)', 'sxtah': '(u32)(s32)(s16)', 'uxtab': '(u32)(u8)',
                'uxtah': '(u32)(u16)'}[d['op']]
        e = '%s(%s)' % (cast, v)
        if d['rn'] != 15:
            e = '%s + %s' % (RN[d['rn']], e)
        return ['%s = %s;' % (RN[d['rd']], e)]

    def b_rev(self, d):
        x = RN[d['rm']]
        e = {'rev': 'BSWAP32(%s)', 'rev16': '(((%s >> 8) & 0x00ff00ffu) | ((%s << 8) & 0xff00ff00u))',
             'revsh': '(u32)(s32)(s16)(((%s >> 8) & 0xffu) | ((%s << 8) & 0xff00u))'}[d['op']]
        return ['%s = %s;' % (RN[d['rd']], e.replace('%s', x))]

    def b_clz(self, d):
        return ['%s = CLZ32(%s);' % (RN[d['rd']], RN[d['rm']])]

    def b_swp(self, d):
        r, w = ('RD8', 'WR8') if d['b'] else ('RD32', 'WR32')
        return ['t32 = %s(%s); %s(%s, %s); %s = t32;' % (r, RN[d['rn']], w, RN[d['rn']], RN[d['rm']], RN[d['rd']])]

    def b_nop(self, d):
        return []

    # ---------- VFP
    def vr(self, dbl, n):
        return ('D%d' if dbl else 'S%d') % n

    def b_vldr(self, d):
        a = d['addr']; rn = d['rn']; off = d['off']; reg = self.vr(d['dbl'], d['d'])
        if rn == 15:
            lit = ((a + 8) & ~3) + off
            if not d['load']:
                return self.unimpl(a, 'vstr-pc')
            if d['dbl']:
                return ['%s = U2D(0x%xull);' % (reg, int.from_bytes(self.m.read(lit, 8), 'little'))]
            return ['%s = U2F(0x%xu);' % (reg, self.m.u32(lit))]
        ea = RN[rn] if off == 0 else '%s %s %d' % (RN[rn], '+' if off > 0 else '-', abs(off))
        if d['load']:
            return ['%s = %s(%s);' % (reg, 'RDD' if d['dbl'] else 'RDF', ea)]
        return ['%s(%s, %s);' % ('WRD' if d['dbl'] else 'WRF', ea, reg)]

    def b_vldm(self, d):
        a = d['addr']; rn = d['rn']; words = d['words']; mode = d['mode']; dbl = d['dbl']
        if rn == 15:
            return self.unimpl(a, 'vldm-pc')
        L = []
        saved = rn == 13 and dbl and d['d'] >= 8   # callee-saved d8-d15 spill/restore: no-op in C model
        if not saved:
            b = RN[rn]
            if rn != 13:
                L.append('t32 = %s;' % b); b = 't32'
            start = 0 if mode == 'ia' else -4 * words
            for i in range(d['count']):
                off = start + (8 if dbl else 4) * i
                ea = b if off == 0 else '%s %s %d' % (b, '+' if off > 0 else '-', abs(off))
                r = self.vr(dbl, d['d'] + i)
                if d['load']:
                    L.append('%s = %s(%s);' % (r, 'RDD' if dbl else 'RDF', ea))
                else:
                    L.append('%s(%s, %s);' % ('WRD' if dbl else 'WRF', ea, r))
        else:
            self.ctx.stat('vsave-elided')
        if d['w']:
            L.append('%s = %s %s %d;' % (RN[rn], RN[rn], '+' if mode == 'ia' else '-', 4 * words))
        return L

    def b_vfp(self, d):
        a = d['addr']; op = d['op']; dbl = d['dbl']
        if op in ('mla', 'mls', 'nmls', 'nmla', 'mul', 'nmul', 'add', 'sub', 'div'):
            D, Nn, Mm = self.vr(dbl, d['d']), self.vr(dbl, d['n']), self.vr(dbl, d['m'])
            e = {'mla': '{D} + {N} * {M}', 'mls': '{D} - {N} * {M}', 'nmls': '{N} * {M} - {D}',
                 'nmla': '-{D} - {N} * {M}', 'mul': '{N} * {M}', 'nmul': '-({N} * {M})', 'add': '{N} + {M}',
                 'sub': '{N} - {M}', 'div': '{N} / {M}'}[op].format(D=D, N=Nn, M=Mm)
            return ['%s = %s;' % (D, e)]
        if op in ('cpy', 'abs', 'neg', 'sqrt'):
            D, Mm = self.vr(dbl, d['d']), self.vr(dbl, d['m'])
            e = {'cpy': '%s', 'abs': ('fabs(%s)' if dbl else 'fabsf(%s)'), 'neg': '-%s',
                 'sqrt': ('sqrt(%s)' if dbl else 'sqrtf(%s)')}[op] % Mm
            return ['%s = %s;' % (D, e)]
        if op.startswith('cmp'):
            X = self.vr(dbl, d['d'])
            Y = ('0.0' if dbl else '0.0f') if op.endswith('z') else self.vr(dbl, d['m'])
            cur = self.state[3] if (self.state and self.state[0] == 'fcmp') else None
            k = (1 - cur) if cur is not None else self.ftog
            self.ftog = 1 - k
            xa, xb = ('ya%d' % k, 'yb%d' % k) if dbl else ('xa%d' % k, 'xb%d' % k)
            self.fpst = ('fcmp', xa, xb, k)
            return ['%s = %s; %s = %s;' % (xa, X, xb, Y)]
        if op == 'cvtds':
            return ['D%d = (double)S%d;' % (d['d'], d['m'])]
        if op == 'cvtsd':
            return ['S%d = (float)D%d;' % (d['d'], d['m'])]
        if op in ('sito', 'uito'):
            return ['%s = (%s)(%s)F2U(S%d);' % (self.vr(dbl, d['d']), 'double' if dbl else 'float',
                                               's32' if op == 'sito' else 'u32', d['m'])]
        if op in ('tosiz', 'touiz', 'tosi', 'toui'):
            fn = ('D2' if dbl else 'F2') + ('S32' if op.startswith('tos') else 'U32') + ('' if op.endswith('z') else '_RN')
            return ['S%d = U2F((u32)%s(%s));' % (d['d'], fn, self.vr(dbl, d['m']))]
        return self.unimpl(a, 'vfp-' + op)

    def b_vmov_rs(self, d):
        if d['load']:
            return ['%s = F2U(S%d);' % (RN[d['rt']], d['sn'])] if d['rt'] != 15 else self.unimpl(d['addr'], 'vmov-pc')
        return ['S%d = U2F(%s);' % (d['sn'], self.R(d['rt'], d['addr']))]

    def b_vmov_rdh(self, d):
        h = 'HI' if d['high'] else 'LO'
        if d['load']:
            return ['%s = D%s(D%d);' % (RN[d['rt']], h, d['dn'])]
        return ['D%d = DSET%s(D%d, %s);' % (d['dn'], h, d['dn'], RN[d['rt']])]

    def b_vmov_rrd(self, d):
        if d['load']:
            return ['t64 = D2U(D%d); %s = (u32)t64; %s = (u32)(t64 >> 32);' % (d['dm'], RN[d['rt']], RN[d['rt2']])]
        return ['D%d = U2D(((u64)%s << 32) | %s);' % (d['dm'], RN[d['rt2']], RN[d['rt']])]

    def b_vmov_rrss(self, d):
        s = d['sm']
        if d['load']:
            return ['%s = F2U(S%d); %s = F2U(S%d);' % (RN[d['rt']], s, RN[d['rt2']], s + 1)]
        return ['S%d = U2F(%s); S%d = U2F(%s);' % (s, RN[d['rt']], s + 1, RN[d['rt2']])]

    def b_fmstat(self, d):
        if isinstance(self.fpst, tuple):
            self.state = self.fpst
            return []
        self.state = None
        return ['N = FN; Z = FZ; C = FC; V = FV;']

    def b_vmrs(self, d):
        return self.unimpl(d['addr'], 'vmrs')

    def b_vmsr(self, d):
        return self.unimpl(d['addr'], 'vmsr')

    # ---------- assembly
    def body(self, d):
        fn = getattr(self, 'b_' + d['k'], None)
        if fn is None:
            return self.unimpl(d['addr'], d['k'])
        return fn(d)

    def emit_insn(self, d):
        a = d['addr']; c = d['cond']
        if c == 14:
            return self.body(d)
        if c == 15:
            return self.unimpl(a, 'cond15')
        ce = self.cond(c)
        pre = []
        if sets_cpsr(d):
            pre = self.mat(self.g.lo[a])
            lines = self.body(d)
            lines += self.mat(self.g.lo[a])
            self.state = None
        else:
            vc = d['k'] == 'vfp' and d['op'].startswith('cmp')
            if vc:
                pre = self.fp_flush()
                if pre:
                    self.fpst = 'vars'
            lines = self.body(d)
            if vc:
                lines += self.fp_flush()
                self.fpst = 'vars'
        if not lines:
            return pre
        return pre + ['if (%s) {' % ce] + ['    ' + l for l in lines] + ['}']

    def gen(self):
        g = self.g; out = []; prev_ft = False
        for a in g.addrs:
            d = g.code[a]
            if a in g.labels:
                if prev_ft:
                    out += self.mat(g.li[a]) + self.fp_flush()
                out.append('L_%x:;' % a)
                self.state = None
                self.fpst = 'vars' if self.has_vcmp else None
            out += self.emit_insn(d)
            prev_ft = g.ft[a]
            if prev_ft and (a + 4) not in g.code:
                nxt = a + 4
                if nxt == g.fe and nxt in self.m.func_name:
                    out.append('return %s(%s);' % (fname(nxt), ARGS))
                    self.ctx.stat('fallthrough-tail')
                else:
                    out += self.unimpl(nxt, 'falloff')
                prev_ft = False
        return out

    def text(self):
        import re
        body = self.gen()
        src = '\n'.join(l if l.startswith('L_') else '    ' + l for l in body)
        used = set(re.findall(r'\b(r(?:[4-9]|1[0-2])|lr|[NZCV]|F[NZCV]|f[abrc][01]|[xy][ab][01]|t32|t64|rv|t[abcr]|S\d+|D\d+)\b', src))
        u32s = sorted(v for v in used if re.fullmatch(r'r\d+|[NZCV]|F[NZCV]|f[abrc][01]|t32|t[abcr]', v))
        dec = []
        if u32s:
            dec.append('u32 ' + ', '.join('%s = 0' % v for v in u32s) + ';')
        if 'lr' in used:
            dec.append('u32 lr = LR_MAGIC;')
        u64s = sorted(v for v in used if v in ('t64', 'rv'))
        if u64s:
            dec.append('u64 ' + ', '.join('%s = 0' % v for v in u64s) + ';')
        fl = sorted((v for v in used if re.fullmatch(r'S\d+|x[ab][01]', v)), key=lambda v: (v[0], len(v), v))
        if fl:
            dec.append('float ' + ', '.join('%s = 0' % v for v in fl) + ';')
        db = sorted((v for v in used if re.fullmatch(r'D\d+|y[ab][01]', v)), key=lambda v: (v[0], len(v), v))
        if db:
            dec.append('double ' + ', '.join('%s = 0' % v for v in db) + ';')
        sregs = {int(v[1:]) for v in used if re.fullmatch(r'S\d+', v)}
        dregs = {int(v[1:]) for v in used if re.fullmatch(r'D\d+', v)}
        if any((2 * k in sregs or 2 * k + 1 in sregs) for k in dregs):
            self.ctx.stat('vfp-alias'); self.ctx.stats.setdefault('alias_funcs', []).append(self.fa)
        head = 'u64 %s(u32 r0, u32 r1, u32 r2, u32 r3, u32 sp) {\n' % fname(self.fa)
        return head + ''.join('    %s\n' % x for x in dec) + '    RC_ENTER(0x%x);\n' % self.fa + src + '\n}\n'
