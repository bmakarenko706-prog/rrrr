"""ARMv6 (ARM state) + VFPv2 decoder working on raw instruction words.
Produces small dicts; only what the generator needs."""

DP_OPS = ['and', 'eor', 'sub', 'rsb', 'add', 'adc', 'sbc', 'rsc',
          'tst', 'teq', 'cmp', 'cmn', 'orr', 'mov', 'bic', 'mvn']
SHIFTS = ['lsl', 'lsr', 'asr', 'ror']


def ror32(v, n):
    n &= 31
    return ((v >> n) | (v << (32 - n))) & 0xffffffff if n else v


def bits(w, hi, lo):
    return (w >> lo) & ((1 << (hi - lo + 1)) - 1)


def decode(w, addr):
    """Return dict with at least 'k' (kind) and 'cond'."""
    cond = w >> 28
    d = {'addr': addr, 'w': w, 'cond': cond}
    if cond == 0xF:
        if (w & 0x0d70f000) == 0x0550f000:
            d['k'] = 'nop'  # PLD
        elif (w & 0x0e000000) == 0x0a000000:
            d['k'] = 'blx_imm'
        else:
            d['k'] = 'undef'
        return d
    op = bits(w, 27, 25)
    if op == 0:
        if (w & 0x0ffffff0) == 0x012fff10:
            d.update(k='bx', rm=w & 15); return d
        if (w & 0x0ffffff0) == 0x012fff30:
            d.update(k='blx_r', rm=w & 15); return d
        if (w & 0x0fff0ff0) == 0x016f0f10:
            d.update(k='clz', rd=bits(w, 15, 12), rm=w & 15); return d
        if (w & 0x0fb00ff0) == 0x01000090:
            d.update(k='swp', b=bits(w, 22, 22), rn=bits(w, 19, 16), rd=bits(w, 15, 12), rm=w & 15); return d
        if (w & 0x0f8000f0) == 0x00000090 or (w & 0x0f8000f0) == 0x00800090:
            o = bits(w, 23, 21); s = bits(w, 20, 20)
            if o in (0, 1):
                d.update(k='mul', op='mla' if o else 'mul', s=s, rd=bits(w, 19, 16), rn=bits(w, 15, 12),
                         rs=bits(w, 11, 8), rm=w & 15)
            elif o >= 4:
                d.update(k='mull', op=['umull', 'umlal', 'smull', 'smlal'][o - 4], s=s, rdhi=bits(w, 19, 16),
                         rdlo=bits(w, 15, 12), rs=bits(w, 11, 8), rm=w & 15)
            else:
                d['k'] = 'undef'
            return d
        if (w & 0x90) == 0x90 and (w & 0x60):
            # extra load/store
            p, u, i, wb, l = bits(w, 24, 24), bits(w, 23, 23), bits(w, 22, 22), bits(w, 21, 21), bits(w, 20, 20)
            sh = bits(w, 6, 5)
            off = ('imm', (bits(w, 11, 8) << 4) | (w & 15)) if i else ('reg', w & 15, 'lsl', 0)
            base = dict(p=p, u=u, w=wb, rn=bits(w, 19, 16), rd=bits(w, 15, 12), off=off)
            if l:
                size, sg = {1: (2, 0), 2: (1, 1), 3: (2, 1)}[sh]
                d.update(k='mem', load=1, size=size, signed=sg, **base)
            elif sh == 1:
                d.update(k='mem', load=0, size=2, signed=0, **base)
            else:
                d.update(k='memd', load=1 if sh == 2 else 0, **base)
            return d
        if (w & 0x0f900000) == 0x01000000:
            # misc space (MRS/MSR/SMULxy/...)
            if (w & 0x0ff00090) == 0x01600080:
                d.update(k='smulxy', rd=bits(w, 19, 16), rs=bits(w, 11, 8), rm=w & 15,
                         x=bits(w, 5, 5), y=bits(w, 6, 6)); return d
            if (w & 0x0ff00090) == 0x01000080:
                d.update(k='smlaxy', rd=bits(w, 19, 16), rn=bits(w, 15, 12), rs=bits(w, 11, 8), rm=w & 15,
                         x=bits(w, 5, 5), y=bits(w, 6, 6)); return d
            d['k'] = 'undef'
            return d
        # data processing, register operand
        rm = w & 15; st = SHIFTS[bits(w, 6, 5)]
        if w & 0x10:
            op2 = ('regs', rm, st, bits(w, 11, 8))
        else:
            op2 = ('reg', rm, st, bits(w, 11, 7))
        d.update(k='dp', op=DP_OPS[bits(w, 24, 21)], s=bits(w, 20, 20), rn=bits(w, 19, 16), rd=bits(w, 15, 12), op2=op2)
        return d
    if op == 1:
        if (w & 0x0fb00000) in (0x03200000, 0x03000000, 0x03400000):
            d['k'] = 'undef'  # MSR imm / MOVW / MOVT (not ARMv6)
            return d
        rot = bits(w, 11, 8) * 2; v = ror32(w & 0xff, rot)
        op2 = ('imm', v, (v >> 31) if rot else None)
        d.update(k='dp', op=DP_OPS[bits(w, 24, 21)], s=bits(w, 20, 20), rn=bits(w, 19, 16), rd=bits(w, 15, 12), op2=op2)
        return d
    if op in (2, 3):
        if op == 3 and (w & 0x10):
            return decode_media(w, d)
        p, u, b, wb, l = bits(w, 24, 24), bits(w, 23, 23), bits(w, 22, 22), bits(w, 21, 21), bits(w, 20, 20)
        if op == 2:
            off = ('imm', w & 0xfff)
        else:
            off = ('reg', w & 15, SHIFTS[bits(w, 6, 5)], bits(w, 11, 7))
        d.update(k='mem', load=l, size=1 if b else 4, signed=0, p=p, u=u, w=wb, rn=bits(w, 19, 16),
                 rd=bits(w, 15, 12), off=off)
        if p == 0 and wb == 1:
            d['k'] = 'undef'  # LDRT/STRT
        return d
    if op == 4:
        regs = [i for i in range(16) if w & (1 << i)]
        p, u = bits(w, 24, 24), bits(w, 23, 23)
        d.update(k='ldm', load=bits(w, 20, 20), rn=bits(w, 19, 16), regs=regs, w=bits(w, 21, 21),
                 user=bits(w, 22, 22), mode={(0, 1): 'ia', (1, 1): 'ib', (0, 0): 'da', (1, 0): 'db'}[(p, u)])
        return d
    if op == 5:
        off = w & 0xffffff
        if off & 0x800000:
            off -= 0x1000000
        d.update(k='b', link=bits(w, 24, 24), target=(addr + 8 + off * 4) & 0xffffffff)
        return d
    if op == 6:
        return decode_vfp_ls(w, d)
    # op == 7
    if w & 0x01000000:
        d.update(k='svc')
        return d
    return decode_vfp_op(w, d)


def decode_media(w, d):
    if (w & 0x0f8003f0) == 0x06800070:
        o = bits(w, 22, 20); rn = bits(w, 19, 16)
        name = {0: 'xtab16', 2: 'sxtab', 3: 'sxtah', 4: 'uxtab16', 6: 'uxtab', 7: 'uxtah'}.get(o)
        if name is None or name.endswith('16'):
            d['k'] = 'undef'; return d
        d.update(k='ext', op=name, rn=rn, rd=bits(w, 15, 12), rm=w & 15, rot=bits(w, 11, 10) * 8)
        return d
    if (w & 0x0fff0ff0) == 0x06bf0f30:
        d.update(k='rev', op='rev', rd=bits(w, 15, 12), rm=w & 15); return d
    if (w & 0x0fff0ff0) == 0x06bf0fb0:
        d.update(k='rev', op='rev16', rd=bits(w, 15, 12), rm=w & 15); return d
    if (w & 0x0fff0ff0) == 0x06ff0fb0:
        d.update(k='rev', op='revsh', rd=bits(w, 15, 12), rm=w & 15); return d
    d['k'] = 'undef'
    return d


def sreg(f, b):   # single register number
    return (f << 1) | b


def decode_vfp_ls(w, d):
    cp = bits(w, 11, 8)
    if cp not in (10, 11):
        d['k'] = 'undef'; return d
    dbl = cp == 11
    if (w & 0x0fe00000) == 0x0c400000:   # MCRR/MRRC: two core regs <-> VFP
        l = bits(w, 20, 20); rt2 = bits(w, 19, 16); rt = bits(w, 15, 12)
        if (w & 0xd0) != 0x10:
            d['k'] = 'undef'; return d
        m = w & 15; mb = bits(w, 5, 5)
        if dbl:
            d.update(k='vmov_rrd', load=l, rt=rt, rt2=rt2, dm=m)
        else:
            d.update(k='vmov_rrss', load=l, rt=rt, rt2=rt2, sm=sreg(m, mb))
        return d
    p, u, D, wb, l = bits(w, 24, 24), bits(w, 23, 23), bits(w, 22, 22), bits(w, 21, 21), bits(w, 20, 20)
    rn = bits(w, 19, 16); fd = bits(w, 15, 12); off8 = w & 0xff
    reg = fd if dbl else sreg(fd, D)
    if p == 1 and wb == 0:
        d.update(k='vldr', load=l, dbl=dbl, d=reg, rn=rn, off=(off8 * 4) if u else -(off8 * 4))
        return d
    if (p, u) in ((0, 1), (1, 0)):
        x = dbl and (off8 & 1)
        cnt = off8 // 2 if dbl else off8
        d.update(k='vldm', load=l, dbl=dbl, d=reg, count=cnt, rn=rn, mode='ia' if u else 'db', w=wb,
                 words=off8)
        return d
    d['k'] = 'undef'
    return d


def decode_vfp_op(w, d):
    cp = bits(w, 11, 8)
    if cp not in (10, 11):
        d['k'] = 'undef'; return d
    dbl = cp == 11
    if w & 0x10:   # register transfer
        l = bits(w, 20, 20); rt = bits(w, 15, 12); opc = bits(w, 23, 21)
        if opc == 7:   # FMXR/FMRX
            reg = bits(w, 19, 16)
            if l and rt == 15 and reg == 1:
                d['k'] = 'fmstat'
            elif l:
                d.update(k='vmrs', rt=rt, reg=reg)
            else:
                d.update(k='vmsr', rt=rt, reg=reg)
            return d
        fn = bits(w, 19, 16); nb = bits(w, 7, 7)
        if not dbl and opc == 0:
            d.update(k='vmov_rs', load=l, rt=rt, sn=sreg(fn, nb)); return d
        if dbl and opc in (0, 1):
            d.update(k='vmov_rdh', load=l, rt=rt, dn=fn, high=opc); return d
        d['k'] = 'undef'; return d
    p, D, q, r, s = bits(w, 23, 23), bits(w, 22, 22), bits(w, 21, 21), bits(w, 20, 20), bits(w, 6, 6)
    fn, fd, fm = bits(w, 19, 16), bits(w, 15, 12), w & 15
    N, M = bits(w, 7, 7), bits(w, 5, 5)
    pqrs = (p << 3) | (q << 2) | (r << 1) | s
    def R(f, b):
        return f if dbl else sreg(f, b)
    names = {0: 'mla', 1: 'mls', 2: 'nmls', 3: 'nmla', 4: 'mul', 5: 'nmul', 6: 'add', 7: 'sub', 8: 'div'}
    if pqrs in names:
        d.update(k='vfp', op=names[pqrs], dbl=dbl, d=R(fd, D), n=R(fn, N), m=R(fm, M))
        return d
    if pqrs != 15:
        d['k'] = 'undef'; return d
    ext = (fn << 1) | N
    E = {0: 'cpy', 1: 'abs', 2: 'neg', 3: 'sqrt', 8: 'cmp', 9: 'cmpe', 10: 'cmpz', 11: 'cmpez',
         15: 'cvt', 16: 'uito', 17: 'sito', 24: 'toui', 25: 'touiz', 26: 'tosi', 27: 'tosiz'}
    op = E.get(ext)
    if op is None:
        d['k'] = 'undef'; return d
    # operand register spaces
    if op == 'cvt':           # dbl=0: Dd <- Sm ; dbl=1: Sd <- Dm
        dd = fd if not dbl else sreg(fd, D)
        mm = sreg(fm, M) if not dbl else fm
        d.update(k='vfp', op='cvtds' if not dbl else 'cvtsd', dbl=dbl, d=dd, m=mm, n=None)
        return d
    if op in ('uito', 'sito'):  # src is single (integer bits), dst by sz
        d.update(k='vfp', op=op, dbl=dbl, d=R(fd, D), m=sreg(fm, M), n=None); return d
    if op in ('toui', 'touiz', 'tosi', 'tosiz'):  # dst single, src by sz
        d.update(k='vfp', op=op, dbl=dbl, d=sreg(fd, D), m=R(fm, M), n=None); return d
    d.update(k='vfp', op=op, dbl=dbl, d=R(fd, D), m=R(fm, M), n=None)
    return d
