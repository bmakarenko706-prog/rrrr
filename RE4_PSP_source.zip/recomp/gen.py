#!/usr/bin/env python3
"""Static recompiler driver: Res4 (ARMv6 Mach-O) -> C sources in OUT."""
import os, sys, re, json, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from macho import MachO
import emit

import io
class _W(io.StringIO):
    def __init__(self, path): super().__init__(); self.path = path
    def __enter__(self): return self
    def __exit__(self, *a):
        new = self.getvalue()
        try:
            old = open(self.path).read()
        except OSError:
            old = None
        if old != new:
            with open(self.path, 'w') as f: f.write(new)
def wopen(path, mode='w'): return _W(path)

BIN = sys.argv[1] if len(sys.argv) > 1 else '/data/re4psp/ipa/Payload/Res4.app/Res4'
OUT = sys.argv[2] if len(sys.argv) > 2 else '/data/re4psp/build/gen'
CHUNK = 2500   # ARM instructions per generated .c file
IMP_BASE = 0x100

m = MachO(BIN)
os.makedirs(OUT, exist_ok=True)
imports = sorted({n for n in m.stubs.values() if n} | {n for n in m.ptrs.values() if n} |


                 {r['name'] for r in m.extrel if r['name']})
assert IMP_BASE + 4 * len(imports) < 0x1000
cid, used = {}, set()
for n in imports:
    c = re.sub(r'[^A-Za-z0-9_]', '_', n[1:] if n.startswith('_') else n)
    while c in used:
        c += '_'
    used.add(c); cid[n] = c
ctx = emit.Ctx(m, cid)

# Memory patches applied to the generated C (address -> [(old, new)]); each must match exactly once.
PATCHES = {
    # Replace the title options Get More action with the PSP controls manual.
    0x99a28: [('    RC_ENTER(0x99a28);', '    RC_ENTER(0x99a28);\n#ifdef RE4_PSP\n    if (r2 == 1u) { extern void manual_open(void); manual_open(); return RV(r0, r1); }\n#endif')],
    0x6dd58: [('    r0 = r4;\n    r1 = 0x1u;\n    r2 = r6;\n    rv = F_070fe4(r0, r1, r2, r3, sp); r0 = (u32)rv; r1 = (u32)(rv >> 32);', '    r0 = r4;\n    r1 = 0x1u;\n    r2 = r6;\n    rv = F_070fe4(r0, r1, r2, r3, sp); r0 = (u32)rv; r1 = (u32)(rv >> 32);\n    { extern int language_russian_font_available(void); extern void language_force_original_font(int); extern void language_original_font_ready(void); extern void rt_log(const char *,...);\n      rt_log("[font] base asset=%.96s japanese=%x eu_slot=%x ru_available=%d", (const char *)(MEM+0xd5aa0u),r5,r6,language_russian_font_available());\n      if(language_russian_font_available()) {\n        language_force_original_font(1);\n        u32 original_font=(u32)F_06dac4(0xd5aa0u,0,0,0,sp);\n        language_force_original_font(0);\n        rt_log("[font] original font handle=%x",original_font);\n        if(original_font) { F_070fe4(r4,2,original_font,0,sp); language_original_font_ready(); }\n      }\n    }')],
    0x70d4c: [('    RC_ENTER(0x70d4c);', '    RC_ENTER(0x70d4c);\n    { extern u32 language_font_index(u32); r1=language_font_index(r1); }')],
    # Expose Russian via the original language menu's default slot.
    0x880b8: [
        ('    RC_ENTER(0x880b8);', '    RC_ENTER(0x880b8);\n    { extern void language_menu_begin(void); language_menu_begin(); }'),
        ('    rv = F_05b0b0(r0, r1, r2, r3, sp); r0 = (u32)rv; r1 = (u32)(rv >> 32);',
         '    rv = F_05b0b0(r0, r1, r2, r3, sp); r0 = (u32)rv; r1 = (u32)(rv >> 32);\n    { extern u32 language_menu_initial(u32); r0 = language_menu_initial(r0); }')],
    0x87e5c: [('    RC_ENTER(0x87e5c);', '    RC_ENTER(0x87e5c);\n    { extern u32 language_menu_commit(u32,u32); extern int language_selected_russian(void); extern void language_menu_end(void);\n      u32 choice=RD32(r0+16u), previous=RD32(r0+20u);\n      u32 actual=language_menu_commit(choice,previous);\n      /* English and Russian share guest slot 1. Force its native resource reload\n         if the displayed choice changed, even when the slot number did not. */\n      if(choice<=1 && choice!=previous && actual==1 && language_selected_russian()==(choice==0)) WR32(r0+20u,~0u);\n      WR32(r0+16u,actual); language_menu_end(); }')],
    0x7fd50: [('    RC_ENTER(0x7fd50);', '    RC_ENTER(0x7fd50);\n    { extern void language_set_guest(u32); language_set_guest((u8)r1); }')],
    0x67b8c: [('    RC_ENTER(0x67b8c);', '    RC_ENTER(0x67b8c);\n    { extern u32 ru_translate_story(u32); r1 = ru_translate_story(r1); }')],
    0x7fe4c: [('    RC_ENTER(0x7fe4c);', '    RC_ENTER(0x7fe4c);\n    { extern u32 ru_extra_string(u32,u32,u32); u32 translated=ru_extra_string(3,r1*10u+r2,RD32(r0+72u)); if(translated) return RV(translated,r1); }')],
    0x7fdc8: [('    RC_ENTER(0x7fdc8);', '    RC_ENTER(0x7fdc8);\n    { extern u32 ru_extra_string(u32,u32,u32); u32 translated=ru_extra_string(2,r1,RD32(r0+72u)); if(translated) return RV(translated,r1); }')],
    0x7fda4: [('    RC_ENTER(0x7fda4);', '    RC_ENTER(0x7fda4);\n    { extern u32 ru_extra_string(u32,u32,u32); u32 translated=ru_extra_string(1,r1,RD32(r0+72u)); if(translated) return RV(translated,r1); }')],
    0x7fd80: [('    RC_ENTER(0x7fd80);', '    RC_ENTER(0x7fd80);\n    { extern u32 ru_extra_string(u32,u32,u32); u32 translated=ru_extra_string(0,r1,RD32(r0+72u)); if(translated) return RV(translated,r1); }')],
    0x7fe1c: [('    RC_ENTER(0x7fe1c);', '    RC_ENTER(0x7fe1c);\n    { extern u32 ru_mission_string(u32,u32,u32,u32); u32 translated=ru_mission_string(1,r1,r2,RD32(r0+72u)); if(translated) return RV(translated,r1); }')],
    0x7fdec: [('    RC_ENTER(0x7fdec);', '    RC_ENTER(0x7fdec);\n    { extern u32 ru_mission_string(u32,u32,u32,u32); u32 translated=ru_mission_string(0,r1,r2,RD32(r0+72u)); if(translated) return RV(translated,r1); }')],
    0x7fd5c: [('    RC_ENTER(0x7fd5c);', '    RC_ENTER(0x7fd5c);\n    { extern u32 ru_sys_string(u32, u32); u32 translated = ru_sys_string(r1, RD32(r0 + 72u)); if (translated) return RV(translated, r1); }')],
    # Hide only the in-game touch overlay during its draw call. Component flags
    # are restored immediately so touches, button state and QTE still work.
    0x7bd34: [
        ('    RC_ENTER(0x7bd34);', '    RC_ENTER(0x7bd34);\n    u32 touch_input_instance = r0;'),
        ('    rv = F_0684d8(r0, r1, r2, r3, sp); r0 = (u32)rv; r1 = (u32)(rv >> 32);',
         '    {\n'
         '        extern u32 MEM_SIZE;\n'
         '        const u8 offsets[] = {4, 8, 16, 20, 24, 28, 32};\n'
         '        u32 nodes[7]; u8 saved[7];\n'
         '        for (int i = 0; i < 7; i++) {\n'
         '            u32 c = RD32(touch_input_instance + offsets[i]);\n'
         '            nodes[i] = (c >= 0x1000u && c < MEM_SIZE - 256u && c != r0) ? c : 0;\n'
         '            saved[i] = nodes[i] ? RD8(c + 81u) : 0;\n'
         '            if (nodes[i]) WR8(c + 81u, 0);\n'
         '        }\n'
         '        rv = F_0684d8(r0, r1, r2, r3, sp);\n'
         '        for (int i = 6; i >= 0; i--) if (nodes[i]) WR8(nodes[i] + 81u, saved[i]);\n'
         '        r0 = (u32)rv; r1 = (u32)(rv >> 32);\n'
         '    }')],
    # ERP_Camera::Set_Perspective: game can call it before viewport dimensions
    # are initialized. Preserve the existing camera until both are nonzero.
    0xd718: [('    RC_ENTER(0xd718);',
              '    RC_ENTER(0xd718);\n'
              '    if ((r1 & 0x7fffffffu) == 0 || (r2 & 0x7fffffffu) == 0) {\n'
              '        static int warned;\n'
              '        if (!warned) { extern void rt_log(const char *, ...); rt_log("[camera] skipped perspective: zero size (w=%08x h=%08x)", r1, r2); warned = 1; }\n'
              '        return RV(r0, r1);\n'
              '    }')],
    # LAS_Command_AnimAlpha::Init: a single-frame animation has a zero denominator.
    # Exec jumps straight to the final alpha for a one-frame animation, so its
    # interpolation slope is unused. Avoid triggering the PSP FPU with 0/0.
    0x796a4: [('S15 = S14 / S15;',
               'S15 = r3 == 0 ? 0.0f : S14 / S15;  /* PSP: no interpolation needed for a single frame */')],
    # rcx::snd::CT_SndPort::CT_SndPort(float seconds) sizes each of the 5 port buffers as seconds * 44100
    # 32-bit frames (8 s -> 1.4 MB each), but every sound resource is 11025 Hz (longest 7.3 s).
    # With matching sound-resource frame count/write patches, this saves 5.3 MB.
    0x82650: [('S15 = U2F(0x472c4400u);', 'S15 = U2F(0x462c4400u);  /* patched: 44100.0f -> 11025.0f */')],
    # The RemoteIO callback consumes at 11025 Hz and the port allocation is
    # 11025 frames/s. Match sound-resource expansion and frame counts to it.
    # Every bundled WAV is 11025 Hz; the platform upsamples the mixed output
    # to 44100 Hz for PSP. This prevents 4x duration and truncated sounds.
    0x82930: [('r0 = 0xac44u;', 'r0 = 0x2b11u;  /* 11025 Hz port rate */')],
    0x829e4: [('r0 = 0xac44u;', 'r0 = 0x2b11u;  /* 11025 Hz port rate */')],
    # rcx::font::TextBoard(long capacity) allocates 132 bytes per character up front, and both users ask
    # for 1024 characters: every UI text label costs 132 KB (the status menu creates ~120 labels, 15 MB).
    # Labels start at 64 characters instead, and TextBoard::_writeCS grows the buffers on demand up to the
    # original 1024 (rc_textboard_grow), so long texts still fit and the 1024 cut-off stays the same.
    0x67978: [('r1 = 0x400u;', 'r1 = 0x40u;  /* patched: TextBoard capacity 1024 -> 64, grows on demand */')],
    0x8be98: [('r1 = 0x400u;', 'r1 = 0x40u;  /* patched: TextBoard capacity 1024 -> 64, grows on demand */')],
    0x652bc: [('    r2 = RD32(r3 + 16u);\n    r3 = RD32(r3 + 12u);\n',
               '    r2 = RD32(r3 + 16u);\n    if ((s32)r2 >= (s32)RD32(r3 + 12u)) rc_textboard_grow(r3);  /* patched */\n'
               '    r3 = RD32(r3 + 12u);\n')],
}

t0 = time.time()
files, cur, cur_n, total = [], [], 0, 0
for a, name in m.funcs:
    fe = emit.FuncEmitter(ctx, a)
    body = fe.text()
    for old, new in PATCHES.get(a, []):
        assert body.count(old) == 1, 'patch for %x does not match' % a
        body = body.replace(old, new)
    txt = '/* %s */\n%s' % (name.replace('*/', '* /'), body)
    cur.append(txt); cur_n += len(fe.g.code); total += len(fe.g.code)
    if fe.g.notes:
        ctx.stats.setdefault('notes', []).extend(fe.g.notes)
    if cur_n >= CHUNK:
        files.append(cur); cur, cur_n = [], 0
if cur:
    files.append(cur)
hdr = '#include "recomp.h"\n#include "funcs.h"\n\n'
for i, fl in enumerate(files):
    with wopen(os.path.join(OUT, 'gen_%03d.c' % i)) as f:
        f.write(hdr + '\n'.join(fl))

with wopen(os.path.join(OUT, 'funcs.h')) as f:
    f.write('#ifndef FUNCS_H\n#define FUNCS_H\n#include "recomp.h"\n')
    f.write(''.join('u64 %s(u32, u32, u32, u32, u32);\n' % emit.fname(a) for a, _ in m.funcs))
    f.write(''.join('u64 IMP_%s(u32, u32, u32, u32, u32);\n' % cid[n] for n in imports))
    f.write('#define RC_NUM_IMPORTS %d\n#define RC_IMP_BASE 0x%x\n#endif\n' % (len(imports), IMP_BASE))

with wopen(os.path.join(OUT, 'imp_weak.c')) as f:
    f.write('#include "recomp.h"\n#include "funcs.h"\nu64 rc_missing_import(u32 idx, u32 r0, u32 r1, u32 r2, u32 r3, u32 sp);\n')
    for i, n in enumerate(imports):
        f.write('__attribute__((weak)) u64 IMP_%s(u32 r0, u32 r1, u32 r2, u32 r3, u32 sp) '
                '{ return rc_missing_import(%d, r0, r1, r2, r3, sp); }\n' % (cid[n], i))

with wopen(os.path.join(OUT, 'tables.c')) as f:
    w = f.write
    w('#include "recomp.h"\n#include "funcs.h"\n#include "rc_tables.h"\n\n')
    w('const rc_func_entry rc_funcs[] = {\n')
    w(''.join('    {0x%x, %s},\n' % (a, emit.fname(a)) for a, _ in m.funcs))
    w('};\nconst u32 rc_nfuncs = %d;\n\n' % len(m.funcs))
    w('const rc_import_entry rc_imports[] = {\n')
    w(''.join('    {"%s", IMP_%s},\n' % (n, cid[n]) for n in imports))
    w('};\nconst u32 rc_nimports = %d;\n\n' % len(imports))
    binds = sorted([(a, imports.index(n), 0) for a, n in m.ptrs.items() if n] +
                   [(r['addr'], imports.index(r['name']), 1) for r in m.extrel if r['name']])
    w('/* pointer slots bound to imports: kind 0 = store address, 1 = add address (extrel) */\n')
    w('const rc_bind_entry rc_binds[] = {\n')
    w(''.join('    {0x%x, %d, %d},\n' % b for b in binds))
    w('};\nconst u32 rc_nbinds = %d;\n\n' % len(binds))
    w('const u32 rc_mod_init[] = {%s};\nconst u32 rc_nmod_init = %d;\n\n' %
      (', '.join('0x%x' % x for x in m.mod_init), len(m.mod_init)))
    w('const rc_seg_entry rc_segs[] = {\n')
    for s in m.segments:
        if s['name'] in ('__TEXT', '__DATA'):
            w('    {"%s", 0x%x, 0x%x, 0x%x, 0x%x},\n' % (s['name'], s['addr'], s['size'], s['off'], s['fsize']))
    w('};\nconst u32 rc_nsegs = 2;\nconst u32 rc_main_addr = 0x%x;\n' % m.defsyms['_main'])
    tx = m.sectseg[('__TEXT', '__text')]
    w('const u32 rc_text_lo = 0x%x, rc_text_hi = 0x%x;   /* ARM code: never read as data once recompiled */\n' % (tx['addr'], tx['addr'] + tx['size']))
    sr = m.sectseg[('__DATA', '__objc_selrefs')]; clr = m.sectseg[('__DATA', '__objc_classlist')]
    w('const u32 rc_selrefs[] = {%s};\nconst u32 rc_nselrefs = %d;\n' % (', '.join('0x%x' % (sr['addr'] + 4 * i) for i in range(sr['size'] // 4)), sr['size'] // 4))
    w('const u32 rc_classlist[] = {%s};\nconst u32 rc_nclasslist = %d;\n' % (', '.join('0x%x' % (clr['addr'] + 4 * i) for i in range(clr['size'] // 4)), clr['size'] // 4))
    syms = {k: v for k, v in m.defsyms.items() if not m.in_text(v)}
    w('const rc_sym_entry rc_datasyms[] = {\n')
    w(''.join('    {"%s", 0x%x},\n' % (k, v) for k, v in sorted(syms.items(), key=lambda x: x[1])))
    w('};\nconst u32 rc_ndatasyms = %d;\n' % len(syms))

st = ctx.stats
st_out = {k: v for k, v in st.items() if not isinstance(v, list)}
st_out.update(files=len(files), functions=len(m.funcs), instructions=total, imports=len(imports),
              seconds=round(time.time() - t0, 1), alias_funcs=['%x' % x for x in st.get('alias_funcs', [])][:40],
              notes=st.get('notes', [])[:40])
json.dump(st_out, open(os.path.join(OUT, 'stats.json'), 'w'), indent=1)
print(json.dumps(st_out, indent=1))
