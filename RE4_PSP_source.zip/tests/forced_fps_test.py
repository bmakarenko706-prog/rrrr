#!/usr/bin/env python3
"""Compile and run the real timer registration with mock Objective-C state."""
from pathlib import Path
import subprocess,tempfile
r=Path(__file__).resolve().parents[1]
s=(r/'runtime/hle_foundation2.c').read_text();s=s[s.index('NM(t_sched)'):s.index('NM(t_invalidate)')]
head=r'''#include "recomp.h"
#include <assert.h>
#include <stdio.h>
#include <math.h>
static u8 memory[0x10000];u8 *const MEM=memory;
#define MAXT 16
static u32 timers[MAXT], next=0x1000;
int rt_target_fps=30;
static u32 objc_new(u32 x){(void)x; u32 p=next;next+=64;return p;}
static u32 objc_retain(u32 x){return x;}
static u32 objc_autorelease(u32 x){return x;}
static const char *sel_name(u32 x){return x==1?"onTick":"otherTimer";}
static double now_s(void){return 0;}
static u32 objc_isa(u32 x){return x;}
static const char *objc_class_name(u32 x){(void)x;return "Mock";}
void rt_log(const char*fmt,...){(void)fmt;}
#define SARG(i) RD32A(sp+4*(i))
#define UNUSED_ARGS ((void)0)
#define RET(x) return (u64)(u32)(x)
#define NM(n) u64 n(u32 self,u32 a2,u32 a3,u32 sp)
'''
main=r'''
int main(void){u32 sp=0x9000;WR32(sp,0);WR32(sp+4,1);WR32(sp+8,0);WR32(sp+12,1);
 u64 orig=D2U(.05);int values[]={20,25,30,60}; double intervals[]={.05,1.0/25,1.0/30,1.0/60};
 for(int i=0;i<4;i++){rt_target_fps=values[i];orig=D2U(intervals[i]);u32 timer=(u32)t_sched(0,(u32)orig,orig>>32,sp);assert(fabs(RDD(timer+4)-1.0/23.0)<1e-10);} orig=D2U(.05);
 WR32(sp+4,2);u32 other=(u32)t_sched(0,(u32)orig,orig>>32,sp);assert(fabs(RDD(other+4)-.05)<1e-10);
 puts("PSP onTick fixed at 23 Hz for all FPS values; other timers unchanged");}
'''
with tempfile.TemporaryDirectory() as td:
 p=Path(td);(p/'test.c').write_text(head+s+main);subprocess.run(['cc','-std=c11','-DRE4_PSP','-I'+str(r/'runtime'),str(p/'test.c'),'-lm','-o',str(p/'test')],check=True);subprocess.run([str(p/'test')],check=True)
psp=(r/'runtime/platform_psp.c').read_text(); assert '!strcmp(k, "fps")' not in psp
print('Old config fps setting cannot override PSP timer')
