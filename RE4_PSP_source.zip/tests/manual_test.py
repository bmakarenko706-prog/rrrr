#!/usr/bin/env python3
"""Run real manual parser/input/rasterizer with stubbed PSP GPU, not game assets."""
from pathlib import Path
import re, subprocess, tempfile
root=Path(__file__).resolve().parents[1]
s=(root/'runtime/manual.c').read_text()
const=sorted(set(re.findall(r'\bGU_[A-Z0-9_]+\b',s)))
buttons=['CIRCLE','CROSS','RIGHT','LEFT','UP','DOWN','RTRIGGER','LTRIGGER']
func=sorted(set(re.findall(r'\b(sceGu\w+)\(',s))-{'sceGuGetMemory'})
with tempfile.TemporaryDirectory() as tmp:
 d=Path(tmp)
 (d/'pspctrl.h').write_text('\n'.join('#define PSP_CTRL_%s (1u<<%d)'%(k,i) for i,k in enumerate(buttons)))
 (d/'pspkernel.h').write_text('#define sceKernelDcacheWritebackRange(...) ((void)0)\n')
 (d/'pspgu.h').write_text('\n'.join('#define %s %d'%(k,i+1) for i,k in enumerate(const))+'\n'+ '\n'.join('#define %s(...) ((void)0)'%f for f in func)+'\nstatic char mem[1024];\nstatic void *sceGuGetMemory(int n){(void)n;return mem;}\n')
 c=r'''
#include <assert.h>
#include <stdio.h>
#include <string.h>
char rt_home_dir[256];
static int lang;
int language_manual_id(void){return lang;}
#include "manual.c"
int main(int argc, char **argv) {
 snprintf(rt_home_dir,sizeof rt_home_dir,"%s",argv[1]);
 for(lang=0;lang<6;lang++) {
  manual_open(); assert(manual_is_open());
  printf("Language %d: %d pages\n",lang,pages); assert(pages==5);
  for(int p=0;p<pages;p++) for(int l=0;l<MANUAL_LINE_MAX;l++) for(int i=0;lines[p][l][i];i++) assert(glyph(lines[p][l][i])->cp==lines[p][l][i]);
  manual_draw(36,408); assert(!dirty); assert(pixels[0]!=pixels[15*TW+15]);
  manual_handle(PSP_CTRL_LEFT);assert(page==0); manual_handle(PSP_CTRL_CROSS);assert(page==1);
  manual_handle(PSP_CTRL_RTRIGGER);assert(page==2);manual_handle(PSP_CTRL_LTRIGGER);assert(page==1);
  manual_handle(PSP_CTRL_CIRCLE);assert(!manual_is_open());
 }
 lang=0; manual_open(); manual_draw(36,408);
 FILE *f=fopen(argv[2],"wb");fprintf(f,"P6\n%d %d\n255\n",PANEL_W,PANEL_H);
 for(int y=0;y<PANEL_H;y++) for(int x=0;x<PANEL_W;x++){u16 v=pixels[y*TW+x]; unsigned char rgb[]={((v&31)*255)/31,(((v>>5)&63)*255)/63,(((v>>11)&31)*255)/31};fwrite(rgb,1,3,f);}fclose(f);
 snprintf(rt_home_dir,sizeof rt_home_dir,"%s",argv[3]); lang=0;manual_open();assert(lines[0][0][0]==0x41b); /* editable file */
 char filepath[512];snprintf(filepath,sizeof filepath,"%s/localization/manual/ru.txt",rt_home_dir);remove(filepath);
 manual_open();assert(pages==5 && lines[0][0][0]==0x423); /* compiled fallback */
 parse_text("");assert(pages==1);parse_text("-");assert(pages==1);parse_text("--");assert(pages==1);parse_text("\xef");assert(pages==1);
 parse_text("A\n---\nB\n");assert(pages==2 && lines[0][0][0]=='A' && lines[1][0][0]=='B');
 parse_text("A\nB\nC\nD\nE\nF\nG\nH\nI\n");assert(pages==2 && lines[1][0][0]=='I');
 puts("Manual parser, translations, glyphs, controls and rasterization OK");
}
'''
 (d/'manual_test.c').write_text(c)
 subprocess.run(['cc','-std=c11','-I'+str(d),'-I'+str(root/'runtime'),'-I'+str(root/'build/gen'),str(d/'manual_test.c'),'-o',str(d/'t')],check=True)
 (d/'localization/manual').mkdir(parents=True)
 (d/'localization/manual/ru.txt').write_text('ЛОКАЛЬНЫЙ\nтекст\n', encoding='utf-8')
 subprocess.run([str(d/'t'),str(root),'/data/manual_preview.ppm',str(d)],check=True)
