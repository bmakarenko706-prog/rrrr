#!/usr/bin/env python3
"""Exercise the actual PSP UI-selection and texture allocator code with host mocks.
This is not a replacement for a PSP GPU or gameplay test."""
from pathlib import Path
import tempfile, subprocess
root=Path(__file__).resolve().parents[1]
p=(root/'runtime/platform_psp.c').read_text(); g=(root/'runtime/gl_gu.c').read_text()
ui=p[p.index('static int gok('):p.index('static float clampf(')]
alloc=g[g.index('#define VB_MAX'):g.index('static void tex_wb(')]
header=r'''
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef uint8_t u8; typedef uint16_t u16; typedef int16_t s16; typedef uint32_t u32;
static u8 data[1048576]; static u8 *MEM=data; static u32 MEM_SIZE=sizeof data;
#define RD8(a) (MEM[(a)])
static u16 rd16(u32 a){u16 v;memcpy(&v,MEM+a,2);return v;}
static u32 rd32(u32 a){u32 v;memcpy(&v,MEM+a,4);return v;}
static void wr16(u32 a,u16 v){memcpy(MEM+a,&v,2);}
static void wr32(u32 a,u32 v){memcpy(MEM+a,&v,4);}
#define RD16(a) rd16(a)
#define RD32(a) rd32(a)
#define A_GUN 5
#define A_KNIFE 6
#define A_MAIN 7
#define A_ASH 8
static void rt_log(const char *fmt, ...){(void)fmt;}
'''
uimain=r'''
int main(void) {
 u32 in=0x2000,root=0x3000,arr=0x4000,ash=0x5000,rect=0x6000;
 wr32(0xdd750,in); MEM[in+60]=1; wr32(in,root); MEM[root+81]=1;
 wr32(root+12,arr); wr32(root+24,1); wr32(arr,ash);
 wr32(in+IN_ASH,ash); wr32(ash+8,rect); MEM[ash+80]=MEM[ash+81]=1;
 wr16(rect+16,339);wr16(rect+18,109);wr16(rect+20,64);wr16(rect+22,64);
 ui_state u;ui_read(&u);assert(u.ash==ash); assert(ui_target(A_ASH,&u)==ash);
 float x,y;assert(ui_point(u.ash,&x,&y) && x==371 && y==141);
 MEM[ash+81]=0;ui_read(&u);assert(!u.ash && ui_target(A_ASH,&u)==0);
 MEM[ash+81]=1;MEM[root+81]=0;ui_read(&u);assert(!u.ash);
 puts("UI selection and Ashley hit-test OK");return 0;
}
'''
aheader=r'''
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
typedef uint8_t u8;typedef uint32_t u32;
static u8 buffer[16384];static u8 *MEM=buffer;static u32 freeb=12000, pnext=8;static int flushes;
static u32 heap_free_bytes(void){return freeb;}
static u32 gmalloc(u32 n){if(n>freeb)return 0;freeb-=n;u32 p=pnext;pnext+=n;return p;}
static void gfree(u32 p){(void)p;}
static void* sceGeEdramGetAddr(void){return (void*)(uintptr_t)0x04000000;}
static void free_deferred(void);
static void list_flush(void){flushes++;free_deferred();}
'''
amain=r'''
int main(void){
 u32 h1=0,h2=0,h3=0;vram_init(0x1000,0x1100);tex_reserve=0;
 assert(tmem_alloc(256,&h1) && (h1&0x80000000u));
 tmem_free_later(h1);assert(ndfree==1);
 assert(tmem_alloc(256,&h2) && h2==h1 && flushes==1 && ndfree==0);
 assert(tmem_alloc(128,&h3) && !(h3&0x80000000u) && tex_main_allocs==1);
 tmem_free_later(h3);list_flush();assert(tex_main_allocs==0);
 tmem_free_later(h2);list_flush();assert(vram_used==0);
 puts("Deferred VRAM reclamation and live count OK");return 0;
}
'''
with tempfile.TemporaryDirectory() as td:
 for name,code in [('ui',header+ui+uimain),('mem',aheader+alloc+amain)]:
  f=Path(td)/(name+'.c'); f.write_text(code); out=Path(td)/name
  subprocess.run(['cc','-std=c11','-O2',str(f),'-o',str(out)],check=True)
  subprocess.run([str(out)],check=True)
