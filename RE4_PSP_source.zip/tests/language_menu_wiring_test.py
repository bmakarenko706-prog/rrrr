#!/usr/bin/env python3
"""Check the recompiler hooks and that the old SELECT overlay is gone."""
from pathlib import Path
root=Path(__file__).resolve().parents[1]
g=(root/'build/gen/gen_049.c').read_text()
init=g[g.index('u64 F_0880b8('):g.index('/* __ZN27Bio4_CTTask_LanguageSettingC1Ev')]
term=g[g.index('u64 F_087e5c('):g.index('/* __ZN27Bio4_CTTask_LanguageSetting6Render')]
assert init.count('language_menu_begin()')==1 and init.count('language_menu_initial(r0)')==1
assert term.count('language_menu_commit(choice,previous)')==1
assert term.count('language_menu_end()')==1
p=(root/'recomp/gen.py').read_text()
for h in ('0x880b8:', '0x87e5c:', 'language_menu_begin()', 'language_menu_initial(r0)', 'language_menu_commit(choice,previous)'): assert h in p
assert 'draw_language_help' not in (root/'runtime/gl_gu.c').read_text()
assert 'language_toggle_saved' not in (root/'runtime/platform_psp.c').read_text()
print('Language screen hook wiring and overlay removal OK')
