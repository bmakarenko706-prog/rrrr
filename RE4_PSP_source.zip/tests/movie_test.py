#!/usr/bin/env python3
"""Validate converted assets and run the real player with a mock PSP platform.
Usage: python3 tests/movie_test.py /path/to/psp_video
"""
from pathlib import Path
import io, struct, subprocess, sys, tempfile, shutil
from PIL import Image
root=Path(__file__).resolve().parents[1];vid=Path(sys.argv[1]);expected={'bio4':813,'buki':140,'kuro':10,'res4':813}
for name,n in expected.items():
 p=vid/(name+'.r4v');f=p.open('rb');magic,w,h,num,den,count,maxsize=struct.unpack('<8s6I',f.read(32));assert (magic,w,h,num,den,count)==(b'RE4MV01\0',480,272,20,1,n)
 for i in range(count):
  b=f.read(4);assert len(b)==4;sz=struct.unpack('<I',b)[0];assert 0<sz<=maxsize
  data=f.read(sz);assert len(data)==sz
  with Image.open(io.BytesIO(data)) as im: assert im.size==(480,272) and im.format=='JPEG'
 assert not f.read(1)
 audio=vid/(name+'.mp3');assert audio.exists()==(name!='kuro')
 if audio.exists():
  spec=subprocess.check_output(['ffprobe','-v','error','-select_streams','a:0','-show_entries','stream=codec_name,sample_rate,channels','-of','csv=p=0',str(audio)],text=True).strip()
  assert spec=='mp3,44100,2',spec
 print(name,count,'frames verified')
main=r'''
#include "rt.h"
#include "platform.h"
#include "psp_movie.h"
#include <assert.h>
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
char rt_bundle_dir[256];static u64 clock_us,render_cost=50000;static int draws,begins,ends,audio_begins,audio_ends,opened,closed,cancel_after=-1;
void rt_log(const char *s,...){(void)s;}
u64 plat_time_us(void){return clock_us;}void plat_sleep_us(u32 u){clock_us+=u;}
int plat_music_open(const char *path,const void *p,u32 n){(void)p;(void)n;FILE*f=fopen(path,"rb");assert(f);fclose(f);opened++;return 8;}
void movie_music_begin(int h){assert(h==8||h==-1);audio_begins++;}void movie_music_end(int h){assert(h==8||h==-1);audio_ends++;if(h==8)closed++;}
void psp_movie_input_begin(void){begins++;}void psp_movie_input_end(void){ends++;}
int psp_movie_input_cancel(void){return cancel_after>=0 && draws>=cancel_after;}
void gl_movie_frame(const unsigned short *p){assert(p);draws++;clock_us+=render_cost;}
int main(int argc,char **argv){assert(argc==3);snprintf(rt_bundle_dir,sizeof rt_bundle_dir,"%s",argv[1]);
 const char *names[]={"bio4","buki","kuro","res4"};int frames[]={813,140,10,813};
 for(int i=0;i<4;i++){int prior=draws;char path[128];snprintf(path,sizeof path,"file:///Res4.app/%s.m4v",names[i]);assert(psp_movie_play(path));assert(draws-prior==frames[i]);}
 assert(begins==4&&ends==4&&audio_begins==4&&audio_ends==4&&opened==3&&closed==3);
 assert(!psp_movie_play("/Res4.app/other.m4v"));assert(!psp_movie_play("/Res4.app/../x"));
 int before=draws;cancel_after=draws+3;assert(psp_movie_play("/Res4.app/kuro.m4v"));assert(draws-before==3 && begins==5 && ends==5 && audio_begins==5 && audio_ends==5);
 cancel_after=-1; before=draws;render_cost=150000;clock_us=0;assert(psp_movie_play("/Res4.app/kuro.m4v"));assert(draws-before<10 && clock_us>=500000 && clock_us<=650000);
 render_cost=50000;clock_us=0;before=draws;snprintf(rt_bundle_dir,sizeof rt_bundle_dir,"%s",argv[2]);assert(psp_movie_play("/Res4.app/kuro.m4v"));assert(draws-before==3 && clock_us<500000);
 puts("Actual JPEG decode and playback scheduler: all movies, silent/audio cases, skip and missing-name handling OK.");
}
'''
with tempfile.TemporaryDirectory() as td:
 d=Path(td);(d/'psp_video').symlink_to(vid.resolve(), target_is_directory=True);(d/'test.c').write_text(main)
 bad=d/'bad'/'psp_video';bad.mkdir(parents=True)
 raw=bytearray((vid/'kuro.r4v').read_bytes());pos=32
 for i in range(4):
  size=struct.unpack_from('<I',raw,pos)[0];pos+=4
  if i==3:raw[pos:pos+size]=bytes(size)
  pos+=size
 (bad/'kuro.r4v').write_bytes(raw)
 subprocess.run(['cc','-std=c11','-Wall','-Wextra','-Wno-misleading-indentation','-I'+str(root/'runtime'),'-I'+str(root/'build/gen'),str(d/'test.c'),str(root/'runtime/psp_movie.c'),'-ljpeg','-o',str(d/'test')],check=True)
 subprocess.run([str(d/'test'),str(d),str(d/'bad')],check=True)
# Ensure integration is on actual play path and game resumes via existing notification.
s=(root/'runtime/hle_uikit.c').read_text();assert 'psp_movie_play(movie)' in s and 'post_later(MP_FINISHED, self, 2)' in s
print('UI movie call and completion notification wiring present.')
