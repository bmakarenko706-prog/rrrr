#!/usr/bin/env python3
"""The custom Cyrillic name is shown only with the Russian font."""
from pathlib import Path
import subprocess,tempfile
r=Path(__file__).resolve().parents[1]
c=r'''
#include "rt.h"
#include "language.h"
#include <assert.h>
#include <stdio.h>
static u8 mem[1024*1024];u8 *MEM=mem;u32 MEM_SIZE=sizeof mem;char rt_home_dir[256];static u32 top=0x1000;
u32 gmalloc(u32 n){u32 p=top;top=(top+n+3)&~3u;return p;}
void rt_log(const char*f,...){(void)f;}
u32 ru_sys_string(u32,u32);
int main(int argc,char**argv){assert(argc==2);snprintf(rt_home_dir,sizeof rt_home_dir,"%s",argv[1]);language_init(argv[1]);language_set_guest(1);language_menu_begin();
 assert(RD16(ru_sys_string(198,1))==0x423);assert(RD16(ru_sys_string(193,1))=='E');
 assert(language_menu_commit(1,0)==1);assert(RD16(ru_sys_string(198,1))=='R');
 language_set_guest(3);assert(RD16(ru_sys_string(198,3))=='R');
 assert(language_menu_commit(0,1)==1);language_set_guest(1);assert(RD16(ru_sys_string(198,1))==0x423);
 puts("Custom label in Russian mode; safe RUSSIAN label with EU font");}
'''
with tempfile.TemporaryDirectory() as td:
 d=Path(td);(d/'ru_font_U16le.fnt').write_bytes(b'test');(d/'localization').mkdir();(d/'localization/language.json').write_text('{"name":"УКРАЇНСЬКА"}',encoding='utf-8');(d/'t.c').write_text(c)
 subprocess.run(['cc','-std=c11','-I'+str(r/'runtime'),str(d/'t.c'),str(r/'runtime/language.c'),str(r/'runtime/ru_translate.c'),str(r/'runtime/ru_external.c'),'-o',str(d/'t')],check=True)
 subprocess.run([str(d/'t'),str(d)],check=True)
