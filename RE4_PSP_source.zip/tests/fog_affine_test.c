#include <assert.h>
#include <math.h>
#include <stdio.h>
#include "../runtime/fog_affine.h"
int main(void) {
    float m[16] = {0}; m[15] = 1.0f; assert(ge_model_is_affine(m));
    m[15] = 0.999999881f; assert(ge_model_is_affine(m));
    m[15] = 1.00000012f; assert(ge_model_is_affine(m));
    m[15] = 1.001f; assert(!ge_model_is_affine(m));
    m[15] = 1.0f; m[11] = -1.0f; assert(!ge_model_is_affine(m));
    m[11] = 0; m[3] = 1e-9f; assert(!ge_model_is_affine(m));
    m[3] = 0; m[15] = NAN; assert(!ge_model_is_affine(m));
    puts("fog affine classification OK");
}
