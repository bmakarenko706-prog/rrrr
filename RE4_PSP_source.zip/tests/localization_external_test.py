#!/usr/bin/env python3
"""Exercise the actual external JSON loader and fallback with a mocked guest heap."""
from pathlib import Path
import json, tempfile, subprocess, shutil
root=Path(__file__).resolve().parents[1]
harness=r'''
#include "rt.h"
#include <stdio.h>
#include <string.h>
#include <stdarg.h>
static u8 mem[1024*1024]; u8 *MEM=mem; u32 MEM_SIZE=sizeof mem; char rt_home_dir[256];
static u32 top=0x1000;
u32 gmalloc(u32 n){u32 p=top; top=(top+n+3)&~3u; return top<sizeof mem?p:0;}
void rt_log(const char *fmt,...){(void)fmt;}
u32 ru_sys_string(u32,u32); u32 ru_mission_string(u32,u32,u32,u32); u32 ru_extra_string(u32,u32,u32); u32 ru_translate_story(u32);
static void print(u32 p) {if(!p){puts("NULL");return;}while(RD16(p)){printf("%04x",RD16(p));p+=2;}puts("");}
int main(int argc,char **argv){if(argc<2)return 2; snprintf(rt_home_dir,sizeof rt_home_dir,"%s",argv[1]);
 print(ru_sys_string(2,1)); print(ru_mission_string(0,0,0,1)); print(ru_extra_string(1,0,1));
 const char *en="I'll never forget it.";u32 p=gmalloc(2*(strlen(en)+1));for(unsigned i=0;i<=strlen(en);i++)WR16(p+2*i,(unsigned char)en[i]);print(ru_translate_story(p));
 print(ru_sys_string(2,0));return 0;}
'''
def enc(s): return ''.join(f'{int.from_bytes(s.encode("utf-16le")[i:i+2],"little"):04x}' for i in range(0,len(s.encode('utf-16le')),2))
with tempfile.TemporaryDirectory() as td:
 d=Path(td);c=d/'test.c';c.write_text(harness);exe=d/'test'
 subprocess.run(['cc','-std=c11','-Wall','-Wextra','-Wno-misleading-indentation','-I'+str(root/'runtime'),str(c),str(root/'runtime/ru_translate.c'),str(root/'runtime/ru_external.c'),str(root/'runtime/language.c'),'-o',str(exe)],check=True)
 loc=d/'localization';loc.mkdir()
 for n in ['ru_menu_draft.json','ru_missions.json','ru_extra.json','ru_story.json']:shutil.copy(root/'localization'/n,loc/n)
 def run():return subprocess.check_output([str(exe),str(d)],text=True).splitlines()
 menu=json.loads((loc/'ru_menu_draft.json').read_text()); menu['entries'][2]['russian_draft']='ПРОВЕРКА \\ "\r\nТЕКСТ';(loc/'ru_menu_draft.json').write_text(json.dumps(menu,ensure_ascii=False),encoding='utf-8')
 missions=json.loads((loc/'ru_missions.json').read_text());missions['names'][0]='Миссия проверка';(loc/'ru_missions.json').write_text(json.dumps(missions),encoding='utf-8')
 extra=json.loads((loc/'ru_extra.json').read_text());extra['item_name']['0']='Новый нож';(loc/'ru_extra.json').write_text(json.dumps(extra,ensure_ascii=False),encoding='utf-8')
 story=json.loads((loc/'ru_story.json').read_text());story["I'll never forget it."]='Новая реплика';(loc/'ru_story.json').write_text(json.dumps(story,ensure_ascii=False),encoding='utf-8')
 expected=[enc(menu['entries'][2]['russian_draft']),enc('Миссия проверка'),enc('Новый нож'),enc('Новая реплика'),'NULL']
 assert run()==expected,(run(),expected)
 (loc/'ru_menu_draft.json').write_text('{broken',encoding='utf-8');(loc/'ru_story.json').unlink()
 expected=[enc('Начать игру'),enc('Миссия проверка'),enc('Новый нож'),enc(json.loads((root/'localization/ru_story.json').read_text())["I'll never forget it."]),'NULL']
 assert run()==expected,(run(),expected)
 print('External menu, missions, items and story; escapes, fallback and language guard OK')
