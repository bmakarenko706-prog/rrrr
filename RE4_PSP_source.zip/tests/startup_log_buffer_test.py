#!/usr/bin/env python3
"""Host test of the real rt_log implementation; does not emulate a PSP."""
import pathlib, subprocess, tempfile
root = pathlib.Path(__file__).resolve().parents[1]
src = (root/'runtime/rt_core.c').read_text()
start = src.index('void rt_log(const char *fmt, ...) {')
end = src.index('\nvoid plat_fatal(', start)
impl = src[start:end]
main = r'''
#include <stdio.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <string.h>
typedef uint64_t u64;
int rt_log_enabled=1,rt_log_time=0;
static u64 clock_us;
u64 plat_time_us(void){return clock_us;}
'''+impl+r'''
static long size(const char *p) {struct stat st; return stat(p,&st) == 0 ? st.st_size : -1;}
int main(int argc,char **argv){
 static char buffer[8192]; if (!freopen(argv[1],"w",stderr)) return 1;
 if(setvbuf(stderr,buffer,_IOFBF,sizeof buffer)) return 2;
 clock_us=100000; rt_log("line %d",1);
#if defined(RE4_PSP) && !defined(RE4_PSPLINK)
 if(size(argv[1])!=0) return 4;
#else
 if(size(argv[1])==0) return 3;
#endif
 clock_us=2100000; rt_log("line %d",2);
 if(size(argv[1])==0) return 5;
 clock_us=2200000; rt_log_enabled=0; rt_log("not written");
 rt_log_enabled=1; rt_log("line %d",3); fflush(stderr);
 FILE *f=fopen(argv[1],"r"); char b[256]={0}; fread(b,1,sizeof b-1,f); fclose(f);
 return strcmp(b,"line 1\nline 2\nline 3\n") ? 6:0;
}
'''
with tempfile.TemporaryDirectory() as d:
 d=pathlib.Path(d); (d/'test.c').write_text(main)
 for mode, flags in [('release',['-DRE4_PSP']),('psplink',['-DRE4_PSP','-DRE4_PSPLINK']),('host',[])]:
  exe=d/mode
  subprocess.run(['cc','-std=c99','-Wall','-Werror',*flags,str(d/'test.c'),'-o',str(exe)],check=True)
  subprocess.run([str(exe),str(d/(mode+'.log'))],check=True)
print('startup log buffering: release, PSPLINK and host passed')
