#!/usr/bin/env python3
"""Exercise saved RU/EN choice and the actual menu/story translation gates."""
from pathlib import Path
import subprocess,tempfile,shutil,hashlib
root=Path(__file__).resolve().parents[1]
harness=r'''
#include "rt.h"
#include "language.h"
#include <assert.h>
#include <stdio.h>
static u8 mem[1024*1024];u8 *MEM=mem;u32 MEM_SIZE=sizeof mem;char rt_home_dir[256];static u32 top=0x1000;
u32 gmalloc(u32 n){u32 p=top;top=(top+n+3)&~3u;return top<sizeof mem?p:0;}
void rt_log(const char *fmt,...){(void)fmt;}
u32 ru_sys_string(u32,u32);u32 ru_mission_string(u32,u32,u32,u32);u32 ru_extra_string(u32,u32,u32);u32 ru_translate_story(u32);
static u32 english(void){const char *s="I'll never forget it.";unsigned n=0;while(s[n])n++;u32 p=gmalloc((n+1)*2);for(unsigned i=0;i<=n;i++)WR16(p+2*i,(unsigned char)s[i]);return p;}
int main(int argc,char**argv){assert(argc==2);snprintf(rt_home_dir,sizeof rt_home_dir,"%s",argv[1]);
 language_init(argv[1]); assert(language_selected_russian() && language_active_russian());
 language_set_guest(1);assert(language_font_index(1)==1); language_original_font_ready();
 assert(language_font_index(1)==1 && language_font_index(0)==0);
 assert(ru_sys_string(2,1));assert(ru_mission_string(0,0,0,1));assert(ru_extra_string(1,0,1));u32 p=english();assert(ru_translate_story(p)!=p);
 assert(!ru_sys_string(2,0));assert(!ru_sys_string(2,2));
 language_set_guest(2);assert(ru_translate_story(p)==p);language_set_guest(1);
 language_menu_begin(); assert(language_menu_is_open());
 assert(language_menu_initial(1)==0 && language_menu_initial(2)==2);
 u32 e=ru_sys_string(193,1), r=ru_sys_string(198,1);
 assert(RD16(e)=='E' && RD16(r)==0x420);
 assert(language_menu_commit(1,0)==1);language_menu_end();
 assert(!language_selected_russian() && !language_active_russian());assert(language_font_index(1)==2);assert(!ru_sys_string(2,1));assert(ru_translate_story(p)==p);
 language_init(argv[1]);assert(!language_selected_russian() && !language_active_russian());language_set_guest(1);
 assert(!ru_sys_string(2,1));assert(!ru_mission_string(0,0,0,1));assert(!ru_extra_string(1,0,1));assert(ru_translate_story(p)==p);
 language_menu_begin();assert(language_menu_initial(1)==1);
 e=ru_sys_string(193,1);r=ru_sys_string(198,1);
 assert(RD16(e)=='E' && RD16(r)=='R');
 assert(language_menu_commit(0,1)==1);language_menu_end();
 assert(language_selected_russian() && language_active_russian());assert(language_font_index(1)==1);assert(ru_sys_string(2,1) && ru_translate_story(p)!=p);
 language_init(argv[1]);language_set_guest(1);assert(language_active_russian() && ru_sys_string(2,1) && ru_translate_story(p)!=p);
 language_original_font_ready(); language_set_guest(4);assert(ru_translate_story(p)==p && language_font_index(1)==2);
 language_menu_begin();assert(language_menu_initial(4)==4);
 assert(language_menu_commit(4,4)==4);language_menu_end();
 assert(language_selected_russian());
 language_init("/nonexistent/path/for/re4-test");
 assert(language_menu_commit(1,0)==1 && language_selected_russian());
 puts("Menu choices, immediate switching, persistence and other languages OK");}
'''
with tempfile.TemporaryDirectory() as td:
 d=Path(td);loc=d/'localization';loc.mkdir(); (d/'ru_font_U16le.fnt').write_bytes(b'test font')
 for f in (root/'localization').glob('*.json'):shutil.copy(f,loc/f.name)
 before={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in loc.iterdir()}
 src=d/'test.c';src.write_text(harness);exe=d/'test'
 subprocess.run(['cc','-std=c11','-Wall','-Wextra','-Wno-misleading-indentation','-I'+str(root/'runtime'),str(src),str(root/'runtime/ru_translate.c'),str(root/'runtime/ru_external.c'),str(root/'runtime/language.c'),'-o',str(exe)],check=True)
 subprocess.run([str(exe),str(d)],check=True)
 assert before=={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in loc.iterdir()}
 assert (d/'re4_language.txt').read_text()=='ru\n'
