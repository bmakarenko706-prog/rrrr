#!/usr/bin/env python3
"""Execute generated font-list initialization and selection with isolated guest mocks."""
from pathlib import Path
import subprocess,tempfile
root=Path(__file__).resolve().parents[1]
g39=(root/'build/gen/gen_039.c').read_text(); start=g39.index('u64 F_06dd58('); end=g39.index('/* __ZN16Bio4_ResourceMgr13Load_LangData',start); load=g39[start:end]
g40=(root/'build/gen/gen_040.c').read_text();start=g40.index('u64 F_070d4c(');end=g40.index('/* __ZN17LYT_Data_FontListC2Ev',start);select=g40[start:end]
head=r'''#include "recomp.h"
#include "language.h"
#include <assert.h>
#include <stdio.h>
static u8 memory[0x100000]; u8 *const MEM=memory; u32 MEM_SIZE=sizeof memory;
static int creates, entries; static u32 fonts[3];
void rt_log(const char *fmt,...){(void)fmt;}
u64 F_06dac4(u32 a,u32 b,u32 c,u32 d,u32 sp){(void)b;(void)c;(void)d;(void)sp;creates++;
 if(creates==1){assert(a==0xd5a8c && language_use_russian_font());return RV(0x7000,0);}
 if(creates==2){assert(a==0xd5aa0 && language_use_russian_font());return RV(0x7100,0);}
 assert(creates==3 && a==0xd5aa0 && !language_use_russian_font());return RV(0x7200,0);}
u64 F_06cbf8(u32 a,u32 b,u32 c,u32 d,u32 sp){(void)a;(void)c;(void)d;(void)sp;return RV(0x5000,b);}
u64 F_070fe4(u32 a,u32 b,u32 c,u32 d,u32 sp){(void)d;(void)sp;assert(a==0x6000 && b<3);fonts[b]=c;entries++;return RV(1,b);}
u64 rc_icall(u32 target,u32 a,u32 b,u32 c,u32 d,u32 sp){(void)target;(void)a;(void)c;(void)d;(void)sp;return RV(3,b);}
'''
main=r'''
int main(int argc,char**argv){assert(argc==2);language_init(argv[1]);WR32(0x5000+12,0x6000);
 F_06dd58(0,0,0,0,0xf0000);assert(creates==3 && entries==3 && fonts[0]==0x7000 && fonts[1]==0x7100 && fonts[2]==0x7200);
 assert(language_use_russian_font()); language_set_guest(1);F_070d4c(0x6000,1,0,0,0xf0000);assert(RD32(0x6000+16)==1);
 assert(language_menu_commit(1,0)==1);F_070d4c(0x6000,1,0,0,0xf0000);assert(RD32(0x6000+16)==2);
 assert(language_menu_commit(0,1)==1);F_070d4c(0x6000,1,0,0,0xf0000);assert(RD32(0x6000+16)==1);
 language_set_guest(3);F_070d4c(0x6000,1,0,0,0xf0000);assert(RD32(0x6000+16)==2);
 F_070d4c(0x6000,0,0,0,0xf0000);assert(RD32(0x6000+16)==0);
 puts("Generated font list retains both font objects and selects RU/EN/other correctly");}
'''
with tempfile.TemporaryDirectory() as td:
 d=Path(td);(d/'ru_font_U16le.fnt').write_bytes(b'test font');src=d/'fonts.c';src.write_text(head+load+select+main);exe=d/'fonts'
 subprocess.run(['cc','-std=c11','-Wall','-Wextra','-Wno-unused-but-set-variable','-I'+str(root/'runtime'),str(src),str(root/'runtime/language.c'),'-o',str(exe)],check=True)
 subprocess.run([str(exe),str(d)],check=True)
gen=(root/'recomp/gen.py').read_text()
for x in ['0x6dd58:', '0x70d4c:', 'language_force_original_font(1)', 'language_font_index(r1)']: assert x in gen
foundation=(root/'runtime/hle_foundation2.c').read_text()
assert foundation.count('language_use_russian_font() &&')==2
print('Recompiler and file loader font hooks OK')
