#!/usr/bin/env python3
"""Exercise actual pack reader and PSP file-handle integration on the host."""
import pathlib, tempfile, subprocess, struct, os
root=pathlib.Path(__file__).resolve().parents[1]
s=(root/'runtime/hle_foundation2.c').read_text()
cache=s[s.index('#ifdef RE4_PSP\n/* Only'):s.index('/* ---------- NSFileManager */')]
fh=s[s.index('/* ---------- NSFileHandle'):s.index('static nmdef fh_im[]')]
pack=(root/'runtime/startup_pack.c').read_text().replace('#include "rt.h"','').replace('#include "startup_pack.h"','').replace('#include "bundle_stat.h"','')
header=r'''
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include <stdlib.h>
#include <assert.h>
#include <sys/stat.h>
int bundle_stat(const char*p,struct stat*s){return stat(p,s);}
void bundle_stat_invalidate(const char*p){(void)p;}
typedef uint32_t u32; typedef uint64_t u64;
#define RE4_PSP 1
#define NM(n) static u64 n(u32 self,u32 _cmd,u32 a2,u32 a3,u32 sp)
#define UNUSED_ARGS (void)self;(void)_cmd;(void)a2;(void)a3;(void)sp
#define RET(x) return (u64)(u32)(x)
static unsigned char memory[8*1024*1024], *MEM=memory;
#define RD32(x) (*(u32*)(MEM+(x)))
#define WR32(x,v) (*(u32*)(MEM+(x))=(v))
char rt_bundle_dir[256],rt_home_dir[256]; static int rt_verbose;
static u32 nextmem=65536,nextobj=1024;
u32 heap_free_bytes(void){return 4*1024*1024;}
u32 gmalloc(u32 n){u32 x=nextmem;nextmem+=(n+7)&~7;assert(nextmem<sizeof memory);return x;}
void gfree(u32 p){(void)p;} void rt_log(const char *s,...){(void)s;}
int language_use_russian_font(void){return 0;}
u32 objc_new(u32 cls){(void)cls;u32 o=nextobj;nextobj+=16;return o;}
u32 objc_autorelease(u32 o){return o;} void objc_dealloc_raw(u32 o){(void)o;}
const char *objc_nsstring_cstr(u32 o){return (char*)MEM+o;}
u32 nsdata_new(u32 b,u32 n,int own){(void)own;u32 o=objc_new(1);WR32(o+4,b);WR32(o+8,n);return o;}
'''
main=r'''
int main(int argc,char **argv){
 snprintf(rt_bundle_dir,sizeof rt_bundle_dir,"%s",argv[1]);
 char a[512],b[512];snprintf(a,sizeof a,"%s/a.bin",argv[1]);snprintf(b,sizeof b,"%s/b.wav",argv[1]);
 if(!strcmp(argv[2],"invalid")){assert(startup_pack_find(a)==-1);return 0;}
 if(!strcmp(argv[2],"changed")){assert(startup_pack_find(a)==-1);assert(startup_pack_find(b)>=0);return 0;}
 u32 x=fh_open(1,a,"rb"),y=fh_open(1,b,"rb"),z=fh_open(1,a,"rb");assert(x&&y&&z);
 assert(fh_cached[RD32(x+4)]==2 && fh_cached[RD32(y+4)]==2);
 u32 d=fh_readlen(x,0,3,0,0);assert(RD32(d+8)==3&&!memcmp(MEM+RD32(d+4),"abc",3));
 d=fh_readlen(y,0,3,0,0);assert(RD32(d+8)==3&&!memcmp(MEM+RD32(d+4),"123",3));
 d=fh_readlen(z,0,2,0,0);assert(RD32(d+8)==2&&!memcmp(MEM+RD32(d+4),"ab",2));
 assert(fh_offset(x,0,0,0,0)==3);fh_seek(x,0,4,0,0);d=fh_readlen(x,0,9,0,0);assert(RD32(d+8)==2&&!memcmp(MEM+RD32(d+4),"ef",2));
 assert(fh_seekend(y,0,0,0,0)==5);d=fh_readlen(y,0,1,0,0);assert(RD32(d+8)==0);
 startup_pack_invalidate(a);assert(startup_pack_find(a)==-1);fh_seek(z,0,3,0,0);d=fh_readlen(z,0,3,0,0);assert(RD32(d+8)==3&&!memcmp(MEM+RD32(d+4),"def",3));assert(!fh_cached[RD32(z+4)]);
 fh_close(x,0,0,0,0);fh_close(y,0,0,0,0);fh_close(z,0,0,0,0);return 0;
}'''
with tempfile.TemporaryDirectory() as t:
 d=pathlib.Path(t); (d/'t.c').write_text(header+pack+cache+fh+main); subprocess.run(['cc','-std=c99','-w',str(d/'t.c'),'-o',str(d/'test')],check=True)
 (d/'a.bin').write_bytes(b'abcdef');(d/'b.wav').write_bytes(b'12345');(d/'list').write_text('a.bin\nb.wav\n')
 p=d/'startup_cache.bin';run=lambda mode:subprocess.run([str(d/'test'),str(d),mode],check=True)
 run('invalid')
 subprocess.run(['python3',str(root/'tools/build_startup_pack.py'),str(d),str(p),'--list',str(d/'list')],check=True)
 run('ok');(d/'a.bin').write_bytes(b'changed content');run('changed')
 p.write_bytes(b'R4P1'+struct.pack('<I',100)+b'broken');run('invalid')
print('startup pack: independent handles, seek, EOF, invalidation, changed/missing/corrupt fallback OK')
