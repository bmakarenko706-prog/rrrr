#!/usr/bin/env python3
"""Test real music mixer, MP3 decoder and movie audio isolation on host mocks."""
from pathlib import Path
import subprocess,sys,tempfile
root=Path(__file__).resolve().parents[1];mp3=Path(sys.argv[1]).resolve()
harness=r'''
#include "rt.h"
#include "platform.h"
#include "psp_movie.h"
#include <assert.h>
#include <string.h>
#include <stdio.h>
void music_mix(s32 *,int);void music_init(void);void music_shutdown(void);
void rt_log(const char *f,...){(void)f;}int rt_verbose=0;
static int energy(s32 *a,int n){int k=0;for(int i=0;i<n*2;i++)if(a[i])k++;return k;}
int main(int argc,char **argv){assert(argc==2);music_init();
 int game=plat_music_open(argv[1],0,0);int movie=plat_music_open(argv[1],0,0);assert(game>=0&&movie>=0&&game!=movie);
 s32 acc[4096];plat_music_play(game,0);
 for(int i=0;i<15;i++){memset(acc,0,sizeof acc);music_mix(acc,2048);} double before=plat_music_time(game);assert(before>0.6);
 movie_music_begin(movie);assert(movie_music_active());int nonzero=0;
 for(int i=0;i<15;i++){memset(acc,0,sizeof acc);music_mix(acc,2048);nonzero+=energy(acc,2048);}
 assert(plat_music_time(game)==before);assert(plat_music_time(movie)>0.6);assert(nonzero>0);
 movie_music_end(movie);assert(!movie_music_active());memset(acc,0,sizeof acc);music_mix(acc,2048);assert(plat_music_time(game)>before);
 before=plat_music_time(game);movie_music_begin(-1);memset(acc,0,sizeof acc);music_mix(acc,2048);assert(!energy(acc,2048));assert(plat_music_time(game)==before);movie_music_end(-1);
 plat_music_close(game);music_shutdown();puts("Actual 44.1kHz stereo MP3 decoder, exclusive mix, mute, resume and cleanup OK.");
}
'''
with tempfile.TemporaryDirectory() as td:
 d=Path(td);(d/'pspkernel.h').write_text('''typedef int SceUID;
static int sceKernelWaitSema(int a,int b,void*c){(void)a;(void)b;(void)c;return 0;}
static int sceKernelSignalSema(int a,int b){(void)a;(void)b;return 0;}
static int sceKernelCreateSema(const char*a,int b,int c,int e,void*f){(void)a;(void)b;(void)c;(void)e;(void)f;return 1;}
static int sceKernelDeleteSema(int a){(void)a;return 0;}
''')
 (d/'pspiofilemgr.h').write_text('''#include <unistd.h>
#include <fcntl.h>
#define PSP_O_RDONLY O_RDONLY
#define PSP_SEEK_SET SEEK_SET
#define PSP_SEEK_END SEEK_END
static int sceIoOpen(const char *p,int f,int m){return open(p,f,m);}
static int sceIoRead(int fd,void*b,int n){return read(fd,b,n);}
static int sceIoClose(int fd){return close(fd);}
static int sceIoLseek32(int fd,int off,int how){return lseek(fd,off,how);}
''')
 (d/'test.c').write_text(harness)
 subprocess.run(['cc','-std=c11','-O2','-Wall','-Wextra','-Wno-unused-function','-I'+str(d),'-I'+str(root/'runtime'),'-I'+str(root/'build/gen'),str(d/'test.c'),str(root/'runtime/psp_music.c'),str(root/'runtime/third_party/rmp3.c'),'-lm','-o',str(d/'test')],check=True)
 subprocess.run([str(d/'test'),str(mp3)],check=True)
