#!/usr/bin/env python3
"""Exercise actual presentation limiter and timer scheduling using a simulated clock."""
from pathlib import Path
import subprocess,tempfile
r=Path(__file__).resolve().parents[1]
s=(r/'runtime/gl_gu.c').read_text(); pacing=s[s.index('    static u64 present_due;'):s.index('    st_vwait +=',s.index('    static u64 present_due;'))]
t=(r/'runtime/hle_foundation2.c').read_text();timer=t[t.index('double timers_run(u32 sp)'):t.index('/* ---------- NSNotificationCenter')]
head=r'''
#include "recomp.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
static u8 memory[65536];u8 *const MEM=memory;
static u64 clock_us=1000000;static int psp_vsync;static int calls;
static u64 plat_time_us(void){return clock_us;}
static void plat_sleep_us(u32 n){clock_us+=n;}
static void sceDisplayWaitVblankStart(void){clock_us=(clock_us/16667+1)*16667;}
static void present(void){
'''
mid=r'''
}
#define MAXT 16
static u32 timers[MAXT];
static double now_s(void){return clock_us/1e6;}
static const char*sel_name(u32 x){(void)x;return "onTick";}
static void objc_release(u32 x){(void)x;}
static void psp_ui_tick_begin(void){}
static void psp_ui_tick_end(void){}
static void objc_send(u32 a,u32 b,u32 c,u32 d,u32 e){(void)a;(void)b;(void)c;(void)d;(void)e;calls++;clock_us+=43478;}
'''
main=r'''
int main(int argc,char**argv){psp_vsync=atoi(argv[1]);u64 start=clock_us;for(int i=0;i<601;i++)present();double fps=600e6/(clock_us-start);assert(fps>22.8 && fps<23.1);
 memset(timers,0,sizeof timers);u32 q=0x1000;timers[0]=q;WR32(q+36,1);WR32(q+24,1);WRD(q+4,1.0/23.0);WRD(q+28,now_s());
 double next=timers_run(0);assert(calls==1 && next<0.00001);printf("vsync=%d presentation ~%.2f fps; callback duration included in timer sleep\n",psp_vsync,fps);}
'''
with tempfile.TemporaryDirectory() as td:
 p=Path(td);(p/'test.c').write_text(head+pacing+mid+timer+main)
 subprocess.run(['cc','-std=c11','-DRE4_PSP','-I'+str(r/'runtime'),str(p/'test.c'),'-lm','-o',str(p/'test')],check=True)
 for flag in ('0','1'):subprocess.run([str(p/'test'),flag],check=True)
