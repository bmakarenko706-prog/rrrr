#!/usr/bin/env python3
"""Exercise the real startup-only metadata cache with an instrumented stat."""
from pathlib import Path
import tempfile, subprocess
root=Path(__file__).resolve().parents[1]
s=(root/'runtime/bundle_stat.c').read_text().replace('#include "rt.h"','').replace('#include "bundle_stat.h"','').replace('int r=stat(path,st);','int r=test_stat(path,st);')
head='''#include <sys/stat.h>\n#include <string.h>\n#include <errno.h>\n#include <stdio.h>\n#include <assert.h>\nchar rt_bundle_dir[256]; static int calls;\nint test_stat(const char*p,struct stat*s){calls++;return stat(p,s);}\n'''
main=r'''
int main(int argc,char **argv){
 snprintf(rt_bundle_dir,sizeof rt_bundle_dir,"%s",argv[1]);char p[512];struct stat st;
 snprintf(p,sizeof p,"%s/a.bin",argv[1]);assert(!bundle_stat(p,&st)&&calls==1&&st.st_size==3);assert(!bundle_stat(p,&st)&&calls==1);
 FILE*f=fopen(p,"wb");fwrite("12345",1,5,f);fclose(f);bundle_stat_invalidate(p);assert(!bundle_stat(p,&st)&&calls==2&&st.st_size==5);
 snprintf(p,sizeof p,"%s/missing",argv[1]);assert(bundle_stat(p,&st)&&errno==ENOENT&&calls==3);assert(bundle_stat(p,&st)&&errno==ENOENT&&calls==3);
 f=fopen(p,"wb");fclose(f);bundle_stat_invalidate(p);assert(!bundle_stat(p,&st)&&calls==4);
 snprintf(p,sizeof p,"%s/font.fnt",argv[1]);assert(!bundle_stat(p,&st));assert(!bundle_stat(p,&st));assert(calls==6);
 assert(!bundle_stat("/tmp",&st));assert(!bundle_stat("/tmp",&st));assert(calls==8);
 bundle_stat_stop();snprintf(p,sizeof p,"%s/a.bin",argv[1]);assert(!bundle_stat(p,&st));assert(!bundle_stat(p,&st));assert(calls==10);
 return 0;
}'''
with tempfile.TemporaryDirectory() as t:
 p=Path(t);(p/'a.bin').write_bytes(b'abc');(p/'font.fnt').write_bytes(b'f');(p/'t.c').write_text(head+s+main)
 subprocess.run(['cc','-std=c99','-Wall','-Werror',str(p/'t.c'),'-o',str(p/'test')],check=True);subprocess.run([str(p/'test'),t],check=True)
print('bundle metadata cache: positive, missing, invalidation, exclusions, stop OK')
