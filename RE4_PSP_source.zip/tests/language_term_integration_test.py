#!/usr/bin/env python3
"""Run the real generated language-menu Term with guest-memory/function mocks."""
from pathlib import Path
import subprocess,tempfile
root=Path(__file__).resolve().parents[1]
s=(root/'build/gen/gen_049.c').read_text(); s=s[s.index('u64 F_087e5c('):s.index('/* __ZN27Bio4_CTTask_LanguageSetting6Render')]
h=r'''#include "recomp.h"
#include "language.h"
#include <assert.h>
#include <stdio.h>
static u8 memory[0x100000];u8 *const MEM=memory;u32 MEM_SIZE=sizeof memory;
static int loads, saved_id, active_at_load;
void rt_log(const char *fmt, ...){(void)fmt;}
u64 rc_icall(u32 t,u32 a,u32 b,u32 c,u32 d,u32 e){(void)t;(void)a;(void)c;(void)d;(void)e;return RV(0x3000,b);}
u64 F_0a2d44(u32 a,u32 b,u32 c,u32 d,u32 e){(void)a;(void)b;(void)c;(void)d;(void)e;assert(0);return 0;}
u64 F_05b0a8(u32 a,u32 b,u32 c,u32 d,u32 e){(void)a;(void)c;(void)d;(void)e;saved_id=b;return RV(0,b);}
u64 F_05bd14(u32 a,u32 b,u32 c,u32 d,u32 e){(void)a;(void)c;(void)d;(void)e;return RV(0,b);}
u64 F_06ddb0(u32 a,u32 b,u32 c,u32 d,u32 e){(void)a;(void)c;(void)d;(void)e;loads++;active_at_load=language_active_russian();language_set_guest(b);return RV(0,b);}
u64 F_06d210(u32 a,u32 b,u32 c,u32 d,u32 e){(void)a;(void)c;(void)d;(void)e;return RV(0,b);}
'''
main=r'''
static void choose(u32 x,u32 prior){u32 task=0x1000,fw=0x2000; WR32(task+4,0);WR32(task+16,x);WR32(task+20,prior);WR32(fw+104,0x4000);language_menu_begin();F_087e5c(task,fw,0,0,0xf0000);assert(!language_menu_is_open());}
int main(int argc,char **argv){assert(argc==2);language_init(argv[1]);assert(language_active_russian());
 choose(1,0);assert(loads==1 && saved_id==1 && active_at_load==0 && !language_translate_for(1));
 choose(0,1);assert(loads==2 && saved_id==1 && active_at_load==1 && language_translate_for(1));
 choose(2,0);assert(loads==3 && saved_id==2 && !language_translate_story());
 choose(0,2);assert(loads==4 && saved_id==1 && active_at_load==1 && language_translate_story());
 language_init(argv[1]);assert(language_active_russian());puts("Actual Term invokes reload for both directions and preserves other language IDs");}
'''
with tempfile.TemporaryDirectory() as td:
 d=Path(td);src=d/'term.c';src.write_text(h+s+main);exe=d/'term';
 subprocess.run(['cc','-std=c11','-I'+str(root/'runtime'),str(src),str(root/'runtime/language.c'),'-o',str(exe)],check=True)
 subprocess.run([str(exe),str(d)],check=True)
