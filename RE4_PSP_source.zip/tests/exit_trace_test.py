#!/usr/bin/env python3
"""Host test of real PSP exit trace functions using stubbed sceIo APIs."""
from pathlib import Path
import subprocess,tempfile
root=Path(__file__).resolve().parents[1]
s=(root/'runtime/platform_psp.c').read_text();part=s[s.index('static void exit_trace_init(void)'):s.index('static int exit_cb(')]
stub=r'''
#include <assert.h>
#include <string.h>
#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
typedef int SceUID;
#define PSP_O_WRONLY O_WRONLY
#define PSP_O_CREAT O_CREAT
#define PSP_O_TRUNC O_TRUNC
#define PSP_O_APPEND O_APPEND
static char base_dir[256];
static int sceIoOpen(const char *p,int flags,int mode){return open(p,flags,mode);}
static int sceIoWrite(int fd,const void *buf,int n){return write(fd,buf,n);}
static int sceIoClose(int fd){return close(fd);}
'''
main=r'''
int main(int argc,char **argv) {
 assert(argc==2);snprintf(base_dir,sizeof base_dir,"%s",argv[1]);
 exit_trace_init();plat_exit_trace("audio: thread stopped");
 char path[300],buf[256]={0};snprintf(path,sizeof path,"%s/re4_exit_debug.log",base_dir);
 FILE*f=fopen(path,"rb");assert(f);assert(fread(buf,1,sizeof buf-1,f)>0);fclose(f);
 assert(strstr(buf,"RE4 exit diagnostics: started\n") && strstr(buf,"audio: thread stopped\n"));
 exit_trace_init();f=fopen(path,"rb");assert(f);memset(buf,0,sizeof buf);fread(buf,1,sizeof buf-1,f);fclose(f);assert(!strstr(buf,"audio: thread stopped"));
 snprintf(base_dir,sizeof base_dir,"%s/no-such-directory",argv[1]);exit_trace_init();plat_exit_trace("ignored");
 puts("Exit trace writes, appends, resets and tolerates missing directory in host mock");
}
'''
with tempfile.TemporaryDirectory() as d:
 p=Path(d);(p/'x.c').write_text(stub+part+main)
 subprocess.run(['cc','-std=c11','-Wall','-Wextra','-Werror',str(p/'x.c'),'-o',str(p/'test')],check=True)
 subprocess.run([str(p/'test'),d],check=True)
