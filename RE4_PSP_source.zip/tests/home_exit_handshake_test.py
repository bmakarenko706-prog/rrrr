#!/usr/bin/env python3
"""Host simulation of HOME callback handoff/watchdog; not a PSP integration test."""
from pathlib import Path
import subprocess, tempfile
root=Path(__file__).resolve().parents[1]
s=(root/'runtime/platform_psp.c').read_text()
fn=s[s.index('static int exit_cb('):s.index('static int cb_thread(')]
stub=r'''
#include <assert.h>
#include <stdio.h>
static volatile int quit_req, home_exit_requested;
static int delays, exit_calls, mode;
static void plat_exit_trace(const char *s) {(void)s;}
static int sceKernelDelayThread(unsigned us) {
 delays++;
 if (mode==1 && us==10000 && delays==3) quit_req=2;
 if (mode==3) assert(us==1000000 && quit_req==2 && home_exit_requested);
 return 0;
}
static int sceKernelExitGame(void) {exit_calls++;return 0;}
'''
main=r'''
int main(void) {
 mode=1; exit_cb(0,0,0); assert(quit_req==2 && home_exit_requested==1 && delays==3 && exit_calls==1);
 quit_req=home_exit_requested=delays=exit_calls=0;mode=2;
 exit_cb(0,0,0); assert(quit_req==1 && home_exit_requested==1 && delays==500 && exit_calls==1);
 quit_req=delays=exit_calls=0; home_exit_requested=1;mode=3;
 finish_platform_exit(); assert(quit_req==2 && delays==1 && exit_calls==1);
 quit_req=home_exit_requested=delays=exit_calls=0;mode=0;
 finish_platform_exit(); assert(quit_req==2 && !delays && exit_calls==1);
 puts("HOME callback handoff, five-second timeout, and fallback simulated OK");
}
'''
with tempfile.TemporaryDirectory() as d:
 c=Path(d)/'test.c';c.write_text(stub+fn+main);exe=Path(d)/'test'
 subprocess.run(['cc','-std=c11','-Wall','-Wextra','-Werror',str(c),'-o',str(exe)],check=True)
 subprocess.run([str(exe)],check=True)
