#!/usr/bin/env python3
"""Test Ukrainian IFNT patcher against a synthetic font; no original game font required."""
from pathlib import Path
import struct, subprocess, tempfile
root=Path(__file__).resolve().parents[1]; ttf=root/'localization/LiberationSans-Bold.ttf'
def make_font():
 head=bytearray(0x474);head[:4]=b'IFNT';struct.pack_into('<I',head,4,2)
 records=[(ord('A'),4,12,0,9)]
 atlas=bytearray(512*250);atlas[9*25*512+4]=255
 return bytes(head)+struct.pack('<I',len(records))+b''.join(struct.pack('<HBBHH',*r) for r in records)+b'\0'*8+struct.pack('<II',512,250)+atlas
def parse(b):
 n=struct.unpack_from('<I',b,0x474)[0];p=0x478+8*n
 return [struct.unpack_from('<HBBHH',b,0x478+8*i) for i in range(n)],b[p+16:]
with tempfile.TemporaryDirectory() as td:
 d=Path(td);src=d/'in.fnt';out=d/'out.fnt';src.write_bytes(make_font())
 subprocess.run(['python3',str(root/'localization/add_ukrainian_to_font.py'),str(src),str(ttf),str(out)],check=True)
 a,pa=parse(src.read_bytes());b,pb=parse(out.read_bytes());lookup={r[0]:r for r in b}
 assert all(lookup[r[0]]==r for r in a)
 for c in 'ЄєІіЇїҐґ':
  r=lookup[ord(c)];_,xoff,width,col,row=r
  assert any(pb[y*512+x] for y in range(row*25,(row+1)*25) for x in range(col*26+xoff,col*26+xoff+width))
 assert pb[9*25*512+4]==pa[9*25*512+4]
 again=d/'again.fnt';subprocess.run(['python3',str(root/'localization/add_ukrainian_to_font.py'),str(out),str(ttf),str(again)],check=True)
 assert again.read_bytes()==out.read_bytes()
 print('Original glyph preserved; eight Ukrainian glyphs populated; second pass unchanged')
