#!/usr/bin/env python3
"""Run the game's actual language-code routine against manual mapping fixtures."""
from pathlib import Path
import subprocess, tempfile, re
root=Path(__file__).resolve().parents[1]
s=(root/'build/gen/gen_059.c').read_text()
start=s.index('u64 F_0a2d44(');end=s.index('/* __ZN26Bio4_CTTask_ResourceChangeD0Ev',start)
func=s[start:end]
head=r'''
#define RC_RUNTIME 1
#include "recomp.h"
#include "language.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
static u8 memory[0x100000]; u8 *MEM=memory; u32 MEM_SIZE=sizeof memory;
void rt_log(const char *fmt,...){(void)fmt;}
char rt_home_dir[256];
#include "manual.c"
static void heading(const char *word) { for(int i=0;word[i];i++)assert(lines[0][0][i]==(unsigned char)word[i]);assert(lines[0][0][strlen(word)]==0); }
static const char *current;static int stage;
u64 IMP_objc_msgSend(u32 a,u32 b,u32 c,u32 d,u32 sp){(void)a;(void)b;(void)d;(void)sp;
 if(stage++<2)return RV(0x1000,0);
 const char *candidate=(const char*)MEM+RD32(c+8);
 return RV(!strcmp(current,candidate),0);
}
'''
main=r'''
static void nsstr(u32 obj,u32 addr,const char *s){WR32(obj+8,addr);WR32(obj+12,strlen(s));memcpy(memory+addr,s,strlen(s)+1);}
int main(int argc,char **argv){assert(argc==3);language_init(argv[1]);snprintf(rt_home_dir,sizeof rt_home_dir,"%s",argv[2]);
 const u32 objs[]={0xe15e4,0xe15f4,0xe1604,0xe1614};
 /* Covers all possible game mappings, including the reported ES = 3. */
 const char *sets[][4]={{"fr","de","it","es"},{"de","it","fr","es"},{"it","fr","de","es"},{"es","it","de","fr"}};
 for(int s=0;s<4;s++){
  for(int i=0;i<4;i++)nsstr(objs[i],0x2000+i*32,sets[s][i]);
  for(int i=0;i<4;i++){
   current=sets[s][i];stage=0;u32 game=(u32)F_0a2d44(0,0,0,0,0xf0000);
   language_set_guest(game);
   int expected=!strcmp(current,"fr")?2:!strcmp(current,"de")?3:!strcmp(current,"it")?4:5;
   assert(language_manual_id()==expected);
   manual_open(); heading(expected==2?"COMMANDES":expected==3?"STEUERUNG":expected==4?"COMANDI":"CONTROLES");
  }
 }
 nsstr(0xe1614,0x2100,"es");language_set_guest(3);assert(language_manual_id()==5);
 language_set_guest(1);assert(language_manual_id()==0);manual_open();assert(lines[0][0][0]==0x423);
 assert(language_menu_commit(1,0)==1);language_set_guest(1);assert(language_manual_id()==1);manual_open();heading("CONTROLS");
 WR32(0xe1614+8,0xfffffffe);language_set_guest(3);assert(language_manual_id()==1);
 puts("Real GetDeviceLanguage code and manual mapping agree for all locale permutations; Spanish=3; RU/EN and bad data OK");
}
'''
with tempfile.TemporaryDirectory() as td:
 d=Path(td);p=d/'test.c';p.write_text(head+func+main)
 manual=(root/'runtime/manual.c').read_text()
 gu=sorted(set(re.findall(r'\bGU_[A-Z0-9_]+\b',manual)))
 methods=sorted(set(re.findall(r'\b(sceGu\w+)\(',manual)) - {'sceGuGetMemory'})
 buttons=['CIRCLE','CROSS','RIGHT','LEFT','UP','DOWN','RTRIGGER','LTRIGGER']
 (d/'pspctrl.h').write_text('\n'.join('#define PSP_CTRL_%s (1u<<%d)'%(k,i) for i,k in enumerate(buttons)))
 (d/'pspkernel.h').write_text('#define sceKernelDcacheWritebackRange(...) ((void)0)\n')
 (d/'pspgu.h').write_text('\n'.join('#define %s %d'%(k,i+1) for i,k in enumerate(gu))+'\n'+'\n'.join('#define %s(...) ((void)0)'%f for f in methods)+'\nstatic char gu_mem[1024];static void *sceGuGetMemory(int n){(void)n;return gu_mem;}\n')
 subprocess.run(['cc','-std=c11','-Wall','-Wextra','-Wno-unused-but-set-variable','-Wno-misleading-indentation','-I'+str(d),'-I'+str(root/'runtime'),'-I'+str(root/'build/gen'),str(p),str(root/'runtime/language.c'),'-o',str(d/'test')],check=True)
 subprocess.run([str(d/'test'),str(d),str(root)],check=True)
