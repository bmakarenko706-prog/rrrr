#!/usr/bin/env python3
"""Check every editable JSON value against the real loader using a fake guest heap."""
from pathlib import Path
import json,tempfile,subprocess
root=Path(__file__).resolve().parents[1]
def enc(s):
 b=s.encode('utf-16le');return ''.join(f'{int.from_bytes(b[i:i+2],"little"):04x}' for i in range(0,len(b),2))
def h32(s):
 h=2166136261
 for x in s.encode('utf-16le')[::2] if False else [int.from_bytes(s.encode('utf-16le')[i:i+2],'little') for i in range(0,len(s.encode('utf-16le')),2)]:h=((h^x)*16777619)&0xffffffff
 return h
with tempfile.TemporaryDirectory() as td:
 d=Path(td);loc=d/'localization';loc.mkdir()
 menu=json.loads((root/'localization/ru_menu_draft.json').read_text()); missions=json.loads((root/'localization/ru_missions.json').read_text()); extra=json.loads((root/'localization/ru_extra.json').read_text()); story=json.loads((root/'localization/ru_story.json').read_text())
 expected=[]; commands=[]
 for e in menu['entries']:
  e['russian_draft']='Изм '+e['russian_draft'];commands.append(f'print(ru_sys_string({e["id"]},1));');expected.append(enc(e['russian_draft']))
 for k,key in enumerate(['names','descriptions']):
  for i,s in enumerate(missions[key]):
   missions[key][i]='Изм '+s;commands.append(f'print(ru_mission_string({k},{i//12},{i%12},1));');expected.append(enc(missions[key][i]))
 for k,key in enumerate(['stage','item_name','item_info','file']):
  for id,s in extra[key].items():
   if int(id)>=130:continue
   extra[key][id]='Изм '+s;commands.append(f'print(ru_extra_string({k},{int(id)},1));');expected.append(enc(extra[key][id]))
 for en in story:story[en]='Изм '+story[en]
 for i,en in enumerate(sorted(story,key=h32)):
  commands.append(f'{{const u16 *s=ru_story[{i}].en;unsigned n=0;while(s[n])n++;u32 p=gmalloc((n+1)*2);for(unsigned j=0;j<=n;j++)WR16(p+2*j,s[j]);print(ru_translate_story(p));}}');expected.append(enc(story[en]))
 for n,obj in [('ru_menu_draft.json',menu),('ru_missions.json',missions),('ru_extra.json',extra),('ru_story.json',story)]: (loc/n).write_text(json.dumps(obj,ensure_ascii=False),encoding='utf-8')
 c=r'''#include "rt.h"
#include "ru_story.h"
#include <stdio.h>
static u8 mem[4*1024*1024];u8 *MEM=mem;u32 MEM_SIZE=sizeof mem;char rt_home_dir[256];static u32 top=0x1000;
u32 gmalloc(u32 n){u32 p=top;top=(top+n+3)&~3u;return top<sizeof mem?p:0;}
void rt_log(const char *fmt,...){(void)fmt;}
u32 ru_sys_string(u32,u32);u32 ru_mission_string(u32,u32,u32,u32);u32 ru_extra_string(u32,u32,u32);u32 ru_translate_story(u32);
static void print(u32 p){if(!p){puts("NULL");return;}while(RD16(p)){printf("%04x",RD16(p));p+=2;}puts("");}
int main(int argc,char **argv){if(argc<2)return 2;snprintf(rt_home_dir,sizeof rt_home_dir,"%s",argv[1]);
'''+ '\n'.join(commands)+'\nreturn 0;}\n'
 src=d/'test.c';src.write_text(c);exe=d/'test'
 subprocess.run(['cc','-std=c11','-O1','-I'+str(root/'runtime'),str(src),str(root/'runtime/ru_translate.c'),str(root/'runtime/ru_external.c'),str(root/'runtime/language.c'),'-o',str(exe)],check=True)
 actual=subprocess.check_output([str(exe),str(d)],text=True).splitlines()
 assert len(actual)==len(expected),(len(actual),len(expected))
 for i,(a,b) in enumerate(zip(actual,expected)):
  if a!=b:raise AssertionError(f'entry {i}: actual={a[:100]} expected={b[:100]}')
 print(f'All {len(expected)} modified entries loaded and matched')
