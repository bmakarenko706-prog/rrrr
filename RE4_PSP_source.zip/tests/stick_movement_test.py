#!/usr/bin/env python3
"""Exercise stick mapping with the generated game's virtual-pad routine.

Pad radius and release limit below are fixtures, not extracted game assets;
this does not replace an in-game test on PPSSPP or PSP.
"""
from pathlib import Path
import subprocess
import tempfile

root = Path(__file__).resolve().parents[1]
def extract(path, name):
    text = (root / path).read_text()
    start = text.index('u64 ' + name + '(')
    return text[start:text.index('\n/*', start)]

head = r'''#include "recomp.h"
#include "funcs.h"
#include "stick_movement.h"
#include <assert.h>
#include <stdio.h>
static u8 memory[0x100000]; u8 *const MEM=memory;
static int releases;
u64 F_07215c(u32 a,u32 b,u32 c,u32 d,u32 sp){(void)c;(void)d;(void)sp;releases++;return RV(a,b);}
u64 F_068ca8(u32 a,u32 b,u32 c,u32 d,u32 sp){(void)c;(void)d;(void)sp;return RV(a,b);}
u64 F_067138(u32 a,u32 b,u32 c,u32 d,u32 sp){(void)c;(void)d;(void)sp;return RV(a,b);}
u64 F_0d1e44(u32 a,u32 b,u32 c,u32 d,u32 sp){(void)c;(void)d;(void)sp;return RV(F2U(sqrtf(U2F(a))),b);}
'''
main = r'''
static float feed(float x,float y,float r){
 float dx,dy; stick_movement_offset(x,y,r,&dx,&dy);
 memset(memory,0,sizeof memory); releases=0;
 const u32 p=0x2000, point=0x4000;
 WR32(p+168,76); WR32(p+172,249); WRF(p+180,50); WRF(p+184,60); WRF(p+192,75);
 WR32(p+144,0x3000); WR32(0x3000+68,20); WR32(0x3000+72,20);
 WR32(point,(u32)(int)(76+dx)); WR32(point+4,(u32)(int)(249+dy));
 F_072564(p,point,0,0,0xf0000); assert(!releases); return RDF(p+208);
}
int main(void){
 float straight[][2]={{0,-1},{0,1},{-1,0},{1,0}};
 float diagonal[][2]={{1,1},{1,-1},{-1,1},{-1,-1},{0.707107f,0.707107f}};
 for(int i=0;i<4;i++){float v=feed(straight[i][0],straight[i][1],40); assert(v>40 && v<=51);}
 for(int i=0;i<5;i++){float v=feed(diagonal[i][0],diagonal[i][1],40); assert(v>40 && v<=52);}
 assert(feed(0,-0.5f,40)>0 && feed(0,-0.5f,40)<40);
 assert(feed(0,-1,60)>40 && feed(0,-1,60)<=60);
 float dx,dy;stick_movement_offset(0,-1,40,&dx,&dy);assert(dx==0 && dy==-50);
 puts("Virtual-pad fixtures: full tilt runs straight and diagonally; half tilt walks; legacy radius 40 handled");
}
'''
parts = [extract('build/gen/gen_077.c','F_0d1f98'), extract('build/gen/gen_003.c','F_00cdb4'), extract('build/gen/gen_041.c','F_072564')]
with tempfile.TemporaryDirectory() as td:
    src = Path(td)/'test.c'; exe = Path(td)/'test'
    src.write_text(head + '\n'.join(parts) + main)
    subprocess.run(['cc','-std=c11','-w','-I'+str(root/'runtime'),'-I'+str(root/'build/gen'),str(src),'-lm','-o',str(exe)],check=True)
    subprocess.run([str(exe)],check=True)
s = (root/'runtime/platform_psp.c').read_text()
assert s.count('stick_movement_offset(') == 1
assert s.index('stick_movement_offset(') > s.index('/* finger 0: movement pad;')
print('Movement mapping isolated from cursor and swipe')
