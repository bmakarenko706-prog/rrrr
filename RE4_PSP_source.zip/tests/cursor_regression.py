#!/usr/bin/env python3
"""Check generated-task mapping and actual cursor tick state with host mocks."""
from pathlib import Path
import re, subprocess, tempfile
root=Path(__file__).resolve().parents[1]
p=(root/'runtime/platform_psp.c').read_text()
fn=p[p.index('static int ui_tick_open, ui_tick_menu, ui_tick_language;'):p.index('static int joy_down, swipe_down')]
header=(root/'runtime/ui_cursor.h').read_text()
generated='\n'.join(x.read_text() for x in (root/'build/gen').glob('gen_*.c'))
rows=re.findall(r'case (0x[0-9a-f]+): /\* (\w+) \*/',header)
assert len(rows)>=20
for addr, name in rows:
 match=re.search(r'/\* __ZN\d+Bio4_CTTask_'+name+r'5FrameEPv \*/\s*u64 F_([0-9a-f]+)\(',generated)
 assert match and int(addr,16)==int(match.group(1),16), name
for excluded in ['Title','GameMain','StatusEnd','TitleMovie','GameResult']:
 match=re.search(r'/\* __ZN\d+Bio4_CTTask_'+excluded+r'5FrameEPv \*/\s*u64 F_([0-9a-f]+)\(',generated)
 assert match and int(match.group(1),16) not in [int(a,16) for a,_ in rows]
ui=(root/'runtime/hle_foundation2.c').read_text()
assert 'if (is_game_tick) psp_ui_tick_begin();' in ui and 'if (is_game_tick) psp_ui_tick_end();' in ui
stub='''#include <assert.h>\n#include <stdio.h>\nstatic int psp_cursor_on;\n'''
checks='\n'.join(f'check({a});' for a,_ in rows)
main='''
static void check(unsigned int id) {
 assert(ui_cursor_is_menu_task(id)); psp_ui_tick_begin();
 if (ui_cursor_is_menu_task(id)) psp_ui_tick_note(id);
 psp_ui_tick_end(); assert(psp_cursor_on);
 psp_ui_tick_begin(); psp_ui_tick_end(); assert(!psp_cursor_on);
}
int main(void) {
 psp_ui_tick_note(0); psp_ui_tick_end(); assert(!psp_cursor_on);
'''+checks+'''\nassert(!ui_cursor_is_menu_task(0));
for (unsigned int stage=0; stage<6; stage++)
 assert(ui_cursor_is_title_menu(0x98bf0, stage) == (stage==4));
assert(!ui_cursor_is_title_menu(0x1234,4));
psp_ui_tick_begin(); if (ui_cursor_is_title_menu(0x98bf0,4)) psp_ui_tick_note(0x98bf0);
psp_ui_tick_end(); assert(psp_cursor_on);
psp_ui_tick_begin(); if (ui_cursor_is_title_menu(0x98bf0,1)) psp_ui_tick_note(0x98bf0);
psp_ui_tick_end(); assert(!psp_cursor_on);
puts("Menu classifier and title stages OK"); }\n'''
with tempfile.TemporaryDirectory() as d:
 src=Path(d)/'cursor.c';src.write_text(stub+header+fn+main);exe=Path(d)/'test'
 subprocess.run(['cc','-std=c11','-Wall','-Wextra','-Werror',str(src),'-o',str(exe)],check=True)
 subprocess.run([str(exe)],check=True)
