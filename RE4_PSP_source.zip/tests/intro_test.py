#!/usr/bin/env python3
"""Validate encryption, pixel data and startup animation with host-side PSP mocks."""
from pathlib import Path
import ctypes, importlib.util, re, shutil, struct, subprocess, tempfile, zlib
from PIL import Image
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms
root=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('encoder',root/'tools/encode_intro.py');enc=importlib.util.module_from_spec(spec);spec.loader.exec_module(enc)
blob=(root/'assets/mis_data_m25.bin').read_bytes();assert len(blob)==8+4+480*272*2
nonce=blob[:8];cipher=blob[8:]
ref=Cipher(algorithms.ChaCha20(enc.KEY,bytes(8)+nonce),mode=None).encryptor().update(cipher)
assert enc.crypt(cipher,nonce)==ref
assert struct.unpack('<I',ref[:4])[0]==zlib.crc32(ref[4:]); assert len(set(ref[4:]))>100
img=Image.new('RGB',(480,272));img.putdata([((x&31)*255//31,((x>>5)&63)*255//63,((x>>11)&31)*255//31) for (x,) in struct.iter_unpack('<H',ref[4:])]);img.resize((960,544)).save('/data/re4_intro_preview.png')
with tempfile.TemporaryDirectory() as td:
 d=Path(td); lib=d/'codec.so'
 subprocess.run(['cc','-std=c11','-shared','-fPIC','-Wall','-Wextra','-I'+str(root/'runtime'),str(root/'runtime/intro_codec.c'),'-o',str(lib)],check=True)
 c=ctypes.CDLL(str(lib));c.intro_decode.argtypes=[ctypes.c_void_p,ctypes.c_size_t,ctypes.c_void_p];c.intro_decode.restype=ctypes.c_int
 def decoded(data,nn=nonce,size=None):
  a=ctypes.create_string_buffer(data,len(data));n=ctypes.create_string_buffer(nn,len(nn));ok=c.intro_decode(a,len(data) if size is None else size,n);return ok,a.raw
 ok,raw=decoded(cipher);assert ok and raw==ref
 corrupt=bytearray(cipher);corrupt[812]^=1;assert decoded(bytes(corrupt))[0]==0
 assert decoded(cipher,size=len(cipher)-1)[0]==0
 # Exercise the real startup function and inspect submitted vertices and fade values.
 text=(root/'runtime/intro.c').read_text();const=sorted(set(re.findall(r'\bGU_[A-Z0-9_]+\b',text)))
 funcs=sorted(set(re.findall(r'\b(sceGu\w+)\(',text)) - {'sceGuGetMemory','sceGuDrawArray','sceGuInit','sceGuTerm','sceGuSwapBuffers'})
 (d/'pspgu.h').write_text('\n'.join('#define %s %d'%(x,i+1) for i,x in enumerate(const))+'\n'+'\n'.join('#define %s(...) ((void)0)'%x for x in funcs)+r'''
static int starts, ends, swaps, draws;static unsigned levels[128];static char gu_memory[1024];
static void sceGuInit(void){starts++;} static void sceGuTerm(void){ends++;} static void sceGuSwapBuffers(void){swaps++;}
static void *sceGuGetMemory(int n){(void)n;return gu_memory;}
static void capture(void *v); #define sceGuDrawArray(a,b,c,d,v) capture(v)
'''.replace('static void capture(void *v); #define','static void capture(void *v);\n#define'))
 (d/'pspdisplay.h').write_text('#define sceDisplayWaitVblankStart() ((void)0)\n')
 (d/'pspkernel.h').write_text(r'''
#define sceKernelDcacheWritebackRange(...) ((void)0)
#define sceKernelDcacheWritebackInvalidateRange(...) ((void)0)
static unsigned long long fake_time;static volatile int *quitptr;static int quit_after;
static unsigned long long sceKernelGetSystemTimeWide(void){fake_time+=100000; if(quitptr && quit_after && fake_time>=(unsigned long long)quit_after)*quitptr=1;return fake_time;}
''')
 test=r'''
#include <assert.h>
#include <stdarg.h>
void rt_log(const char *x,...){(void)x;}
#include "intro.c"
static void capture(void *p){vertex *v=p;assert(v[0].color==v[1].color);levels[draws++]=v[0].color&255;assert(v[0].x==0 && v[1].x==480 && v[1].y==272);}
int main(int argc,char**argv){assert(argc==2);volatile int q=0;
 intro_show(argv[1],&q);assert(starts==1&&ends==1&&draws>20&&swaps==draws+1);
 assert(levels[0]<levels[5] && levels[5]<levels[9]);assert(levels[9]==255 && levels[15]==255);assert(levels[20]>levels[25]);
 int previous=draws; intro_show("/missing-intro-test",&q);assert(starts==1&&draws==previous);
 fake_time=0;quitptr=&q;quit_after=400000;intro_show(argv[1],&q);assert(q && starts==2&&ends==2 && draws-previous<5);
 puts("Intro asset validation, preloading, fade sequence, missing-file fallback, and exit path passed with mock PSP renderer.");
}
'''
 (d/'test.c').write_text(test);shutil.copy(root/'assets/mis_data_m25.bin',d/'mis_data_m25.bin')
 subprocess.run(['cc','-std=c11','-Wall','-Wextra','-Wno-unused-variable','-I'+str(d),'-I'+str(root/'runtime'),'-I'+str(root/'build/gen'),str(d/'test.c'),str(root/'runtime/intro_codec.c'),'-o',str(d/'test')],check=True)
 subprocess.run([str(d/'test'),str(d)],check=True)
print('ChaCha20 matches independent implementation, CRC catches corruption, image decodes to 480x272.')
