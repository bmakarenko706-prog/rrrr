#!/usr/bin/env python3
"""Test actual deferred movie queue/play code with host mocks, not full PSP."""
from pathlib import Path
import subprocess,tempfile
s=(Path(__file__).resolve().parents[1]/'runtime/hle_uikit.c').read_text()
queue=s[s.index('static const char *MP_FINISHED'):s.index('/* ---------- UIApplication:')]
mp=s[s.index('NM(mp_init)'):s.index('NM(mp_setmode)')]
stub=r'''
void startup_pack_report(void) {}
void bundle_stat_stop(void) {}

#include <assert.h>
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
typedef unsigned int u32;typedef unsigned long long u64;
#define RE4_PSP 1
#define NM(name) static u64 name(u32 self,u32 _cmd,u32 a2,u32 a3,u32 sp)
#define UNUSED_ARGS (void)self;(void)_cmd;(void)a2;(void)a3;(void)sp
#define RET(x) return (x)
static u32 mem[256], refs[256];static int plays,finished,preloaded,replay_on_finish,missing;
#define WR32(a,v) (mem[(a)/4]=(v))
#define RD32(a) (mem[(a)/4])
static u32 objc_retain(u32 x){if(x)refs[x]++;return x;}
static void objc_release(u32 x){if(x){assert(refs[x]>0);refs[x]--;}}
static const char* objc_nsstring_cstr(u32 x){(void)x;return "res4.m4v";}
static int psp_movie_play(const char *s){assert(s && strcmp(s,"res4.m4v")==0);plays++;return !missing;}
static void rt_log(const char *s,...){(void)s;}
static void plat_exit_trace(const char *s){(void)s;}
static void post_notification(u32 sp,const char *name,u32 obj);
'''
main=r'''
static void post_notification(u32 sp,const char *name,u32 obj){
 (void)sp;if(strstr(name,"Preload")){preloaded++;mp_play(obj,0,0,0,0);}
 else if(strstr(name,"Finish")){finished++;if(replay_on_finish){replay_on_finish=0;mp_play(obj,0,0,0,0);}}
}
static void ticks(int n){while(n--)run_pending(0);}
int main(void){
 u32 p=40,q=80;WR32(p+4,120);WR32(124,1);WR32(q+4,120);refs[p]=refs[q]=1;
 /* Direct play cancels queued preload; both duplicate calls before and after
    playback are ignored until delivery of completion. */
 post_later(MP_PRELOADED,p,1);mp_play(p,0,0,0,0);mp_play(p,0,0,0,0);
 assert(!plays&&npend==1&&RD32(p+16)==1);ticks(1);
 assert(plays==1&&finished==0&&RD32(p+16)==2);mp_play(p,0,0,0,0);
 ticks(4);assert(plays==1&&finished==1&&preloaded==0&&refs[p]==1&&!npend&&RD32(p+16)==0);
 /* An intentional later replay works. */
 mp_play(p,0,0,0,0);ticks(5);assert(plays==2&&finished==2&&refs[p]==1);
 /* Preload-led playback still works and starts after observer returns. */
 post_later(MP_PRELOADED,p,0);ticks(5);assert(plays==3&&finished==3&&preloaded==1&&refs[p]==1);
 /* Other players are independent, even for the same asset. */
 post_later(MP_PRELOADED,p,1);post_later(MP_PRELOADED,q,1);mp_play(p,0,0,0,0);ticks(6);
 assert(plays==5&&finished==5&&preloaded==2&&refs[p]==1&&refs[q]==1&&!npend);
 /* Stopping a pending start prevents playback and releases its retain. */
 mp_play(p,0,0,0,0);mp_stop(p,0,0,0,0);ticks(5);assert(plays==5&&finished==5&&refs[p]==1&&!npend);
 /* Stopping after playback cancels stale completion; the next play is valid. */
 mp_play(p,0,0,0,0);ticks(1);assert(plays==6);mp_stop(p,0,0,0,0);mp_play(p,0,0,0,0);ticks(5);
 assert(plays==7&&finished==6&&refs[p]==1&&!npend);
 /* Completion callback can explicitly request a fresh replay. */
 replay_on_finish=1;mp_play(p,0,0,0,0);ticks(10);assert(plays==9&&finished==8&&refs[p]==1&&!npend);
 /* Missing/corrupt video should still generate completion. */
 missing=1;mp_play(p,0,0,0,0);ticks(5);assert(plays==10&&finished==9&&refs[p]==1&&!npend);
 puts("Deferred movie start, duplicate requests, stop, replay, missing file, two players, references OK");
}
'''
with tempfile.TemporaryDirectory() as d:
 p=Path(d);(p/'t.c').write_text(stub+queue+mp+main)
 subprocess.run(['cc','-std=c11','-Wall','-Wextra','-Wno-unused-function','-Werror',str(p/'t.c'),'-o',str(p/'t')],check=True)
 subprocess.run([str(p/'t')],check=True)
