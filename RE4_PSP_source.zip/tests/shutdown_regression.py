#!/usr/bin/env python3
"""Exercise PSP shutdown logic with host stubs; not a PSP or full-game test."""
from pathlib import Path
import subprocess, tempfile
root = Path(__file__).resolve().parents[1]
p = (root/'runtime/platform_psp.c').read_text()
fn = p[p.index('static void shutdown_audio(void)'):p.index('/* ---------- start-up */')]
ui = (root/'runtime/hle_uikit.c').read_text()
assert 'plat_exit_trace("guest: applicationWillTerminate returned")' in ui
assert '/* Return through guest main to the platform for orderly shutdown. */\n    RET(0);' in ui
stub = r'''
#include <assert.h>
#include <stdarg.h>
#include <stdio.h>
typedef unsigned int u32; typedef unsigned int SceUInt;
static volatile int quit_req; static int audio_th, audio_src, a_ch;
static int result, wait_count, del_count, src_count, ch_count, music_count;
static int sceKernelWaitThreadEnd(int th, SceUInt *t) { assert(quit_req==1 && th==42 && *t==1000000); wait_count++; return result; }
static void sceKernelDeleteThread(int th) {assert(th==42); del_count++;}
static void sceAudioSRCChRelease(void) {src_count++;}
static void sceAudioChRelease(int ch) {assert(ch==3); ch_count++;}
static void music_shutdown(void) {music_count++;}
static void rt_log(const char *fmt, ...) {(void)fmt;}
static void plat_exit_trace(const char *s) {(void)s;}
'''
main = r'''
int main(void) {
 audio_th=42; audio_src=1; a_ch=-1; result=0; shutdown_audio();
 assert(wait_count==1 && del_count==1 && src_count==1 && !ch_count && music_count==1);
 quit_req=0; wait_count=del_count=src_count=ch_count=music_count=0;
 result=-1; shutdown_audio(); assert(wait_count==1 && !del_count && !src_count && !music_count);
 quit_req=0; wait_count=0; audio_th=-1; audio_src=0; a_ch=3; shutdown_audio();
 assert(!wait_count && ch_count==1 && music_count==1);
 puts("Shutdown ordering, timeout and no-thread paths OK");
}
'''
with tempfile.TemporaryDirectory() as d:
    src=Path(d)/'t.c'; src.write_text(stub+fn+main)
    exe=Path(d)/'test'
    subprocess.run(['cc','-std=c11','-Wall','-Wextra','-Werror',str(src),'-o',str(exe)],check=True)
    subprocess.run([str(exe)],check=True)
