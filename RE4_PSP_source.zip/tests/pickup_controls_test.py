#!/usr/bin/env python3
"""Execute actual PSP poll/UI code with synthetic guest layouts, not actual game assets."""
from pathlib import Path
import subprocess,tempfile
root=Path(__file__).resolve().parents[1]
p=(root/'runtime/platform_psp.c').read_text()
binds=p[p.index('enum { B_CROSS'):p.index('/* scripted touches')]
ui=p[p.index('static int gok('):p.index('static float clampf(')]
poll=p[p.index('static float clampf('):p.index('/* Called after the guest has stopped using audio')]
pre=r'''#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
typedef uint8_t u8; typedef int16_t s16; typedef uint16_t u16; typedef uint32_t u32; typedef uint64_t u64;
#include "weapon_hold.h"
#include "stick_movement.h"
#define PSP_CTRL_CROSS (1u<<0)
#define PSP_CTRL_CIRCLE (1u<<1)
#define PSP_CTRL_SQUARE (1u<<2)
#define PSP_CTRL_TRIANGLE (1u<<3)
#define PSP_CTRL_START (1u<<4)
#define PSP_CTRL_SELECT (1u<<5)
#define PSP_CTRL_LTRIGGER (1u<<6)
#define PSP_CTRL_RTRIGGER (1u<<7)
#define PSP_CTRL_UP (1u<<8)
#define PSP_CTRL_DOWN (1u<<9)
#define PSP_CTRL_LEFT (1u<<10)
#define PSP_CTRL_RIGHT (1u<<11)
#define PLAT_QUIT 1
#define PLAT_RUN 0
static u8 memory[0x100000]; static u8 *MEM=memory; static u32 MEM_SIZE=sizeof memory;
static u32 RD32(u32 p){u32 v;memcpy(&v,MEM+p,4);return v;}
static u16 RD16(u32 p){u16 v;memcpy(&v,MEM+p,2);return v;}
#define RD8(p) (MEM[p])
static void wr32(u32 p,u32 v){memcpy(MEM+p,&v,4);}
static void wr16(u32 p,u16 v){memcpy(MEM+p,&v,2);}
typedef struct{int down;float x,y;}plat_touch;
typedef struct{plat_touch touch[3];}plat_input;
typedef struct {u32 Buttons; u8 Lx,Ly;}SceCtrlData;
static SceCtrlData pad_state={0,128,128};
static void sceCtrlPeekBufferPositive(SceCtrlData *p,int n){(void)n;*p=pad_state;}
static u64 clocktime; static u64 plat_time_us(void){clocktime+=50000;return clocktime;}
static void rt_log(const char *f,...){(void)f;}
static int quit_req, psp_cursor_on,rt_verbose; static float psp_cursor_x=240,psp_cursor_y=160;
static int joy_down,swipe_down,finger_src[3]={-1,-1,-1};static float swipe_x,swipe_y;static u32 prev_buttons,transition_blocked;static int a_reset;static u64 last_poll;
static int deadzone=32;
static int manual_active, manual_events; static u32 manual_last;
static int manual_is_open(void){return manual_active;}
static void manual_handle(u32 p){manual_events++;manual_last=p;if(p & PSP_CTRL_CIRCLE) manual_active=0;}
static void land2port(float X,float Y,plat_touch *t){t->down=1;t->x=320-Y;t->y=X;}
#define SRC_SWIPE NB
#define SRC_CURSOR (NB+1)
#define SRC_SCRIPT (NB+2)
#define SRC_WEAPON (NB+3)
#define NSRC (NB+4)
'''
mid=r'''
typedef struct {float t,dur,x,y;}tap; static tap taps[64];static int ntaps;
'''
main=r'''
static void component(u32 root,u32 arr,int i,u32 c,u32 rect,int x,int y){
 wr32(arr+i*4,c);wr32(c+8,rect);MEM[c+80]=MEM[c+81]=1;
 wr16(rect+16,x);wr16(rect+18,y);wr16(rect+20,20);wr16(rect+22,20);
}
static int got(plat_input *p,int x,int y){for(int i=1;i<3;i++)if(p->touch[i].down && p->touch[i].x==320-(y+10) && p->touch[i].y==x+10)return 1;return 0;}
static plat_input poll(u32 b){plat_input p;pad_state.Buttons=b;plat_poll(&p);return p;}
int main(void){
 u32 in=0x2000,iroot=0x3000,iarr=0x4000,ash=0x5000,ar=0x6000;
 wr32(0xdd750,in);MEM[in+60]=1;wr32(in,iroot);MEM[iroot+81]=1;wr32(iroot+12,iarr);wr32(iroot+24,1);wr32(in+16,ash);component(iroot,iarr,0,ash,ar,300,100);
 plat_input v=poll(PSP_CTRL_CIRCLE);assert(got(&v,300,100));poll(0);
 u32 item=0x7000,root=0x8000,arr=0x9000,lay=0xa000;
 wr32(0xddd98,item);MEM[item+32]=1;wr32(item+4,root);MEM[root+81]=1;wr32(root+12,arr);wr32(root+24,3);wr32(0xdd740,lay);wr32(lay+76,2);
 u32 get=0xb000,use=0xc000,cancel=0xd000;wr32(item+16,get);wr32(item+12,use);wr32(item+20,cancel);
 component(root,arr,0,get,0xe000,100,60);component(root,arr,1,use,0xe100,200,60);component(root,arr,2,cancel,0xe200,300,60);
 poll(0); v=poll(PSP_CTRL_CROSS);assert(got(&v,100,60));poll(0);
 v=poll(PSP_CTRL_SQUARE);assert(got(&v,200,60));assert(!got(&v,300,100));poll(0);
 v=poll(PSP_CTRL_CIRCLE);assert(got(&v,300,60));assert(!got(&v,300,100));poll(0);
 MEM[use+81]=0;v=poll(PSP_CTRL_SQUARE);for(int i=1;i<3;i++)assert(!v.touch[i].down);poll(0);
 MEM[item+32]=0;v=poll(PSP_CTRL_CIRCLE);assert(!got(&v,300,100));poll(0);v=poll(PSP_CTRL_CIRCLE);assert(got(&v,300,100));
 poll(0);manual_active=1;
 v=poll(PSP_CTRL_CROSS);assert(manual_last==0);for(int i=0;i<3;i++)assert(!v.touch[i].down);
 poll(PSP_CTRL_CROSS);assert(manual_last==0);poll(0);poll(PSP_CTRL_CROSS);assert(manual_last==PSP_CTRL_CROSS);
 poll(0);v=poll(PSP_CTRL_CIRCLE);assert(!manual_active);for(int i=0;i<3;i++)assert(!v.touch[i].down);
 v=poll(PSP_CTRL_CIRCLE);for(int i=0;i<3;i++)assert(!v.touch[i].down);poll(0);
 v=poll(PSP_CTRL_CIRCLE);assert(got(&v,300,100));
 puts("Pickup fixtures: X=get, square=use only if visible, circle=cancel, Ashley restored; mode transition blocks holds");
}
'''
with tempfile.TemporaryDirectory() as d:
 s=Path(d)/'t.c'; e=Path(d)/'t';s.write_text(pre+binds+mid+ui+poll+main)
 subprocess.run(['cc','-std=c11','-w','-I'+str(root/'runtime'),str(s),'-lm','-o',str(e)],check=True)
 subprocess.run([str(e)],check=True)
