#include <stdint.h>
#include <assert.h>
#include <stdio.h>
typedef uint64_t u64;
#include "../runtime/weapon_hold.h"
int main(void) {
 weapon_hold w = {0}; int t;
 w.owned=1;
 t=wh_decide(&w,1000000,1,WH_GUN,1,1,1,0,0); assert(t==WH_GUN); wh_begin(&w,1000000);
 assert(wh_decide(&w,1050000,1,WH_NONE,1,1,1,0,0)==WH_NONE); /* fast release doesn't truncate tap */
 assert(wh_decide(&w,1200000,1,WH_NONE,1,1,1,1,0)==WH_NONE); /* release gap */
 t=wh_decide(&w,1350000,1,WH_NONE,1,1,1,1,0); assert(t==WH_LOWER); wh_begin(&w,1350000);
 assert(wh_decide(&w,1700000,1,WH_NONE,1,1,1,0,0)==WH_NONE);
 t=wh_decide(&w,1800000,1,WH_KNIFE,1,1,1,0,0);assert(t==WH_KNIFE);wh_begin(&w,1800000);
 assert(wh_decide(&w,2150000,1,WH_KNIFE,1,1,1,0,1)==WH_NONE); /* hold */
 t=wh_decide(&w,2200000,1,WH_GUN,1,1,1,0,1);assert(t==WH_GUN);wh_begin(&w,2200000);
 t=wh_decide(&w,2550000,1,WH_KNIFE,1,1,1,1,0);assert(t==WH_KNIFE);wh_begin(&w,2550000);
 assert(wh_decide(&w,2900000,0,WH_NONE,1,1,1,0,1)==WH_NONE); /* menu / cursor */
 assert(wh_decide(&w,2900000,1,WH_NONE,1,1,1,0,1)==WH_LOWER);
 w.owned=0; assert(wh_decide(&w,3000000,1,WH_NONE,1,1,1,1,0)==WH_NONE);
 puts("weapon hold, release, switch and menu guard OK");
 return 0;
}
