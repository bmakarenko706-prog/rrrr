#!/usr/bin/env python3
"""Exercise editable name_en, legacy files, empty values, and invalid JSON."""
from pathlib import Path
import subprocess,tempfile,json
r=Path(__file__).resolve().parents[1]
c=r'''
#include "rt.h"
#include "language.h"
#include <assert.h>
#include <stdio.h>
static u8 memory[1048576];u8 *MEM=memory;u32 MEM_SIZE=sizeof memory;char rt_home_dir[256];static u32 top=0x1000;
u32 gmalloc(u32 n){u32 p=top;top=(top+n+3)&~3u;return p;}
void rt_log(const char*f,...){(void)f;}
u32 ru_sys_string(u32,u32);
static void check(u32 p,const char*s){for(unsigned i=0;;i++){assert(RD16(p+2*i)==(unsigned char)s[i]);if(!s[i])break;}}
int main(int argc,char**argv){assert(argc==3);snprintf(rt_home_dir,sizeof rt_home_dir,"%s",argv[1]);language_init(argv[1]);language_set_guest(1);language_menu_begin();
 assert(RD16(ru_sys_string(193,1))=='E');assert(language_menu_commit(1,0)==1);check(ru_sys_string(198,1),argv[2]);
 language_set_guest(3);check(ru_sys_string(198,3),argv[2]);assert(language_menu_commit(0,1)==1);language_set_guest(1);assert(RD16(ru_sys_string(198,1))==0x420);
 puts("language label and font-mode fallback OK");}
'''
with tempfile.TemporaryDirectory() as td:
 d=Path(td);(d/'t.c').write_text(c);exe=d/'t';subprocess.run(['cc','-std=c11','-I'+str(r/'runtime'),str(d/'t.c'),str(r/'runtime/language.c'),str(r/'runtime/ru_translate.c'),str(r/'runtime/ru_external.c'),'-o',str(exe)],check=True)
 cases=[('{"name":"РУССКИЙ", "name_en":"UKRAINIAN"}','UKRAINIAN'),('{"name":"РУССКИЙ"}','RUSSIAN'),('{"name":"РУССКИЙ", "name_en":""}','RUSSIAN'),('{broken','RUSSIAN'),(None,'RUSSIAN')]
 for i,(content,expected) in enumerate(cases):
  p=d/str(i);p.mkdir();(p/'localization').mkdir();(p/'ru_font_U16le.fnt').write_bytes(b'test')
  if content is not None:(p/'localization/language.json').write_text(content,encoding='utf-8')
  subprocess.run([str(exe),str(p),expected],check=True)
print('name_en with custom, legacy, empty, invalid and missing files OK')
