#!/usr/bin/env python3
"""Exercise real PSP NSFileHandle cache code using host mocks and files."""
import pathlib, subprocess, tempfile
p=pathlib.Path(__file__).resolve().parents[1]/'runtime/hle_foundation2.c'
s=p.read_text()
cache=s[s.index('#ifdef RE4_PSP\n/* Only'):s.index('/* ---------- NSFileManager */')]
fh=s[s.index('/* ---------- NSFileHandle'):s.index('static nmdef fh_im[]')]
header=r'''
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include <stdlib.h>
#include <assert.h>
typedef uint32_t u32; typedef uint64_t u64;
#define RE4_PSP 1
#define NM(n) static u64 n(u32 self,u32 _cmd,u32 a2,u32 a3,u32 sp)
#define UNUSED_ARGS (void)self;(void)_cmd;(void)a2;(void)a3;(void)sp
#define RET(x) return (u64)(u32)(x)
static unsigned char memory[8*1024*1024], *MEM=memory;
#define RD32(x) (*(u32*)(MEM+(x)))
#define WR32(x,v) (*(u32*)(MEM+(x))=(v))
static char rt_bundle_dir[256],rt_home_dir[256]; static int rt_verbose;
static u32 nextmem=65536,nextobj=1024; static int fail_alloc;
u32 heap_free_bytes(void){return 4*1024*1024;}
u32 gmalloc(u32 n){if(fail_alloc){fail_alloc=0;return 0;}u32 x=nextmem;nextmem+=(n+7)&~7; assert(nextmem<sizeof memory);return x;}
void gfree(u32 p){(void)p;}
void rt_log(const char *s,...){(void)s;}
int language_use_russian_font(void){return 0;}
void bundle_stat_invalidate(const char *p){(void)p;}
int startup_pack_find(const char *p){(void)p;return -1;}
void startup_pack_invalidate(const char *p){(void)p;}
unsigned startup_pack_size(int i){(void)i;return 0;}
int startup_pack_read(int i,unsigned p,void*d,unsigned n){(void)i;(void)p;(void)d;(void)n;return -1;}
const char *startup_pack_path(int i){(void)i;return 0;}
u32 objc_new(u32 cls){(void)cls;u32 o=nextobj;nextobj+=16;return o;}
u32 objc_autorelease(u32 o){return o;}
void objc_dealloc_raw(u32 o){(void)o;}
const char *objc_nsstring_cstr(u32 o){return (char*)MEM+o;}
u32 nsdata_new(u32 b,u32 n,int own){(void)own;u32 o=objc_new(1);WR32(o+4,b);WR32(o+8,n);return o;}
'''
main=r'''
int main(int argc,char**argv){
 snprintf(rt_bundle_dir,sizeof rt_bundle_dir,"%s",argv[1]);
 char path[512];snprintf(path,sizeof path,"%s/common.h2z",argv[1]);
 if(argc>2 && !strcmp(argv[2],"fail")) fail_alloc=1;
 u32 a=fh_open(1,path,"rb"), b=fh_open(1,path,"rb"); assert(a&&b);
 int cached=fh_cached[RD32(a+4)];
 if(argc>2) assert(!cached); else assert(cached);
 u32 d=(u32)fh_readlen(a,0,100,0,0); assert(RD32(d+8)==100);
 for(int i=0;i<100;i++) assert(MEM[RD32(d+4)+i]==(i%251));
 fh_seek(a,0,1000,0,0); d=(u32)fh_readlen(a,0,50,0,0);
 for(int i=0;i<50;i++)assert(MEM[RD32(d+4)+i]==((1000+i)%251));
 assert(fh_offset(b,0,0,0,0)==0 && fh_offset(a,0,0,0,0)==1050);
 assert(fh_seekend(b,0,0,0,0)==123456); assert(fh_offset(b,0,0,0,0)==123456);
 d=(u32)fh_readlen(b,0,10,0,0);assert(RD32(d+8)==0);
 fh_close(a,0,0,0,0); fh_close(b,0,0,0,0);
 if(cached){ common_invalidate(path); assert(!common_cache_valid); a=fh_open(1,path,"rb");assert(a&&!fh_cached[RD32(a+4)]);fh_close(a,0,0,0,0); }
 return 0;
}
'''
with tempfile.TemporaryDirectory() as td:
 d=pathlib.Path(td); (d/'t.c').write_text(header+cache+fh+main)
 (d/'common.h2z').write_bytes(bytes(i%251 for i in range(123456)))
 subprocess.run(['cc','-std=c99','-w',str(d/'t.c'),'-o',str(d/'test')],check=True)
 for mode in ([],['fail']):subprocess.run([str(d/'test'),td,*mode],check=True)
print('common.h2z cache: data, independent offsets, EOF, invalidation and allocation fallback OK')
