/* RE4 PSP runtime: shared definitions for HLE (high-level emulation) code. */
#ifndef RT_H
#define RT_H
#define RC_RUNTIME 1
#include "recomp.h"
#include "rc_tables.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>

extern u8 *MEM;
extern u32 MEM_SIZE;
#define IMPORT(name) u64 IMP_##name(u32 r0, u32 r1, u32 r2, u32 r3, u32 sp)
#define SARG(i) RD32A(sp + 4 * (i))          /* i-th stack argument */
#define RET(x) return (u64)(u32)(x)
#define RETD(d) return D2U(d)
#define RETF(f) return (u64)F2U(f)
#define GSTR(g) ((char *)(MEM + (g)))
#define HPTR(g) ((void *)(MEM + (g)))
#define GPTR(h) ((u32)((u8 *)(h) - MEM))

/* logging */
void rt_log(const char *fmt, ...) __attribute__((format(printf, 1, 2)));
extern int rt_log_enabled;
void rt_fatal(const char *fmt, ...) __attribute__((format(printf, 1, 2), noreturn));
extern int rt_verbose;
extern int rt_target_fps; /* Host debug target; PSP always uses 23 Hz. */

/* guest heap */
void heap_init(u32 lo, u32 hi);
void heap_add(u32 lo, u32 hi);
u32 gmalloc(u32 n);
u32 gcalloc(u32 n);
u32 grealloc(u32 p, u32 n);
void gfree(u32 p);
u32 heap_free_bytes(void);
u32 heap_min_free(void);
u32 gstrdup(const char *s);
u32 gmemdup(const void *p, u32 n);

/* calling guest code */
u64 rc_call(u32 fn, u32 r0, u32 r1, u32 r2, u32 r3, u32 sp);
extern u32 rt_cb_sp;          /* guest sp for callbacks from the host run loop */
u32 rt_import_addr(const char *name);
void rt_register_data(const char *name, u32 gaddr);
u32 rt_find_func(const char *sym);   /* guest address of a game function by name (0 if none) */

/* platform layer */
extern char rt_bundle_dir[256];     /* folder with the .app contents (assets + Res4) */
extern char rt_docs_dir[256];
void plat_init(int argc, char **argv);
u64 plat_time_us(void);
void plat_sleep_us(u32 us);
extern u64 rt_idle_us;   /* time the main loop spent sleeping between game timers */
void plat_present(void);

/* subsystems */
void objc_init(void);
void objc_bind_classes(void);
void cxx_init(void);
void libc_init(void);
void uikit_main(u32 sp);           /* UIApplicationMain implementation: nib setup + run loop */
#endif
