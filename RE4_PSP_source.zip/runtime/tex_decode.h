#ifndef TEX_DECODE_H
#define TEX_DECODE_H
#include "recomp.h"
/* decoders produce RGBA8 (r,g,b,a byte order) */
void pvrtc_decode(const u8 *src, int w, int h, int bpp2, u8 *rgba);
/* OES_compressed_paletted_texture: fmt 0x8B90..0x8B99, level 0 only; returns 0 if unsupported */
int palette_decode(u32 fmt, const u8 *src, int w, int h, u8 *rgba);
int palette_info(u32 fmt, int *bits, int *entry_bytes);
/* palette entries as RGBA8 words (r in the low byte, = GE 8888); 16 or 256 entries */
void palette_rgba(u32 fmt, const u8 *src, u32 *pal);
/* PVRTC into a 16-bit GE texture (4444 when alpha, else 5650) keeping every (1 << shift)-th texel;
   pitch in bytes; swizzled layout when swz */
void pvrtc_decode16(const u8 *src, int w, int h, int bpp2, int shift, int alpha, u8 *out, int pitch, int swz);
/* byte offset of (x bytes, y) in a GE swizzled texture with the given row pitch */
u32 tex_swz_off(u32 xb, u32 y, u32 pitch);
#endif
