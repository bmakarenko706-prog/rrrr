/* Minimal Objective-C 2 runtime for the recompiled game: game classes come from the binary,
   system classes (Foundation/UIKit/...) are "native" classes implemented in C. */
#ifndef OBJC_H
#define OBJC_H
#include "rt.h"
typedef u64 (*nmeth)(u32 self, u32 sel, u32 a2, u32 a3, u32 sp);
typedef struct { const char *name; nmeth fn; u32 sel; } nmdef;
typedef struct nclass {
    const char *name, *super;
    nmdef *im, *cm;              /* instance / class methods, terminated by {0} */
    u32 isize;                   /* bytes from isa (offset 0) */
    u32 cls, meta; int idx;
} nclass;
#define NM(n) static u64 n(u32 self, u32 _cmd, u32 a2, u32 a3, u32 sp)
#define UNUSED_ARGS (void)self; (void)_cmd; (void)a2; (void)a3; (void)sp
void objc_add_classes(nclass *list);     /* NULL-name terminated; call from *_classes() hooks */
u32 objc_class_named(const char *name);
u32 objc_new(u32 cls);                   /* alloc+zero, retain count 1 */
u32 objc_new_named(const char *name);
u32 sel_named(const char *s);
const char *sel_name(u32 sel);
u64 objc_send(u32 sp, u32 obj, u32 sel, u32 a2, u32 a3);
u64 objc_send_s(u32 obj, const char *sel, u32 a2, u32 a3);   /* from host code, uses rt_cb_sp */
int objc_responds(u32 obj, u32 sel);
u32 objc_retain(u32 o);
void objc_release(u32 o);
u32 objc_autorelease(u32 o);
void objc_drain_pool(void);
void objc_set_sp(u32 sp);               /* host loop: declare the guest sp in use before sending messages */
u32 objc_isa(u32 o);
int objc_is_kind(u32 o, u32 cls);
const char *objc_class_name(u32 cls);
void objc_dealloc_raw(u32 o);            /* NSObject -dealloc */
/* NSString helpers (hle_foundation.c) */
u32 nsstr(const char *s);                /* autoreleased */
u32 nsstr_owned(const char *s);          /* retain count 1 */
const char *objc_nsstring_cstr(u32 o);
u32 nsdata_new(u32 bytes, u32 len, int owned);
u32 nsarray_new(void);
void nsarray_add(u32 arr, u32 obj);
u32 nsnumber_bool(int b);
void post_notification(u32 sp, const char *name, u32 object);
#endif
