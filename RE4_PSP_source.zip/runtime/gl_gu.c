/* OpenGL ES 1.1 on the PSP GE (libpspgu): the subset RE4 Mobile Edition uses (the 67 entry points of gl_host.c).
   The game renders a 320x480 portrait framebuffer that the iPhone shows in landscape. Here the picture goes
   straight to the PSP's landscape screen: the rotation, the GL viewport and the scaling to 408x272 (or 480x272)
   are folded into the GE projection matrix; GL depth is inverted (GE convention: near = 65535); geometry that
   crosses the near plane or would leave the GE's 4096x4096 drawing space is clipped on the CPU.
   Textures: OES paletted -> T8/T4 + CLUT, PVRTC -> 4444/5650, uncompressed -> the nearest GE format; swizzled,
   downscaled to at most psp_tex_limit (PVRTC), psp_tex_limit_pal (paletted) or 512 (others), kept in VRAM while it has room. */
#include "rt.h"
#include "funcs.h"
#include "tex_decode.h"
#include "psp_glue.h"
#include "language.h"
#include "manual.h"
#include <pspkernel.h>
#include <malloc.h>
#include <pspge.h>
#include <pspgu.h>
#include <pspdisplay.h>
#include <string.h>
#include <stdint.h>
#include <math.h>
#include "fog_affine.h"

/* ---------- GL enums */
#define GL_POINTS 0x0000
#define GL_LINES 0x0001
#define GL_LINE_LOOP 0x0002
#define GL_LINE_STRIP 0x0003
#define GL_TRIANGLES 0x0004
#define GL_TRIANGLE_STRIP 0x0005
#define GL_TRIANGLE_FAN 0x0006
#define GL_ZERO 0
#define GL_ONE 1
#define GL_SRC_COLOR 0x0300
#define GL_ONE_MINUS_SRC_COLOR 0x0301
#define GL_SRC_ALPHA 0x0302
#define GL_ONE_MINUS_SRC_ALPHA 0x0303
#define GL_DST_ALPHA 0x0304
#define GL_ONE_MINUS_DST_ALPHA 0x0305
#define GL_DST_COLOR 0x0306
#define GL_ONE_MINUS_DST_COLOR 0x0307
#define GL_NEVER 0x0200
#define GL_LESS 0x0201
#define GL_LEQUAL 0x0203
#define GL_GREATER 0x0204
#define GL_GEQUAL 0x0206
#define GL_ALWAYS 0x0207
#define GL_FRONT 0x0404
#define GL_BACK 0x0405
#define GL_FRONT_AND_BACK 0x0408
#define GL_CW 0x0900
#define GL_CCW 0x0901
#define GL_CULL_FACE 0x0B44
#define GL_LIGHTING 0x0B50
#define GL_LIGHT_MODEL_TWO_SIDE 0x0B52
#define GL_LIGHT_MODEL_AMBIENT 0x0B53
#define GL_COLOR_MATERIAL 0x0B57
#define GL_FOG 0x0B60
#define GL_FOG_DENSITY 0x0B62
#define GL_FOG_START 0x0B63
#define GL_FOG_END 0x0B64
#define GL_FOG_MODE 0x0B65
#define GL_FOG_COLOR 0x0B66
#define GL_DEPTH_TEST 0x0B71
#define GL_NORMALIZE 0x0BA1
#define GL_VIEWPORT 0x0BA2
#define GL_ALPHA_TEST 0x0BC0
#define GL_DITHER 0x0BD0
#define GL_BLEND 0x0BE2
#define GL_SCISSOR_BOX 0x0C10
#define GL_SCISSOR_TEST 0x0C11
#define GL_UNPACK_ALIGNMENT 0x0CF5
#define GL_MAX_LIGHTS 0x0D31
#define GL_MAX_TEXTURE_SIZE 0x0D33
#define GL_MAX_MODELVIEW_STACK_DEPTH 0x0D36
#define GL_MAX_PROJECTION_STACK_DEPTH 0x0D38
#define GL_MAX_TEXTURE_STACK_DEPTH 0x0D39
#define GL_MAX_VIEWPORT_DIMS 0x0D3A
#define GL_TEXTURE_2D 0x0DE1
#define GL_BYTE 0x1400
#define GL_UNSIGNED_BYTE 0x1401
#define GL_SHORT 0x1402
#define GL_UNSIGNED_SHORT 0x1403
#define GL_FLOAT 0x1406
#define GL_FIXED 0x140C
#define GL_AMBIENT 0x1200
#define GL_DIFFUSE 0x1201
#define GL_SPECULAR 0x1202
#define GL_POSITION 0x1203
#define GL_SPOT_DIRECTION 0x1204
#define GL_SPOT_EXPONENT 0x1205
#define GL_SPOT_CUTOFF 0x1206
#define GL_CONSTANT_ATTENUATION 0x1207
#define GL_LINEAR_ATTENUATION 0x1208
#define GL_QUADRATIC_ATTENUATION 0x1209
#define GL_EMISSION 0x1600
#define GL_SHININESS 0x1601
#define GL_AMBIENT_AND_DIFFUSE 0x1602
#define GL_MODELVIEW 0x1700
#define GL_PROJECTION 0x1701
#define GL_TEXTURE 0x1702
#define GL_ALPHA 0x1906
#define GL_RGB 0x1907
#define GL_RGBA 0x1908
#define GL_LUMINANCE 0x1909
#define GL_LUMINANCE_ALPHA 0x190A
#define GL_FLAT 0x1D00
#define GL_SMOOTH 0x1D01
#define GL_REPLACE 0x1E01
#define GL_MODULATE 0x2100
#define GL_DECAL 0x2101
#define GL_ADD 0x0104
#define GL_TEXTURE_ENV_MODE 0x2200
#define GL_TEXTURE_ENV_COLOR 0x2201
#define GL_EXP 0x0800
#define GL_EXP2 0x0801
#define GL_NEAREST 0x2600
#define GL_LINEAR 0x2601
#define GL_NEAREST_MIPMAP_NEAREST 0x2700
#define GL_LINEAR_MIPMAP_NEAREST 0x2701
#define GL_NEAREST_MIPMAP_LINEAR 0x2702
#define GL_LINEAR_MIPMAP_LINEAR 0x2703
#define GL_TEXTURE_MAG_FILTER 0x2800
#define GL_TEXTURE_MIN_FILTER 0x2801
#define GL_TEXTURE_WRAP_S 0x2802
#define GL_TEXTURE_WRAP_T 0x2803
#define GL_REPEAT 0x2901
#define GL_LIGHT0 0x4000
#define GL_COLOR_BUFFER_BIT 0x4000
#define GL_DEPTH_BUFFER_BIT 0x0100
#define GL_UNSIGNED_SHORT_4_4_4_4 0x8033
#define GL_UNSIGNED_SHORT_5_5_5_1 0x8034
#define GL_UNSIGNED_SHORT_5_6_5 0x8363
#define GL_POLYGON_OFFSET_FILL 0x8037
#define GL_RESCALE_NORMAL 0x803A
#define GL_TEXTURE_BINDING_2D 0x8069
#define GL_VERTEX_ARRAY 0x8074
#define GL_NORMAL_ARRAY 0x8075
#define GL_COLOR_ARRAY 0x8076
#define GL_TEXTURE_COORD_ARRAY 0x8078
#define GL_GENERATE_MIPMAP 0x8191
#define GL_TEXTURE0 0x84C0
#define GL_MAX_TEXTURE_UNITS 0x84E2
#define GL_FRAMEBUFFER_BINDING 0x8CA6
#define GL_RENDERBUFFER_BINDING 0x8CA7
#define GL_FRAMEBUFFER_COMPLETE 0x8CD5
#define GL_COLOR_ATTACHMENT0 0x8CE0
#define GL_RENDERBUFFER_WIDTH 0x8D42
#define GL_RENDERBUFFER_HEIGHT 0x8D43
#define GL_RENDERBUFFER_INTERNAL_FORMAT 0x8D44

int gl_log = 0;          /* log GL calls while > 0 (frames) */
int gl_log_at = 0, gl_log_n = 1;
int gl_dbg = 0;          /* debugging: 1 no textures, 2 no blending, 4 no culling, 8 red clear colour, 16 test triangles,
                            32 generic vertex path only, 64 compare the fast and generic vertex paths, 128 no fog, 256 no alpha test */
#define L(...) do { if (gl_log > 0) rt_log("[gl] " __VA_ARGS__); } while (0)
#define ONCE(...) do { static int once_; if (!once_) { once_ = 1; rt_log("[gl] " __VA_ARGS__); } } while (0)
static inline float F(u32 x) { return U2F(x); }
static void rdv(u32 p, float *v, int n) { for (int i = 0; i < n; i++) v[i] = RDF(p + 4 * i); }

/* ---------- display list and screen layout (VRAM: two 565 frame buffers, 16-bit depth, then textures) */
#define DL_SIZE (448 * 1024)
static u32 __attribute__((aligned(64))) dlist[DL_SIZE / 4];
#define FB0 0x00000u
#define FB1 0x44000u
#define ZBUF 0x88000u
#define VPOOL 0xCC000u
static int gu_ready;
static u32 list_seq = 1, frames, draw_off = FB0;
static int area_x = 36, area_w = 408;    /* game picture on the PSP screen */
static int FW = 320, FH = 480;           /* GL drawable (portrait) */
static u32 st_draws, st_tris, st_slow, st_clip;
void gl_psp_area(int *x, int *w) { *x = area_x; *w = area_w; }
u32 gl_frame_count(void) { return frames; }
static u32 st_gewait, st_vwait; static u64 st_t60;
static u32 dl_room(void) { return DL_SIZE - (u32)sceGuCheckList(); }
static void free_deferred(void);
/* run everything queued so far and start an empty list (GE registers keep their values) */
static void list_flush(void) { sceGuFinish(); sceGuSync(0, 0); free_deferred(); sceGuStart(GU_DIRECT, dlist); list_seq++; }

/* ---------- GE state cache */
static signed char ge_en[GU_MAX_STATUS];
static struct { u32 blend, afunc, dfunc, dmask, pmask, front, fog_c, tfx, envc, filt, wrap, shade, dofs, light_ver, tex_ver;
                float fog_s, fog_e; int sc[4]; void *tex; } G;
static void ge_invalidate(void) { memset(ge_en, -1, sizeof ge_en); memset(&G, 0xff, sizeof G); G.tex = 0; }
static void ge_set(int st, int on) {
    on = !!on;
    if (ge_en[st] != on) { ge_en[st] = (signed char)on; if (on) sceGuEnable(st); else sceGuDisable(st); }
}
/* scissor [x0,x1) x [y0,y1) in screen pixels (raw registers: libpspgu's scissor helpers are not used) */
static void ge_scissor(int x0, int y0, int x1, int y1) {
    if (G.sc[0] == x0 && G.sc[1] == y0 && G.sc[2] == x1 && G.sc[3] == y1) return;
    G.sc[0] = x0; G.sc[1] = y0; G.sc[2] = x1; G.sc[3] = y1;
    sceGuSendCommandi(212, (y0 << 10) | x0);
    sceGuSendCommandi(213, ((y1 - 1) << 10) | (x1 - 1));
}
/* GL window rectangle (portrait, origin bottom-left) -> PSP screen rectangle; 0 if empty */
static int rect_map(int gx, int gy, int gw, int gh, int *r) {
    float X0 = FH - (gy + gh), X1 = FH - gy, Y0 = FW - (gx + gw), Y1 = FW - gx;   /* landscape game coordinates */
    int x0 = area_x + (int)floorf(X0 * area_w / FH + 0.5f), x1 = area_x + (int)floorf(X1 * area_w / FH + 0.5f);
    int y0 = (int)floorf(Y0 * 272 / FW + 0.5f), y1 = (int)floorf(Y1 * 272 / FW + 0.5f);
    if (x0 < area_x) x0 = area_x;
    if (x1 > area_x + area_w) x1 = area_x + area_w;
    if (y0 < 0) y0 = 0;
    if (y1 > 272) y1 = 272;
    r[0] = x0; r[1] = y0; r[2] = x1; r[3] = y1;
    return x1 > x0 && y1 > y0;
}

/* ---------- GL state */
typedef struct { int on, size; u32 type, stride, ptr; } carray;
static carray A_v, A_c, A_n, A_t[2];
static int client_tex, act_tex;
static struct {
    int tex_en[2]; u32 tex_bound[2], env_mode[2], env_color[2];
    int lighting, colmat, fog, atest, blend, dtest, cull, stest, pofs, dmask, cmask[4];
    u32 afunc, bsrc, bdst, dfunc, cull_face, front_face, shade, fog_mode;
    float aref, clear_col[4], fog_density, fog_start, fog_end, fog_col[4], pofs_factor, pofs_units;
    int vp[4], sc[4], unpack_align;
} S;
static u32 cur_color = 0xffffffffu;
typedef struct { float amb[4], dif[4], spe[4], pos[4], dir[3], exp, cut, att[3]; int on; } light_t;
static light_t LT[8];
static struct { float amb[4], dif[4], spe[4], emi[4], shin; } MAT;
static float model_amb[4];
static u32 light_ver = 1;
static int cull_ccw_front = GU_CCW;   /* GE front-face setting that matches GL_CCW fronts on screen */

static void state_defaults(void) {
    memset(&S, 0, sizeof S);
    S.env_mode[0] = S.env_mode[1] = GL_MODULATE;
    S.afunc = GL_ALWAYS; S.bsrc = GL_ONE; S.bdst = GL_ZERO; S.dfunc = GL_LESS; S.dmask = 1;
    for (int i = 0; i < 4; i++) S.cmask[i] = 1;
    S.cull_face = GL_BACK; S.front_face = GL_CCW; S.shade = GL_SMOOTH; S.fog_mode = GL_EXP; S.fog_density = 1; S.fog_end = 1;
    S.vp[2] = S.sc[2] = FW; S.vp[3] = S.sc[3] = FH; S.unpack_align = 4;
    for (int i = 0; i < 8; i++) {
        light_t *l = &LT[i];
        memset(l, 0, sizeof *l);
        l->amb[3] = l->dif[3] = l->spe[3] = 1;
        if (i == 0) for (int c = 0; c < 3; c++) l->dif[c] = l->spe[c] = 1;
        l->pos[2] = 1; l->dir[2] = -1; l->cut = 180; l->att[0] = 1;
    }
    for (int c = 0; c < 3; c++) { MAT.amb[c] = 0.2f; MAT.dif[c] = 0.8f; MAT.spe[c] = 0; MAT.emi[c] = 0; model_amb[c] = 0.2f; }
    MAT.amb[3] = MAT.dif[3] = MAT.spe[3] = MAT.emi[3] = model_amb[3] = 1; MAT.shin = 0;
}

/* ---------- matrices (column-major like GL and ScePspFMatrix4) */
static float MV[16] __attribute__((aligned(16))), PR[16] __attribute__((aligned(16))), TM[16];
static float PF[16] __attribute__((aligned(16))), CM[16], IDM[16] __attribute__((aligned(16)));
static int mmode, tm_ident = 1, pf_dirty = 1, mv_dirty = 1, ge_proj_pf;
static void m_ident(float *m) { memset(m, 0, 64); m[0] = m[5] = m[10] = m[15] = 1; }
static int m_is_ident(const float *m) { for (int i = 0; i < 16; i++) if (m[i] != ((i % 5) ? 0.f : 1.f)) return 0; return 1; }
static void m_mul(float *r, const float *a, const float *b) {      /* r = a * b */
    float t[16];
    for (int c = 0; c < 4; c++) for (int k = 0; k < 4; k++)
        t[4 * c + k] = a[k] * b[4 * c] + a[4 + k] * b[4 * c + 1] + a[8 + k] * b[4 * c + 2] + a[12 + k] * b[4 * c + 3];
    memcpy(r, t, 64);
}
static float *cur_m(void) { return mmode == 1 ? PR : mmode == 2 ? TM : MV; }
static void m_changed(void) { if (mmode == 0) mv_dirty = 1; else if (mmode == 1) pf_dirty = 1; else tm_ident = m_is_ident(TM); }
/* PF = A * PR: GL clip space of the portrait viewport -> GE clip space of the landscape game area.
   landscape X = FH - gl_y, Y = FW - gl_x, so GE x_ndc = -(full-buffer y_ndc), GE y_ndc = full-buffer x_ndc */
static void update_pf(void) {
    float sx = (float)S.vp[2] / FW, ox = (2.f * S.vp[0] + S.vp[2]) / FW - 1, sy = (float)S.vp[3] / FH, oy = (2.f * S.vp[1] + S.vp[3]) / FH - 1;
    for (int j = 0; j < 4; j++) {
        const float *p = PR + 4 * j;
        PF[4 * j + 0] = -sy * p[1] - oy * p[3];
        PF[4 * j + 1] = sx * p[0] + ox * p[3];
        PF[4 * j + 2] = p[2];
        PF[4 * j + 3] = p[3];
    }
}

/* ---------- VRAM allocator for textures (best fit, blocks kept sorted by offset) */
#define VB_MAX 512
typedef struct { u32 off, size; int used; } vblk;
static vblk vb[VB_MAX];
static int vb_n;
static u32 vram_used, vram_size, tex_reserve, tex_main_allocs;
#define MAXDF 2048
static u32 dfree[MAXDF];
static int ndfree;
static void vram_init(u32 lo, u32 hi) { vb_n = 1; vb[0].off = lo; vb[0].size = hi - lo; vb[0].used = 0; vram_size = hi - lo; }
static u32 vram_alloc(u32 size) {
    int b = -1;
    for (int i = 0; i < vb_n; i++) if (!vb[i].used && vb[i].size >= size && (b < 0 || vb[i].size < vb[b].size)) b = i;
    if (b < 0) return 0;
    if (vb[b].size > size) {
        if (vb_n >= VB_MAX) return 0;
        memmove(&vb[b + 2], &vb[b + 1], (vb_n - b - 1) * sizeof(vblk));
        vb[b + 1].off = vb[b].off + size; vb[b + 1].size = vb[b].size - size; vb[b + 1].used = 0;
        vb[b].size = size; vb_n++;
    }
    vb[b].used = 1; vram_used += vb[b].size;
    return vb[b].off;
}
static void vram_free(u32 off) {
    for (int i = 0; i < vb_n; i++) if (vb[i].off == off && vb[i].used) {
        vb[i].used = 0; vram_used -= vb[i].size;
        if (i + 1 < vb_n && !vb[i + 1].used) { vb[i].size += vb[i + 1].size; memmove(&vb[i + 1], &vb[i + 2], (vb_n - i - 2) * sizeof(vblk)); vb_n--; }
        if (i > 0 && !vb[i - 1].used) { vb[i - 1].size += vb[i].size; memmove(&vb[i], &vb[i + 1], (vb_n - i - 1) * sizeof(vblk)); vb_n--; }
        return;
    }
}

/* texture memory: VRAM first (uncached pointer, the GE ignores the cache bits), then the guest heap
   (16-byte aligned, written through the cache and flushed). handle: 0x80000000|vram offset, or guest block */
static u8 *tmem_alloc(u32 size, u32 *hnd) {
    size = (size + 15) & ~15u;
    u32 off = vram_alloc(size);
    /* Old texture blocks may still be referenced by the queued GE list.
       Synchronize and reclaim them before spilling to guest RAM or downscaling. */
    if (!off && ndfree) { list_flush(); off = vram_alloc(size); }
    if (off) { *hnd = 0x80000000u | off; return (u8 *)(uintptr_t)(((u32)(uintptr_t)sceGeEdramGetAddr() | 0x40000000u) + off); }
    if (heap_free_bytes() < size + tex_reserve) return 0;
    u32 g = gmalloc(size + 16);
    if (!g) return 0;
    *hnd = g; tex_main_allocs++;
    return (u8 *)(((uintptr_t)(MEM + g) + 15) & ~(uintptr_t)15);
}
static void tmem_free_now(u32 h) {
    if (h & 0x80000000u) vram_free(h & 0x7fffffffu);
    else { gfree(h); if (tex_main_allocs) tex_main_allocs--; }
}
static void tmem_free_later(u32 h) { if (!h) return; if (ndfree == MAXDF) list_flush(); dfree[ndfree++] = h; }
static void free_deferred(void) { for (int i = 0; i < ndfree; i++) tmem_free_now(dfree[i]); ndfree = 0; }
static void tex_wb(const void *p, u32 n) { if (((uintptr_t)p >> 30) != 1) sceKernelDcacheWritebackRange(p, n); }

/* ---------- textures */
#define MAXTEX 4096
#define MAXLEV 8
typedef struct {
    u16 w, h;                 /* GL size of level 0 */
    s8 shift;                 /* stored level k = GL level k + shift */
    u8 psm, bits, nlev, swz, alpha;
    u32 mem[MAXLEV]; u8 *data[MAXLEV]; u16 lw[MAXLEV], lh[MAXLEV], tbw[MAXLEV];
    u32 clut_mem; u32 *clut; u16 clut_n;
    u32 minf, magf, wraps, wrapt, ver, last_list;
} tex_t;
static tex_t *texs[MAXTEX];
static u32 tex_hint = 1, tex_count;
static u8 rowbuf[2048];

static tex_t *tex_new(void) {
    tex_t *t = calloc(1, sizeof *t);
    if (!t) rt_fatal("gl: out of memory for texture objects");
    t->minf = GL_NEAREST_MIPMAP_LINEAR; t->magf = GL_LINEAR; t->wraps = t->wrapt = GL_REPEAT; t->ver = 1;
    tex_count++;
    return t;
}
static tex_t *tex_get(u32 name) {      /* creates the object for names bound without glGenTextures */
    if (!name || name >= MAXTEX) return 0;
    if (!texs[name]) texs[name] = tex_new();
    return texs[name];
}
static tex_t *bound_tex(void) { return tex_get(S.tex_bound[act_tex]); }
static void tex_free_storage(tex_t *t) {
    for (int k = 0; k < MAXLEV; k++) { tmem_free_later(t->mem[k]); t->mem[k] = 0; t->data[k] = 0; }
    tmem_free_later(t->clut_mem);
    t->clut_mem = 0; t->clut = 0; t->clut_n = 0; t->nlev = 0; t->ver++;
    if (G.tex == t) G.tex = 0;
}
static int tex_lim(void) { return psp_tex_limit > 0 && psp_tex_limit < 512 ? psp_tex_limit : 512; }
static int tex_lim_pal(void) { extern int psp_tex_limit_pal; return psp_tex_limit_pal > 0 && psp_tex_limit_pal < 512 ? psp_tex_limit_pal : 512; }
static int pick_shift(int w, int h, int lim) { int s = 0; while ((w >> s) > lim || (h >> s) > lim) s++; return s; }
static int imax(int a, int b) { return a > b ? a : b; }
static u32 lev_pitch(const tex_t *t, int k) { return (u32)t->tbw[k] * t->bits / 8; }
static u32 lev_bytes(const tex_t *t, int k) { return lev_pitch(t, k) * (u32)(t->swz ? (t->lh[k] + 7) & ~7 : t->lh[k]); }
/* (re)allocates stored level k; rows are at least 16 bytes, swizzled levels have whole 8-row blocks */
static int lev_alloc(tex_t *t, int k, int w, int h) {
    int minw = 128 / t->bits, tbw = w < minw ? minw : w;
    u32 pitch = (u32)tbw * t->bits / 8, rows = t->swz ? (u32)((h + 7) & ~7) : (u32)h, hnd;
    u8 *p = tmem_alloc(pitch * rows, &hnd);
    if (!p) return 0;
    tmem_free_later(t->mem[k]);
    t->mem[k] = hnd; t->data[k] = p; t->lw[k] = w; t->lh[k] = h; t->tbw[k] = tbw;
    return 1;
}
static void store_row(tex_t *t, int k, int y, const u8 *row, u32 n) {
    u32 pitch = lev_pitch(t, k);
    u8 *base = t->data[k];
    if (!t->swz) { memcpy(base + (u32)y * pitch, row, n); return; }
    u8 *b = base + (u32)(y >> 3) * (pitch >> 4) * 128 + ((y & 7) << 4);
    for (u32 x = 0; x < n; x += 16, b += 128) memcpy(b, row + x, n - x < 16 ? n - x : 16);
}
static void put_texel(tex_t *t, int k, int x, int y, u32 v) {
    u32 pitch = lev_pitch(t, k), xb = (u32)x * t->bits / 8;
    u8 *p = t->data[k] + (t->swz ? tex_swz_off(xb, y, pitch) : (u32)y * pitch + xb);
    switch (t->bits) {
    case 32: memcpy(p, &v, 4); break;
    case 16: { u16 s = (u16)v; memcpy(p, &s, 2); break; }
    case 8: *p = (u8)v; break;
    default: *p = (x & 1) ? (u8)((*p & 0x0f) | (v << 4)) : (u8)((*p & 0xf0) | (v & 15)); break;
    }
}
static u32 *clut_alloc(tex_t *t, int n) {
    u32 hnd, *c = (u32 *)tmem_alloc(n * 4, &hnd);
    if (!c) return 0;
    t->clut = c; t->clut_mem = hnd; t->clut_n = n;
    return c;
}
/* the GE may still read a texture drawn in the current list: run the list before changing it in place */
static void tex_sync(tex_t *t) { if (t->last_list == list_seq) list_flush(); }

/* OES_compressed_paletted_texture -> T8 / T4 (low nibble first) + 8888 CLUT. level <= 0: levels 0..-level in one call */
static int get_ix4(const u8 *lv, u32 i) { return (lv[i >> 1] >> ((i & 1) ? 0 : 4)) & 15; }
static void upload_paletted(tex_t *t, u32 fmt, s32 level, int w, int h, const u8 *src) {
    int bits, eb;
    palette_info(fmt, &bits, &eb);
    int n = bits == 4 ? 16 : 256, kind = (fmt - 0x8B90) % 5, psm = bits == 4 ? GU_PSM_T4 : GU_PSM_T8;
    int nsrc = level <= 0 ? 1 - level : 1, L0 = level <= 0 ? 0 : level;
    const u8 *ix = src + n * eb;
    if (L0 == 0) {
        tex_free_storage(t);
        t->w = w; t->h = h; t->psm = psm; t->bits = bits; t->alpha = kind == 1 || kind >= 3;
        t->shift = pick_shift(w, h, tex_lim_pal());
        t->swz = (w >> t->shift) * bits / 8 >= 16 && (h >> t->shift) >= 8;
        u32 *c = clut_alloc(t, n);
        if (!c) { ONCE("out of texture memory (palette)"); return; }
        palette_rgba(fmt, src, c); tex_wb(c, n * 4);
    } else {
        if (!t->nlev || t->psm != psm) return;
        tex_sync(t);
    }
    for (int k = 0; k < MAXLEV; k++) {
        int j = k + t->shift, srcl, f;          /* wanted GL level, source level, extra downscale */
        if (j > 0 && (t->w >> (j - 1)) <= 1 && (t->h >> (j - 1)) <= 1) break;   /* past the 1x1 level */
        if (j >= L0 && j < L0 + nsrc) { srcl = j; f = 0; }
        else if (k == 0 && L0 == 0 && j >= nsrc) { srcl = nsrc - 1; f = j - srcl; }
        else continue;
        if (k > t->nlev) break;
        int lw = imax(1, t->w >> j), lh = imax(1, t->h >> j), sw = imax(1, t->w >> srcl);
        u32 off = 0;
        for (int i = L0; i < srcl; i++) off = off + ((u32)imax(1, t->w >> i) * imax(1, t->h >> i) * bits + 7) / 8;
        if (!lev_alloc(t, k, lw, lh)) {
            if (k > 0) break;
            if (t->shift < 6) { t->shift++; t->swz = (t->w >> t->shift) * bits / 8 >= 16 && (t->h >> t->shift) >= 8; k = -1; continue; }
            ONCE("out of texture memory (%dx%d paletted)", w, h); return;
        }
        const u8 *lv = ix + off;
        for (int y = 0; y < lh; y++) {
            if (bits == 8) {
                if (!f) store_row(t, k, y, lv + (u32)y * sw, lw);
                else { for (int x = 0; x < lw; x++) rowbuf[x] = lv[(u32)(y << f) * sw + (x << f)]; store_row(t, k, y, rowbuf, lw); }
            } else {
                for (int x = 0; x < lw; x += 2) {
                    u32 i0 = (u32)(y << f) * sw + (x << f);
                    int a = get_ix4(lv, i0), b = x + 1 < lw ? get_ix4(lv, i0 + (1u << f)) : 0;
                    rowbuf[x >> 1] = (u8)(a | b << 4);
                }
                store_row(t, k, y, rowbuf, (lw + 1) / 2);
            }
        }
        tex_wb(t->data[k], lev_bytes(t, k));
        if (k == t->nlev) t->nlev = k + 1;
    }
    t->ver++;
}

/* PVRTC (one call per level) -> 4444 (with alpha) or 5650 */
static void upload_pvrtc(tex_t *t, u32 fmt, s32 level, int w, int h, const u8 *src) {
    int bpp2 = fmt & 1, alpha = fmt >= 0x8C02, k, sh;
    if (level == 0) {
        tex_free_storage(t);
        t->w = w; t->h = h; t->psm = alpha ? GU_PSM_4444 : GU_PSM_5650; t->bits = 16; t->alpha = alpha;
        t->shift = pick_shift(w, h, tex_lim());
        t->swz = (w >> t->shift) >= 8 && (h >> t->shift) >= 8;
        k = 0; sh = t->shift;
    } else {
        if (!t->nlev || t->bits != 16 || level < t->shift) return;
        k = level - t->shift; sh = 0;
        if (k > t->nlev || k >= MAXLEV || (k > 0 && (w < 8 || h < 8))) return;
        tex_sync(t);
    }
    while (!lev_alloc(t, k, imax(1, w >> sh), imax(1, h >> sh))) {
        if (k > 0 || sh >= 6) { ONCE("out of texture memory (%dx%d PVRTC)", w, h); return; }
        sh++; t->shift = sh; t->swz = (w >> sh) >= 8 && (h >> sh) >= 8;
    }
    pvrtc_decode16(src, w, h, bpp2, sh, alpha, t->data[k], lev_pitch(t, k), t->swz);
    tex_wb(t->data[k], lev_bytes(t, k));
    if (k == t->nlev) t->nlev = k + 1;
    t->ver++;
}

/* uncompressed images */
enum { SF_RGBA8, SF_RGB8, SF_4444, SF_5551, SF_565, SF_L8, SF_A8, SF_LA8 };
static int src_fmt(u32 fmt, u32 type, int *bpp) {
    if (type == GL_UNSIGNED_BYTE) switch (fmt) {
        case GL_RGBA: *bpp = 4; return SF_RGBA8;
        case GL_RGB: *bpp = 3; return SF_RGB8;
        case GL_LUMINANCE: *bpp = 1; return SF_L8;
        case GL_ALPHA: *bpp = 1; return SF_A8;
        case GL_LUMINANCE_ALPHA: *bpp = 2; return SF_LA8;
    }
    *bpp = 2;
    if (type == GL_UNSIGNED_SHORT_4_4_4_4) return SF_4444;
    if (type == GL_UNSIGNED_SHORT_5_5_5_1) return SF_5551;
    if (type == GL_UNSIGNED_SHORT_5_6_5) return SF_565;
    return -1;
}
static u32 x5(u32 v) { return ((v & 31) * 255 + 15) / 31; }
static u32 x6(u32 v) { return ((v & 63) * 255 + 31) / 63; }
static u32 src_rgba(int sf, const u8 *p) {        /* one source texel -> RGBA8 word (r in the low byte) */
    u32 v;
    switch (sf) {
    case SF_RGBA8: memcpy(&v, p, 4); return v;
    case SF_RGB8: return p[0] | p[1] << 8 | p[2] << 16 | 0xff000000u;
    case SF_4444: v = p[0] | p[1] << 8; return ((v >> 12) & 15) * 17 | (((v >> 8) & 15) * 17) << 8 | (((v >> 4) & 15) * 17) << 16 | (u32)((v & 15) * 17) << 24;
    case SF_5551: v = p[0] | p[1] << 8; return x5(v >> 11) | x5(v >> 6) << 8 | x5(v >> 1) << 16 | ((v & 1) ? 0xff000000u : 0);
    case SF_565: v = p[0] | p[1] << 8; return x5(v >> 11) | x6(v >> 5) << 8 | x5(v) << 16 | 0xff000000u;
    case SF_L8: return p[0] * 0x010101u | 0xff000000u;
    case SF_A8: return 0x00ffffffu | (u32)p[0] << 24;
    default: return p[0] * 0x010101u | (u32)p[1] << 24;
    }
}
static u32 enc(int psm, int sf, u32 c) {           /* RGBA8 word -> GE texel */
    u32 r = c & 255, g = (c >> 8) & 255, b = (c >> 16) & 255, a = c >> 24;
    switch (psm) {
    case GU_PSM_8888: return c;
    case GU_PSM_5650: return (r >> 3) | (g >> 2) << 5 | (b >> 3) << 11;
    case GU_PSM_5551: return (r >> 3) | (g >> 3) << 5 | (b >> 3) << 10 | (a >= 128 ? 0x8000u : 0);
    case GU_PSM_4444: return (r >> 4) | (g >> 4) << 4 | (b >> 4) << 8 | (a >> 4) << 12;
    default: return sf == SF_A8 ? a : r;            /* T8 luminance / alpha */
    }
}
static void put_row_texel(int bits, int x, u32 v) {
    if (bits == 32) memcpy(rowbuf + 4 * x, &v, 4);
    else if (bits == 16) { u16 s = (u16)v; memcpy(rowbuf + 2 * x, &s, 2); }
    else rowbuf[x] = (u8)v;
}
static void upload_image(tex_t *t, s32 level, int w, int h, u32 fmt, u32 type, u32 px) {
    int bpp, sf = src_fmt(fmt, type, &bpp), psm, bits, alpha = 1;
    if (sf < 0) { ONCE("unsupported TexImage2D format %x/%x", fmt, type); return; }
    switch (sf) {
    case SF_RGBA8: psm = GU_PSM_8888; bits = 32; break;
    case SF_RGB8: case SF_565: psm = GU_PSM_5650; bits = 16; alpha = 0; break;
    case SF_5551: psm = GU_PSM_5551; bits = 16; break;
    case SF_L8: case SF_A8: psm = GU_PSM_T8; bits = 8; alpha = sf == SF_A8; break;
    default: psm = GU_PSM_4444; bits = 16; break;        /* 4444, LA8 */
    }
    if ((w & (w - 1)) || (h & (h - 1))) ONCE("non-power-of-two texture %dx%d (not supported by the GE)", w, h);
    int k, f;
    if (level == 0) {
        tex_free_storage(t);
        t->w = w; t->h = h; t->psm = psm; t->bits = bits; t->alpha = alpha;
        t->shift = pick_shift(w, h, 512);
        t->swz = (w >> t->shift) * bits / 8 >= 16 && (h >> t->shift) >= 8;
        if (psm == GU_PSM_T8) {
            u32 *c = clut_alloc(t, 256);
            if (!c) { ONCE("out of texture memory (palette)"); return; }
            for (u32 i = 0; i < 256; i++) c[i] = sf == SF_A8 ? (0x00ffffffu | i << 24) : (i * 0x010101u | 0xff000000u);
            tex_wb(c, 1024);
        }
        k = 0; f = t->shift;
    } else {
        if (!t->nlev || t->psm != psm || level < t->shift) return;
        k = level - t->shift; f = 0;
        if (k > t->nlev || k >= MAXLEV) return;
        tex_sync(t);
    }
    while (!lev_alloc(t, k, imax(1, w >> f), imax(1, h >> f))) {
        if (k > 0 || f >= 6) { ONCE("out of texture memory (%dx%d image)", w, h); return; }
        f++; t->shift = f; t->swz = (w >> f) * bits / 8 >= 16 && (h >> f) >= 8;
    }
    int lw = t->lw[k], lh = t->lh[k];
    u32 stride = ((u32)w * bpp + S.unpack_align - 1) / S.unpack_align * S.unpack_align;
    static u32 acc[512 * 4];
    for (int y = 0; y < lh; y++) {
        if (!px) { memset(rowbuf, 0, sizeof rowbuf); store_row(t, k, y, rowbuf, (u32)lw * bits / 8); continue; }
        if (!f) {
            const u8 *row = MEM + px + (u32)y * stride;
            for (int x = 0; x < lw; x++) put_row_texel(bits, x, enc(psm, sf, src_rgba(sf, row + x * bpp)));
        } else {
            int n = 1 << f;
            memset(acc, 0, (size_t)lw * 16);
            for (int dy = 0; dy < n; dy++) {
                const u8 *row = MEM + px + (u32)((y << f) + dy) * stride;
                for (int x = 0; x < w; x++) {
                    u32 c = src_rgba(sf, row + x * bpp), *a = acc + 4 * (x >> f);
                    a[0] += c & 255; a[1] += (c >> 8) & 255; a[2] += (c >> 16) & 255; a[3] += c >> 24;
                }
            }
            int sh = 2 * f;
            for (int x = 0; x < lw; x++) {
                u32 *a = acc + 4 * x;
                put_row_texel(bits, x, enc(psm, sf, (a[0] >> sh) | (a[1] >> sh) << 8 | (a[2] >> sh) << 16 | (a[3] >> sh) << 24));
            }
        }
        store_row(t, k, y, rowbuf, (u32)lw * bits / 8);
    }
    tex_wb(t->data[k], lev_bytes(t, k));
    if (k == t->nlev) t->nlev = k + 1;
    t->ver++;
}
static void upload_sub(tex_t *t, s32 level, int x0, int y0, int w, int h, u32 fmt, u32 type, u32 px) {
    int bpp, sf = src_fmt(fmt, type, &bpp), k, f;
    if (sf < 0 || !t->nlev || t->psm == GU_PSM_T4 || (t->psm == GU_PSM_T8 && sf != SF_L8 && sf != SF_A8)) return;
    if (level >= t->shift) { k = level - t->shift; f = 0; }
    else if (level == 0) { k = 0; f = t->shift; }
    else return;
    if (k >= t->nlev) return;
    tex_sync(t);
    u32 stride = ((u32)w * bpp + S.unpack_align - 1) / S.unpack_align * S.unpack_align, step = 1u << f;
    for (int y = 0; y < h; y++) {
        u32 gy = y0 + y, ty = gy >> f;
        if ((gy & (step - 1)) || ty >= t->lh[k]) continue;
        for (int x = 0; x < w; x++) {
            u32 gx = x0 + x, tx = gx >> f;
            if ((gx & (step - 1)) || tx >= t->lw[k]) continue;
            put_texel(t, k, tx, ty, enc(t->psm, sf, src_rgba(sf, MEM + px + (u32)y * stride + (u32)x * bpp)));
        }
    }
    tex_wb(t->data[k], lev_bytes(t, k));
    t->ver++;
}
/* glCopyTexImage2D: the frame so far is rendered, then read back from the 565 draw buffer */
static void copy_image(tex_t *t, s32 level, int x, int y, int w, int h) {
    if (level != 0) return;
    list_flush();
    tex_free_storage(t);
    t->w = w; t->h = h; t->psm = GU_PSM_5650; t->bits = 16; t->alpha = 0;
    t->shift = pick_shift(w, h, 512);
    t->swz = (w >> t->shift) >= 8 && (h >> t->shift) >= 8;
    int f = t->shift;
    if (!lev_alloc(t, 0, imax(1, w >> f), imax(1, h >> f))) { ONCE("out of texture memory (copy)"); return; }
    const u16 *fb = (const u16 *)(uintptr_t)(((u32)(uintptr_t)sceGeEdramGetAddr() | 0x40000000u) + draw_off);
    for (int j = 0; j < t->lh[0]; j++) {
        for (int i = 0; i < t->lw[0]; i++) {
            float gx = x + (i << f) + 0.5f, gy = y + (j << f) + 0.5f;
            int sx = area_x + (int)((FH - gy) * area_w / FH), sy = (int)((FW - gx) * 272 / FW);
            sx = sx < 0 ? 0 : sx > 479 ? 479 : sx; sy = sy < 0 ? 0 : sy > 271 ? 271 : sy;
            put_row_texel(16, i, fb[sy * 512 + sx]);
        }
        store_row(t, 0, j, rowbuf, (u32)t->lw[0] * 2);
    }
    tex_wb(t->data[0], lev_bytes(t, 0));
    t->nlev = 1; t->ver++;
}

/* ---------- vertices: GE layout [u v f32 if textured][color 8888][normal f32 if lit][position f32] */
typedef struct { float u, v; u32 c; float nx, ny, nz, x, y, z; } vtx;
typedef struct { const u8 *p; u32 stride, type; int size; } src_t;
static src_t sv, sc, sn, st;
static int f_tex, f_lit, f_tm;
static int type_size(u32 t) { return t == GL_BYTE || t == GL_UNSIGNED_BYTE ? 1 : t == GL_SHORT || t == GL_UNSIGNED_SHORT ? 2 : 4; }
static void set_src(src_t *s, const carray *a) {
    if (!a->on) { s->p = 0; return; }
    s->p = MEM + a->ptr; s->type = a->type; s->size = a->size;
    s->stride = a->stride ? a->stride : (u32)(a->size * type_size(a->type));
}
static inline float ldf(const u8 *p) { float f; memcpy(&f, p, 4); return f; }
static inline float comp(const src_t *s, const u8 *p, int i) {
    switch (s->type) {
    case GL_FLOAT: return ldf(p + 4 * i);
    case GL_SHORT: { s16 v; memcpy(&v, p + 2 * i, 2); return v; }
    case GL_BYTE: return ((const s8 *)p)[i];
    case GL_UNSIGNED_BYTE: return p[i];
    case GL_UNSIGNED_SHORT: { u16 v; memcpy(&v, p + 2 * i, 2); return v; }
    case GL_FIXED: { s32 v; memcpy(&v, p + 4 * i, 4); return v * (1.0f / 65536); }
    }
    return 0;
}
static u32 clamp8(float f) { return f <= 0 ? 0 : f >= 1 ? 255 : (u32)(f * 255 + 0.5f); }
static u32 pack4(const float *c) { return clamp8(c[0]) | clamp8(c[1]) << 8 | clamp8(c[2]) << 16 | clamp8(c[3]) << 24; }
static u32 pack3(const float *c) { return clamp8(c[0]) | clamp8(c[1]) << 8 | clamp8(c[2]) << 16; }
static void fetch(u32 i, vtx *o) {
    const u8 *p = sv.p + i * sv.stride;
    if (sv.type == GL_FLOAT) { o->x = ldf(p); o->y = ldf(p + 4); o->z = sv.size > 2 ? ldf(p + 8) : 0; }
    else { o->x = comp(&sv, p, 0); o->y = comp(&sv, p, 1); o->z = sv.size > 2 ? comp(&sv, p, 2) : 0; }
    if (sv.size == 4) { float w = comp(&sv, p, 3); if (w != 1 && w != 0) { w = 1 / w; o->x *= w; o->y *= w; o->z *= w; } }
    if (sc.p) {
        const u8 *q = sc.p + i * sc.stride;
        if (sc.type == GL_UNSIGNED_BYTE) { u32 c; memcpy(&c, q, 4); o->c = sc.size == 3 ? c | 0xff000000u : c; }
        else { float f[4] = {comp(&sc, q, 0), comp(&sc, q, 1), comp(&sc, q, 2), sc.size > 3 ? comp(&sc, q, 3) : 1}; o->c = pack4(f); }
    } else o->c = cur_color;
    if (f_lit) {
        if (sn.p) {
            const u8 *q = sn.p + i * sn.stride;
            float k = sn.type == GL_SHORT ? 1.f / 32767 : sn.type == GL_BYTE ? 1.f / 127 : 1;
            o->nx = comp(&sn, q, 0) * k; o->ny = comp(&sn, q, 1) * k; o->nz = comp(&sn, q, 2) * k;
        } else { o->nx = 0; o->ny = 0; o->nz = 1; }
    }
    if (f_tex) {
        float s = 0, t = 0;
        if (st.p) { const u8 *q = st.p + i * st.stride; s = comp(&st, q, 0); t = comp(&st, q, 1); }
        if (f_tm) {
            float u = TM[0] * s + TM[4] * t + TM[12], v = TM[1] * s + TM[5] * t + TM[13], w = TM[3] * s + TM[7] * t + TM[15];
            if (w != 1 && w != 0) { w = 1 / w; u *= w; v *= w; }
            s = u; t = v;
        }
        o->u = s; o->v = t;
    }
}
static inline u32 *emit(u32 *d, const vtx *v) {
    if (f_tex) { *d++ = F2U(v->u); *d++ = F2U(v->v); }
    *d++ = v->c;
    if (f_lit) { *d++ = F2U(v->nx); *d++ = F2U(v->ny); *d++ = F2U(v->nz); }
    *d++ = F2U(v->x); *d++ = F2U(v->y); *d++ = F2U(v->z);
    return d;
}

/* ---------- CPU clipping: outcodes in GE clip space (CM = final projection * modelview) */
#define OC_NEAR 1
#define OC_FAR 2
#define OC_XP 4
#define OC_XN 8
#define OC_YP 16
#define OC_YN 32
#define OC_CLIP (OC_NEAR | OC_XP | OC_XN | OC_YP | OC_YN)
#define GBX 8.0f      /* guard band in viewport half-sizes: the GE draws only inside its 4096x4096 space */
#define GBY 14.0f
static inline void clipc(const vtx *v, float *c) {
    c[0] = CM[0] * v->x + CM[4] * v->y + CM[8] * v->z + CM[12];
    c[1] = CM[1] * v->x + CM[5] * v->y + CM[9] * v->z + CM[13];
    c[2] = CM[2] * v->x + CM[6] * v->y + CM[10] * v->z + CM[14];
    c[3] = CM[3] * v->x + CM[7] * v->y + CM[11] * v->z + CM[15];
}
static inline int outcode(const vtx *v) {
    float c[4];
    clipc(v, c);
    if (c[3] <= 0) return OC_NEAR;
    int o = 0;
    if (c[2] < -c[3]) o |= OC_NEAR;
    if (c[2] > c[3]) o |= OC_FAR;
    if (c[0] > GBX * c[3]) o |= OC_XP;
    if (c[0] < -GBX * c[3]) o |= OC_XN;
    if (c[1] > GBY * c[3]) o |= OC_YP;
    if (c[1] < -GBY * c[3]) o |= OC_YN;
    return o;
}
typedef struct { vtx a; float c[4]; } cvtx;
static float plane_d(const cvtx *v, int pl) {        /* >= 0 inside; planes slightly inside the outcode limits */
    switch (pl) {
    case 0: return v->c[2] + v->c[3] * 0.9999f;
    case 1: return (GBX - 0.1f) * v->c[3] - v->c[0];
    case 2: return (GBX - 0.1f) * v->c[3] + v->c[0];
    case 3: return (GBY - 0.1f) * v->c[3] - v->c[1];
    default: return (GBY - 0.1f) * v->c[3] + v->c[1];
    }
}
static void lerp_cv(cvtx *o, const cvtx *p, const cvtx *q, float t) {
#define LF(f) o->a.f = p->a.f + (q->a.f - p->a.f) * t
    LF(u); LF(v); LF(nx); LF(ny); LF(nz); LF(x); LF(y); LF(z);
#undef LF
    u32 c = 0;
    for (int s = 0; s < 32; s += 8) {
        float a = (float)((p->a.c >> s) & 255), b = (float)((q->a.c >> s) & 255);
        c |= (u32)(a + (b - a) * t + 0.5f) << s;
    }
    o->a.c = c;
    for (int i = 0; i < 4; i++) o->c[i] = p->c[i] + (q->c[i] - p->c[i]) * t;
}
static vtx *clip_out;
static u32 clip_cap, clip_n;
static void *grow(void *p, u32 *cap, u32 need, u32 esz) {
    if (need <= *cap) return p;
    u32 n = need + need / 2 + 64;
    p = realloc(p, (size_t)n * esz);
    if (!p) rt_fatal("gl: out of memory (%u x %u bytes)", n, esz);
    *cap = n;
    return p;
}
/* Sutherland-Hodgman against the planes in codes (near first); output appended to clip_out as triangles */
static void clip_tri(const vtx *va, const vtx *vb_, const vtx *vc, int codes) {
    cvtx P[2][12];
    int n = 3, cur = 0;
    P[0][0].a = *va; P[0][1].a = *vb_; P[0][2].a = *vc;
    for (int i = 0; i < 3; i++) clipc(&P[0][i].a, P[0][i].c);
    if (codes & OC_NEAR) codes |= OC_XP | OC_XN | OC_YP | OC_YN;
    static const int bit[5] = {OC_NEAR, OC_XP, OC_XN, OC_YP, OC_YN};
    for (int pl = 0; pl < 5; pl++) {
        if (!(codes & bit[pl])) continue;
        cvtx *in = P[cur], *out = P[cur ^ 1];
        int m = 0;
        for (int i = 0; i < n; i++) {
            const cvtx *p = &in[i], *q = &in[i + 1 < n ? i + 1 : 0];
            float dp = plane_d(p, pl), dq = plane_d(q, pl);
            if (dp >= 0) out[m++] = *p;
            if ((dp >= 0) != (dq >= 0) && m < 12) lerp_cv(&out[m++], p, q, dp / (dp - dq));
        }
        n = m; cur ^= 1;
        if (n < 3) return;
    }
    clip_out = grow(clip_out, &clip_cap, clip_n + 3 * (n - 2), sizeof(vtx));
    for (int i = 1; i + 1 < n; i++) {
        clip_out[clip_n++] = P[cur][0].a; clip_out[clip_n++] = P[cur][i].a; clip_out[clip_n++] = P[cur][i + 1].a;
    }
    st_clip++;
}

/* ---------- applying GL state to the GE before a draw */
static int blend_src(u32 f, u32 *fix) {
    *fix = 0;
    switch (f) {
    case GL_ZERO: return GU_FIX;
    case GL_DST_COLOR: return GU_OTHER_COLOR;
    case GL_ONE_MINUS_DST_COLOR: return GU_ONE_MINUS_OTHER_COLOR;
    case GL_SRC_ALPHA: return GU_SRC_ALPHA;
    case GL_ONE_MINUS_SRC_ALPHA: return GU_ONE_MINUS_SRC_ALPHA;
    case GL_ONE_MINUS_DST_ALPHA: return GU_FIX;            /* 565 frame buffer: destination alpha is 1 */
    default: *fix = 0xffffff; return GU_FIX;               /* ONE, DST_ALPHA, SRC_ALPHA_SATURATE */
    }
}
static int blend_dst(u32 f, u32 *fix) {
    *fix = 0;
    switch (f) {
    case GL_ONE: case GL_DST_ALPHA: *fix = 0xffffff; return GU_FIX;
    case GL_SRC_COLOR: return GU_OTHER_COLOR;
    case GL_ONE_MINUS_SRC_COLOR: return GU_ONE_MINUS_OTHER_COLOR;
    case GL_SRC_ALPHA: return GU_SRC_ALPHA;
    case GL_ONE_MINUS_SRC_ALPHA: return GU_ONE_MINUS_SRC_ALPHA;
    default: return GU_FIX;                                /* ZERO, ONE_MINUS_DST_ALPHA */
    }
}
static int cmp_map(u32 f) {        /* GL compare function -> GE (same sense) */
    static const int m[8] = {GU_NEVER, GU_LESS, GU_EQUAL, GU_LEQUAL, GU_GREATER, GU_NOTEQUAL, GU_GEQUAL, GU_ALWAYS};
    return f >= GL_NEVER && f <= GL_ALWAYS ? m[f - GL_NEVER] : GU_ALWAYS;
}
static int depth_map(u32 f) {      /* inverted depth: near = 65535 */
    static const int m[8] = {GU_NEVER, GU_GREATER, GU_EQUAL, GU_GEQUAL, GU_LESS, GU_NOTEQUAL, GU_LEQUAL, GU_ALWAYS};
    return f >= GL_NEVER && f <= GL_ALWAYS ? m[f - GL_NEVER] : GU_ALWAYS;
}
static int nonzero3(const float *c) { return c[0] > 0 || c[1] > 0 || c[2] > 0; }
static void ge_lights(void) {
    int n = 0, mspec = nonzero3(MAT.spe);
    for (int i = 0; i < 8 && n < 4; i++) {
        light_t *l = &LT[i];
        if (!l->on) continue;
        ScePspFVector3 p;
        int type;
        if (l->pos[3] == 0) { type = GU_DIRECTIONAL; p.x = l->pos[0]; p.y = l->pos[1]; p.z = l->pos[2]; }
        else {
            float iw = 1 / l->pos[3];
            p.x = l->pos[0] * iw; p.y = l->pos[1] * iw; p.z = l->pos[2] * iw;
            type = l->cut < 180 ? GU_SPOTLIGHT : GU_POINTLIGHT;
        }
        sceGuLight(n, type, mspec && nonzero3(l->spe) ? GU_DIFFUSE_AND_SPECULAR : GU_AMBIENT_AND_DIFFUSE, &p);
        sceGuLightColor(n, GU_AMBIENT, pack3(l->amb));
        sceGuLightColor(n, GU_DIFFUSE, pack3(l->dif));
        sceGuLightColor(n, GU_SPECULAR, pack3(l->spe));
        sceGuLightAtt(n, l->att[0], l->att[1], l->att[2]);
        if (type == GU_SPOTLIGHT) {
            ScePspFVector3 d = {l->dir[0], l->dir[1], l->dir[2]};
            sceGuLightSpot(n, &d, l->exp, cosf(l->cut * (GU_PI / 180)));
        }
        ge_set(GU_LIGHT0 + n, 1);
        n++;
    }
    for (int i = n; i < 4; i++) ge_set(GU_LIGHT0 + i, 0);
    sceGuAmbient(0xff000000u | pack3(model_amb));
    sceGuModelColor(pack3(MAT.emi), pack3(MAT.amb), pack3(MAT.dif), pack3(MAT.spe));
    sceGuAmbientColor(pack3(MAT.amb) | clamp8(MAT.dif[3]) << 24);     /* lit alpha = material diffuse alpha */
    sceGuColorMaterial(S.colmat ? GU_AMBIENT | GU_DIFFUSE : 0);
    sceGuSpecular(MAT.shin);
}
static int min_map(u32 f, int has_mips) {
    switch (f) {
    case GL_NEAREST: return GU_NEAREST;
    case GL_LINEAR: return GU_LINEAR;
    case GL_NEAREST_MIPMAP_NEAREST: return has_mips ? GU_NEAREST_MIPMAP_NEAREST : GU_NEAREST;
    case GL_LINEAR_MIPMAP_NEAREST: return has_mips ? GU_LINEAR_MIPMAP_NEAREST : GU_LINEAR;
    case GL_NEAREST_MIPMAP_LINEAR: return has_mips ? GU_NEAREST_MIPMAP_LINEAR : GU_NEAREST;
    default: return has_mips ? GU_LINEAR_MIPMAP_LINEAR : GU_LINEAR;
    }
}
static void ge_texture(tex_t *t) {
    t->last_list = list_seq;
    if (G.tex != t || G.tex_ver != t->ver) {
        G.tex = t; G.tex_ver = t->ver;
        sceGuTexMode(t->psm, t->nlev - 1, 0, t->swz);
        if (t->clut) { sceGuClutMode(GU_PSM_8888, 0, 0xff, 0); sceGuClutLoad(t->clut_n / 8, t->clut); }
        for (int k = 0; k < t->nlev; k++) sceGuTexImage(k, t->lw[k], t->lh[k], t->tbw[k], t->data[k]);
        sceGuTexFlush();
    }
    u32 filt = (u32)min_map(t->minf, t->nlev > 1) | (t->magf == GL_NEAREST ? GU_NEAREST : GU_LINEAR) << 8;
    if (G.filt != filt) { G.filt = filt; sceGuTexFilter(filt & 0xff, filt >> 8); }
    u32 wrap = (t->wraps == GL_REPEAT ? GU_REPEAT : GU_CLAMP) | (t->wrapt == GL_REPEAT ? GU_REPEAT : GU_CLAMP) << 8;
    if (G.wrap != wrap) { G.wrap = wrap; sceGuTexWrap(wrap & 0xff, wrap >> 8); }
    int tfx;
    switch (S.env_mode[0]) {
    case GL_REPLACE: tfx = GU_TFX_REPLACE; break;
    case GL_DECAL: tfx = GU_TFX_DECAL; break;
    case GL_BLEND: tfx = GU_TFX_BLEND; break;
    case GL_ADD: tfx = GU_TFX_ADD; break;
    case GL_MODULATE: tfx = GU_TFX_MODULATE; break;
    default: ONCE("texture env mode %x drawn as MODULATE", S.env_mode[0]); tfx = GU_TFX_MODULATE; break;
    }
    u32 key = (u32)tfx | (t->alpha ? GU_TCC_RGBA : GU_TCC_RGB) << 8;
    if (G.tfx != key) { G.tfx = key; sceGuTexFunc(tfx, key >> 8); }
    if (tfx == GU_TFX_BLEND && G.envc != S.env_color[0]) { G.envc = S.env_color[0]; sceGuTexEnvColor(S.env_color[0]); }
}
static void box_planes(void);
static void apply_state(tex_t *t) {
    /* matrices: GE projection = PF (or PF * MV when the modelview is not affine), model = MV, view = identity */
    if (pf_dirty) update_pf();
    if (pf_dirty || mv_dirty) {
        int affine = ge_model_is_affine(MV);
        static float MVA[16] __attribute__((aligned(16)));
        const float *model = MV;
        if (affine && MV[15] != 1.0f) {
            memcpy(MVA, MV, sizeof MVA);
            MVA[15] = 1.0f;
            model = MVA;
        }
        if (affine) {
            if (pf_dirty || !ge_proj_pf) { sceGuSetMatrix(GU_PROJECTION, (const ScePspFMatrix4 *)PF); ge_proj_pf = 1; }
            sceGuSetMatrix(GU_MODEL, (const ScePspFMatrix4 *)model);
        } else {
            static float T[16] __attribute__((aligned(16)));
            m_mul(T, PF, MV);
            sceGuSetMatrix(GU_PROJECTION, (const ScePspFMatrix4 *)T); sceGuSetMatrix(GU_MODEL, (const ScePspFMatrix4 *)IDM);
            ge_proj_pf = 0;
            ONCE("non-affine modelview folded into the projection");
        }
        m_mul(CM, PF, model);
        box_planes();
        pf_dirty = mv_dirty = 0;
    }
    /* blending, alpha test, depth, color mask */
    int bl = S.blend && !(S.bsrc == GL_ONE && S.bdst == GL_ZERO) && !(gl_dbg & 2);
    ge_set(GU_BLEND, bl);
    if (bl && G.blend != (S.bsrc << 16 | S.bdst)) {
        u32 fa, fb;
        int a = blend_src(S.bsrc, &fa), b = blend_dst(S.bdst, &fb);
        G.blend = S.bsrc << 16 | S.bdst;
        sceGuBlendFunc(GU_ADD, a, b, fa, fb);
    }
    ge_set(GU_ALPHA_TEST, S.atest && !(gl_dbg & 256));
    if (S.atest) {
        /* GL compares alpha / 255 with the reference, the GE compares 8-bit integers: a > r * 255 is a > floor(r * 255) */
        float r = (S.aref < 0 ? 0 : S.aref > 1 ? 1 : S.aref) * 255;
        u32 ri = S.afunc == GL_GREATER || S.afunc == GL_LEQUAL ? (u32)floorf(r) : S.afunc == GL_LESS || S.afunc == GL_GEQUAL ? (u32)ceilf(r) : (u32)(r + 0.5f);
        u32 key = (u32)cmp_map(S.afunc) | ri << 8;
        if (G.afunc != key) { G.afunc = key; sceGuAlphaFunc(key & 0xff, key >> 8, 0xff); }
    }
    ge_set(GU_DEPTH_TEST, S.dtest);
    if (S.dtest) { u32 f = (u32)depth_map(S.dfunc); if (G.dfunc != f) { G.dfunc = f; sceGuDepthFunc(f); } }
    u32 dm = !(S.dtest && S.dmask);
    if (G.dmask != dm) { G.dmask = dm; sceGuDepthMask(dm); }
    u32 pm = (S.cmask[0] ? 0 : 0xffu) | (S.cmask[1] ? 0 : 0xff00u) | (S.cmask[2] ? 0 : 0xff0000u) | (S.cmask[3] ? 0 : 0xff000000u);
    if (G.pmask != pm) { G.pmask = pm; sceGuPixelMask(pm); }
    u32 dofs = 0;
    if (S.pofs) { float o = -(S.pofs_units + S.pofs_factor) * 2; dofs = o > 0 ? (u32)o : 0; }
    if (G.dofs != dofs) { G.dofs = dofs; sceGuDepthOffset(dofs); }
    /* culling: GL CCW fronts keep their on-screen winding after the (proper) rotation */
    if (S.cull && S.cull_face != GL_FRONT_AND_BACK && !(gl_dbg & 4)) {
        ge_set(GU_CULL_FACE, 1);
        int front_ccw = (S.front_face == GL_CCW) ^ (S.cull_face == GL_FRONT);
        u32 ff = front_ccw ? (u32)cull_ccw_front : (u32)!cull_ccw_front;
        if (G.front != ff) { G.front = ff; sceGuFrontFace(ff); }
    } else ge_set(GU_CULL_FACE, 0);
    u32 shade = S.shade == GL_FLAT ? GU_FLAT : GU_SMOOTH;
    if (G.shade != shade) { G.shade = shade; sceGuShadeModel(shade); }
    /* fog (linear; EXP modes approximated) */
    ge_set(GU_FOG, S.fog && !(gl_dbg & 128));
    if (S.fog) {
        float s = S.fog_start, e = S.fog_end, d = S.fog_density > 0 ? S.fog_density : 1;
        if (S.fog_mode == GL_EXP) { s = 0; e = 2.5f / d; }
        else if (S.fog_mode == GL_EXP2) { s = 0; e = 1.6f / d; }
        u32 c = pack3(S.fog_col);
        if (G.fog_s != s || G.fog_e != e || G.fog_c != c) {
            G.fog_s = s; G.fog_e = e; G.fog_c = c; sceGuFog(s, e, c);
            if (rt_verbose) rt_log("[gl] fog mode %x start %.2f end %.2f density %.4f colour %08x", S.fog_mode, S.fog_start, S.fog_end, S.fog_density, c);
        }
    }
    /* texture, lighting */
    if (gl_dbg & 1) t = 0;
    ge_set(GU_TEXTURE_2D, t != 0);
    if (t) ge_texture(t);
    ge_set(GU_LIGHTING, f_lit);
    if (f_lit && G.light_ver != light_ver) { G.light_ver = light_ver; ge_lights(); }
}

static u8 *oc_buf; static u32 oc_cap;
static u16 *li_buf; static u32 li_cap;
static u16 *tri_buf; static u32 tri_cap;
static int d_expand; static u32 d_vmin; static const u8 *d_i8; static const u16 *d_i16;
static u32 gvert(u32 j) { return d_expand ? (d_i16 ? d_i16[j] : d_i8[j]) : d_vmin + j; }
/* ---------- fast vertex path for the formats the game draws with: no lighting, positions float or short
   (2 or 3 components), colours as RGBA/RGB bytes or the current colour, texcoords short or float with no or an
   affine texture matrix. Vertices are written once to the uncached list (never read back) and give bit-identical
   results to fetch() + emit(). The bounding box of the positions decides whether per-vertex outcodes are needed:
   its 8 corners inside all planes means every vertex is (the tests are linear in homogeneous coordinates).
   gldbg 32: always use the generic path; gldbg 64: emit both ways and compare (slow, logs mismatches). */
enum { PK_F3, PK_F2, PK_S3, PK_S2 };
enum { CK_NONE, CK_U4, CK_U3 };
enum { TK_NONE, TK_S, TK_ST, TK_F, TK_FT };       /* short / float texcoords, T: affine texture matrix */
static int fp_pk, fp_ck, fp_tk, d_fast;
static int fast_fmt(void) {
    if (f_lit || (gl_dbg & 32)) return 0;
    if (sv.type == GL_FLOAT) fp_pk = sv.size == 3 ? PK_F3 : sv.size == 2 ? PK_F2 : -1;
    else if (sv.type == GL_SHORT) fp_pk = sv.size == 3 ? PK_S3 : sv.size == 2 ? PK_S2 : -1;
    else return 0;
    if (fp_pk < 0) return 0;
    if (!sc.p) fp_ck = CK_NONE;
    else if (sc.type == GL_UNSIGNED_BYTE && (sc.size == 4 || sc.size == 3)) fp_ck = sc.size == 4 ? CK_U4 : CK_U3;
    else return 0;
    if (!f_tex) fp_tk = TK_NONE;
    else {
        if (!st.p || (st.type != GL_SHORT && st.type != GL_FLOAT)) return 0;
        if (f_tm && (TM[3] != 0 || TM[7] != 0 || TM[15] != 1)) return 0;
        fp_tk = st.type == GL_SHORT ? (f_tm ? TK_ST : TK_S) : (f_tm ? TK_FT : TK_F);
    }
    return 1;
}
/* float bits -> integer with the same order (and back: the mapping is its own inverse) */
static inline s32 fkey(u32 b) { return (s32)(b ^ ((u32)((s32)b >> 31) >> 1)); }
typedef struct { s32 lo[3], hi[3]; } fbox;
#define FCH 32                  /* vertices per sub-box: big draws that need clipping keep per-vertex work to the parts near the edges */
static fbox *fch; static u32 fch_cap;
typedef struct { u32 v; } __attribute__((packed)) ua32_t;
typedef struct { s16 v; } __attribute__((packed)) ua16_t;
static inline u32 ld32(const u8 *p, const int al) { return al ? *(const u32 *)(const void *)p : ((const ua32_t *)(const void *)p)->v; }
static inline s16 ld16(const u8 *p, const int al) { return al ? *(const s16 *)(const void *)p : ((const ua16_t *)(const void *)p)->v; }
/* im: 0 sequential, 1 16-bit indices, 2 8-bit indices; al: all arrays 4-byte aligned */
static inline __attribute__((always_inline)) u32 *fast_loop(u32 *d, u32 nv, const int im, const int pk, const int ck, const int tk, const int al, fbox *bx) {
    const u8 *vp = sv.p, *cp = sc.p, *tp = st.p;
    const u32 vs = sv.stride, cs = sc.stride, ts = st.stride, col = cur_color;
    const float m0 = TM[0], m4 = TM[4], m12 = TM[12], m1 = TM[1], m5 = TM[5], m13 = TM[13];
    const u16 *i16 = d_i16; const u8 *i8 = d_i8;
    s32 Lx = 0x7fffffff, Ly = Lx, Lz = Lx, Hx = -0x7fffffff - 1, Hy = Hx, Hz = Hx;
    if (im == 0) {
        u32 b = d_vmin;
        vp += b * vs;
        if (ck != CK_NONE) cp += b * cs;
        if (tk != TK_NONE) tp += b * ts;
    }
    fbox *cb = fch;
    for (u32 j0 = 0; j0 < nv; j0 += FCH, cb++) {
    u32 j1 = j0 + FCH < nv ? j0 + FCH : nv;
    s32 lx = 0x7fffffff, ly = lx, lz = lx, hx = -0x7fffffff - 1, hy = hx, hz = hx;
    for (u32 j = j0; j < j1; j++) {
        const u8 *p, *q = 0, *r = 0;
        if (im == 0) {
            p = vp; vp += vs;
            if (ck != CK_NONE) { q = cp; cp += cs; }
            if (tk != TK_NONE) { r = tp; tp += ts; }
        } else {
            u32 i = im == 1 ? i16[j] : i8[j];
            p = vp + i * vs;
            if (ck != CK_NONE) q = cp + i * cs;
            if (tk != TK_NONE) r = tp + i * ts;
        }
        if (tk != TK_NONE) {
            float s, t;
            if (tk == TK_S || tk == TK_ST) { u32 w = ld32(r, al); s = (float)(s32)(s16)w; t = (float)((s32)w >> 16); }
            else { s = U2F(ld32(r, al)); t = U2F(ld32(r + 4, al)); }
            if (tk == TK_ST || tk == TK_FT) { float u = m0 * s + m4 * t + m12, v = m1 * s + m5 * t + m13; s = u; t = v; }
            d[0] = F2U(s); d[1] = F2U(t); d += 2;
        }
        if (ck == CK_NONE) *d++ = col;
        else { u32 c = ld32(q, al); *d++ = ck == CK_U3 ? c | 0xff000000u : c; }
        u32 x, y, z;
        if (pk == PK_F3 || pk == PK_F2) {
            x = ld32(p, al); y = ld32(p + 4, al);
            z = pk == PK_F3 ? ld32(p + 8, al) : 0;
        } else {
            u32 w = ld32(p, al);
            x = F2U((float)(s32)(s16)w); y = F2U((float)((s32)w >> 16));
            z = pk == PK_S3 ? F2U((float)ld16(p + 4, al)) : 0;
        }
        d[0] = x; d[1] = y; d[2] = z; d += 3;
        s32 k = fkey(x); lx = k < lx ? k : lx; hx = k > hx ? k : hx;
        k = fkey(y); ly = k < ly ? k : ly; hy = k > hy ? k : hy;
        k = fkey(z); lz = k < lz ? k : lz; hz = k > hz ? k : hz;
    }
    cb->lo[0] = lx; cb->lo[1] = ly; cb->lo[2] = lz; cb->hi[0] = hx; cb->hi[1] = hy; cb->hi[2] = hz;
    Lx = lx < Lx ? lx : Lx; Ly = ly < Ly ? ly : Ly; Lz = lz < Lz ? lz : Lz;
    Hx = hx > Hx ? hx : Hx; Hy = hy > Hy ? hy : Hy; Hz = hz > Hz ? hz : Hz;
    }
    bx->lo[0] = Lx; bx->lo[1] = Ly; bx->lo[2] = Lz; bx->hi[0] = Hx; bx->hi[1] = Hy; bx->hi[2] = Hz;
    return d;
}
#define FAST_IM(pk, ck, tk, al) \
    (im == 0 ? fast_loop(d, nv, 0, pk, ck, tk, al, bx) : im == 1 ? fast_loop(d, nv, 1, pk, ck, tk, al, bx) : fast_loop(d, nv, 2, pk, ck, tk, al, bx))
static __attribute__((noinline)) void fast_any(u32 *d, u32 nv, int im, fbox *bx) {      /* the less common formats */
    int pk = fp_pk, ck = fp_ck, tk = fp_tk;
    FAST_IM(pk, ck, tk, 0);
}
/* Same generic format/index handling, but let the compiler use aligned word
   loads when every active array and stride is 4-byte aligned. */
static __attribute__((noinline)) void fast_any_aligned(u32 *d, u32 nv, int im, fbox *bx) {
    int pk = fp_pk, ck = fp_ck, tk = fp_tk;
    FAST_IM(pk, ck, tk, 1);
}
static void fast_emit(u32 *d, u32 nv, fbox *bx) {
    int im = !d_expand ? 0 : d_i16 ? 1 : 2;
    fch = grow(fch, &fch_cap, (nv + FCH - 1) / FCH, sizeof(fbox));
    int al = !(((uintptr_t)sv.p | sv.stride) & 3) && (!sc.p || !(((uintptr_t)sc.p | sc.stride) & 3)) && (!st.p || !(((uintptr_t)st.p | st.stride) & 3));
    if (al && fp_pk == PK_F3 && fp_tk == TK_ST && fp_ck == CK_U4) FAST_IM(PK_F3, CK_U4, TK_ST, 1);
    else if (al && fp_pk == PK_F3 && fp_tk == TK_ST && fp_ck == CK_NONE) FAST_IM(PK_F3, CK_NONE, TK_ST, 1);
    else if (al) fast_any_aligned(d, nv, im, bx);
    else fast_any(d, nv, im, bx);
}
/* the outcode tests without branches: a < b exactly when b - a (or a + -b) has the sign bit set (c3 > 0) */
#define SGN(f) (F2U(f) >> 31)
#define OC_BITS(c0, c1, c2, c3, gx, gy) (SGN((c2) + (c3)) * OC_NEAR | SGN((c3) - (c2)) * OC_FAR | SGN((gx) - (c0)) * OC_XP | \
    SGN((c0) + (gx)) * OC_XN | SGN((gy) - (c1)) * OC_YP | SGN((c1) + (gy)) * OC_YN)
/* the box tests: 7 planes in GE clip space, a point is outside plane p when k[0]x + k[1]y + k[2]z + k[3] > 0.
   Planes 0-5 are in the order of the OC_ bits; the margin stays far above the rounding of the test and of outcode(). */
enum { PL_NEAR, PL_FAR, PL_XP, PL_XN, PL_YP, PL_YN, PL_BEHIND, NPL };
#define PB_BEHIND (1u << PL_BEHIND)
static float pl_k[NPL][4], pl_a[NPL][3], pl_ms, pl_m1;
static int pl_ok;
static void box_planes(void) {       /* after every change of CM */
    float s = 0, s1 = 0;
    for (int i = 0; i < 4; i++) {
        float c0 = CM[4 * i], c1 = CM[4 * i + 1], c2 = CM[4 * i + 2], c3 = CM[4 * i + 3];
        pl_k[PL_NEAR][i] = -(c2 + c3); pl_k[PL_FAR][i] = c2 - c3;
        pl_k[PL_XP][i] = c0 - GBX * c3; pl_k[PL_XN][i] = -c0 - GBX * c3;
        pl_k[PL_YP][i] = c1 - GBY * c3; pl_k[PL_YN][i] = -c1 - GBY * c3;
        pl_k[PL_BEHIND][i] = -c3;
        float m = fabsf(c0) > fabsf(c1) ? fabsf(c0) : fabsf(c1);
        m = (m > fabsf(c2) ? m : fabsf(c2)) + GBY * fabsf(c3);     /* bounds the terms of every plane and outcode() */
        if (i < 3) s += m; else s1 = m;
    }
    for (int p = 0; p < NPL; p++) for (int i = 0; i < 3; i++) pl_a[p][i] = fabsf(pl_k[p][i]);
    pl_ms = 1e-5f * s; pl_m1 = 1e-5f * s1 + 1e-30f;
    pl_ok = s < 1e20f && s1 < 1e20f;
}
/* bit p of the result: some point of the box may be outside plane p; bit p of *all_: every point is outside it */
static u32 box_test(const fbox *bx, u32 *all_) {
    float c[3], h[3], R = 0;
    *all_ = 0;
    if (!pl_ok) return 0x7f;
    for (int a = 0; a < 3; a++) {
        float lo = U2F((u32)fkey((u32)bx->lo[a])), hi = U2F((u32)fkey((u32)bx->hi[a]));
        if (!(lo > -1e15f && hi < 1e15f && lo <= hi)) return 0x7f;     /* also NaN; no overflow below */
        c[a] = 0.5f * (lo + hi); h[a] = 0.5f * (hi - lo);
        float r = fabsf(lo) > fabsf(hi) ? fabsf(lo) : fabsf(hi);
        R = r > R ? r : R;
    }
    float m = pl_ms * R + pl_m1;
    u32 in = 0, all = 0;
    for (int p = NPL - 1; p >= 0; p--) {
        const float *k = pl_k[p], *e = pl_a[p];
        float L = k[0] * c[0] + k[1] * c[1] + k[2] * c[2] + k[3];
        float E = e[0] * h[0] + e[1] * h[1] + e[2] * h[2] + m;          /* > 0, so the signs below are exact */
        in = in << 1 | SGN(L + E); all = all << 1 | SGN(E - L);
    }
    *all_ = all;
    return in ^ 0x7f;
}
/* outcodes from the bounding box: 1 when they settle the draw (skip, or no clipping needed) */
static int box_codes(const fbox *bx, int *oc_or, int *oc_and) {
    u32 all, maybe = box_test(bx, &all);
    if (all & (PB_BEHIND | OC_NEAR)) { *oc_or = *oc_and = OC_NEAR; return 1; }      /* every vertex gets OC_NEAR */
    if (maybe & PB_BEHIND) return 0;                       /* a vertex may be behind the eye */
    if (all) { *oc_or = *oc_and = (int)all; return 1; }      /* every vertex outside these planes */
    if (maybe & OC_CLIP) return 0;
    *oc_or = (int)maybe; *oc_and = 0; return 1;            /* no clipping needed (the far plane is the GE's) */
}
/* outcodes of aligned float xyz positions j0..j1-1: the same results as outcode() */
static inline __attribute__((always_inline)) void oc_loop(u32 j0, u32 j1, const int im, int *oc_or, int *oc_and) {
    const float m0 = CM[0], m1 = CM[1], m2 = CM[2], m3 = CM[3], m4 = CM[4], m5 = CM[5], m6 = CM[6], m7 = CM[7];
    const float m8 = CM[8], m9 = CM[9], m10 = CM[10], m11 = CM[11], m12 = CM[12], m13 = CM[13], m14 = CM[14], m15 = CM[15];
    const u8 *base = sv.p, *q = base + (d_vmin + j0) * sv.stride;
    const u32 vs = sv.stride;
    const u16 *i16 = d_i16; const u8 *i8 = d_i8; u8 *ob = oc_buf;
    u32 oo = (u32)*oc_or, oa = (u32)*oc_and;
    for (u32 j = j0; j < j1; j++) {
        const u8 *p;
        if (im == 0) { p = q; q += vs; } else p = base + (im == 1 ? i16[j] : i8[j]) * vs;
        float x = U2F(ld32(p, 1)), y = U2F(ld32(p + 4, 1)), z = U2F(ld32(p + 8, 1));
        float c3 = m3 * x + m7 * y + m11 * z + m15;
        u32 o;
        if (c3 <= 0) o = OC_NEAR;
        else {
            float c0 = m0 * x + m4 * y + m8 * z + m12, c1 = m1 * x + m5 * y + m9 * z + m13, c2 = m2 * x + m6 * y + m10 * z + m14;
            float gx = GBX * c3, gy = GBY * c3;
            o = OC_BITS(c0, c1, c2, c3, gx, gy);
        }
        ob[j] = (u8)o; oo |= o; oa &= o;
    }
    *oc_or = (int)oo; *oc_and = (int)oa;
}
static void oc_range(u32 j0, u32 j1, int *oc_or, int *oc_and) {
    if (!d_expand) oc_loop(j0, j1, 0, oc_or, oc_and);
    else if (d_i16) oc_loop(j0, j1, 1, oc_or, oc_and);
    else oc_loop(j0, j1, 2, oc_or, oc_and);
}
/* per-vertex outcodes, except for sub-boxes entirely inside (all their vertices have outcode 0) */
static void fast_outcodes(u32 nv, int *oc_or, int *oc_and) {
    int oo = 0, oa = 0xff;
    vtx v;
    const fbox *cb = fch;
    int fast_xyz = sv.type == GL_FLOAT && sv.size == 3 && !(((uintptr_t)sv.p | sv.stride) & 3);
    for (u32 j0 = 0; j0 < nv; j0 += FCH, cb++) {
        u32 j1 = j0 + FCH < nv ? j0 + FCH : nv;
        u32 all;
        if (!box_test(cb, &all)) { memset(oc_buf + j0, 0, j1 - j0); oa = 0; continue; }
        if (fast_xyz) { oc_range(j0, j1, &oo, &oa); continue; }
        for (u32 j = j0; j < j1; j++) {
            const u8 *p = sv.p + gvert(j) * sv.stride;
            if (sv.type == GL_FLOAT) { v.x = ldf(p); v.y = ldf(p + 4); v.z = sv.size > 2 ? ldf(p + 8) : 0; }
            else { s16 a, b, c = 0; memcpy(&a, p, 2); memcpy(&b, p + 2, 2); if (sv.size > 2) memcpy(&c, p + 4, 2); v.x = a; v.y = b; v.z = c; }
            int o = outcode(&v);
            oc_buf[j] = (u8)o; oo |= o; oa &= o;
        }
    }
    *oc_or = oo; *oc_and = oa;
}

/* ---------- drawing */
static void emit_generic(u32 *d, u32 nv, int *oc_or, int *oc_and) {
    int o_or = 0, o_and = 0xff;
    vtx v;
    for (u32 j = 0; j < nv; j++) {
        fetch(gvert(j), &v);
        d = emit(d, &v);
        int o = outcode(&v);
        oc_buf[j] = (u8)o; o_or |= o; o_and &= o;
    }
    *oc_or = o_or; *oc_and = o_and;
}
static void emit_verts(u32 *d, u32 nv, int *oc_or, int *oc_and) {
    if (!d_fast) { emit_generic(d, nv, oc_or, oc_and); return; }
    fbox bx;
    fast_emit(d, nv, &bx);
    if (!box_codes(&bx, oc_or, oc_and)) fast_outcodes(nv, oc_or, oc_and);
}
static u32 *emit_all(u32 nv, u32 vsize, int *oc_or, int *oc_and) {
    u32 *vbuf = sceGuGetMemory(nv * vsize);
    emit_verts(vbuf, nv, oc_or, oc_and);
    return vbuf;
}
/* gldbg 64: both paths into cached buffers; vertex words and the draw decision must match */
static void fast_check(u32 nv, u32 vsize) {
    static u32 *ga, *fa; static u32 gcap, fcap, n_draws, n_bad, n_vbad, n_dec;
    if (!d_fast) return;
    ga = grow(ga, &gcap, nv * vsize / 4, 4); fa = grow(fa, &fcap, nv * vsize / 4, 4);
    int go, gand, fo, fand;
    static u8 *gob; static u32 gobcap; static u32 n_ocbad;
    emit_generic(ga, nv, &go, &gand);
    gob = grow(gob, &gobcap, nv, 1); memcpy(gob, oc_buf, nv);
    emit_verts(fa, nv, &fo, &fand);
    if (!gand && (go & OC_CLIP) && memcmp(gob, oc_buf, nv)) { n_ocbad++; if (n_ocbad <= 20) rt_log("[gl] fastcheck: per-vertex outcodes differ (%u vertices)", nv); }
    n_draws++;
    u32 nw = nv * vsize / 4, bad = 0, first = 0;
    for (u32 i = 0; i < nw; i++) if (ga[i] != fa[i]) { if (!bad) first = i; bad++; }
    int gdec = gand ? 2 : (go & OC_CLIP) ? 1 : 0, fdec = fand ? 2 : (fo & OC_CLIP) ? 1 : 0;
    if (bad) { n_bad++; n_vbad += bad; if (n_bad <= 20) rt_log("[gl] fastcheck: %u/%u words differ (first %u: %08x vs %08x), fmt %d/%d/%d expand %d", bad, nw, first, ga[first], fa[first], fp_pk, fp_ck, fp_tk, d_expand); }
    if (gdec != fdec) { n_dec++; if (n_dec <= 20) rt_log("[gl] fastcheck: decision %d (generic) vs %d (fast), oc %x/%x vs %x/%x", gdec, fdec, go, gand, fo, fand); }
    if ((n_draws & 1023) == 0) rt_log("[gl] fastcheck: %u draws, %u with vertex differences (%u words), %u decisions differ", n_draws, n_bad, n_vbad, n_dec);
}
static void draw_(u32 mode, u32 n, const u8 *i8, const u16 *i16, u32 first);
static u32 st_draw_us;
static void draw(u32 mode, u32 n, const u8 *i8, const u16 *i16, u32 first) {
    if (!rt_verbose) { draw_(mode, n, i8, i16, first); return; }
    u64 t0 = plat_time_us();
    draw_(mode, n, i8, i16, first);
    st_draw_us += (u32)(plat_time_us() - t0);
}
static void draw_(u32 mode, u32 n, const u8 *i8, const u16 *i16, u32 first) {
    if (!gu_ready || !n || !A_v.on) return;
    int gem;
    switch (mode) {
    case GL_POINTS: gem = GU_POINTS; break;
    case GL_LINES: gem = GU_LINES; n &= ~1u; break;
    case GL_LINE_STRIP: gem = GU_LINE_STRIP; if (n < 2) return; break;
    case GL_LINE_LOOP: {      /* strip plus the closing vertex */
        if (n < 2) return;
        u16 *tmp = malloc((n + 1) * 2);
        if (!tmp) return;
        for (u32 i = 0; i < n; i++) tmp[i] = (u16)(i16 ? i16[i] : i8 ? i8[i] : first + i);
        tmp[n] = tmp[0];
        draw(GL_LINE_STRIP, n + 1, 0, tmp, 0);
        free(tmp);
        return;
    }
    case GL_TRIANGLES: gem = GU_TRIANGLES; n -= n % 3; break;
    case GL_TRIANGLE_STRIP: gem = GU_TRIANGLE_STRIP; if (n < 3) return; break;
    case GL_TRIANGLE_FAN: gem = GU_TRIANGLE_FAN; if (n < 3) return; break;
    default: ONCE("unsupported primitive %x", mode); return;
    }
    if (!n) return;
    int tris = gem >= GU_TRIANGLES;
    if (tris && S.cull && S.cull_face == GL_FRONT_AND_BACK) return;
    /* the GL viewport also clips: scissor = viewport (and the scissor box) */
    int r[4], q[4];
    if (!rect_map(S.vp[0], S.vp[1], S.vp[2], S.vp[3], r)) return;
    if (S.stest) {
        if (!rect_map(S.sc[0], S.sc[1], S.sc[2], S.sc[3], q)) return;
        if (q[0] > r[0]) r[0] = q[0];
        if (q[1] > r[1]) r[1] = q[1];
        if (q[2] < r[2]) r[2] = q[2];
        if (q[3] < r[3]) r[3] = q[3];
        if (r[2] <= r[0] || r[3] <= r[1]) return;
    }
    tex_t *t = 0;
    if (S.tex_en[0] && S.tex_bound[0] < MAXTEX) { t = texs[S.tex_bound[0]]; if (t && !t->nlev) t = 0; }
    if (S.tex_en[1]) ONCE("NOTE: texture unit 1 enabled (ignored)");
    set_src(&sv, &A_v); set_src(&sc, &A_c); set_src(&sn, &A_n); set_src(&st, &A_t[0]);
    f_tex = t != 0; f_lit = S.lighting; f_tm = !tm_ident;
    d_fast = fast_fmt();
    /* vertex range */
    u32 nv, ni = 0;
    d_i8 = i8; d_i16 = i16; d_expand = 0; d_vmin = first;
    if (i8 || i16) {
        s32 lo = 0x7fffffff, hi = -1;
        if (i16) for (u32 k = 0; k < n; k++) { s32 v = i16[k]; lo = v < lo ? v : lo; hi = v > hi ? v : hi; }
        else for (u32 k = 0; k < n; k++) { s32 v = i8[k]; lo = v < lo ? v : lo; hi = v > hi ? v : hi; }
        nv = (u32)(hi - lo + 1); d_vmin = (u32)lo;
        if (nv > 2 * n + 32) { d_expand = 1; nv = n; }      /* sparse indices: emit vertices in index order */
        else ni = n;                                         /* the game's indices, drawn with the base moved back by lo */
    } else nv = n;
    if (nv > 65535 || ni > 65535) { ONCE("draw with %u vertices skipped", nv); return; }
    u32 vsize = (f_tex ? 8 : 0) + 4 + (f_lit ? 12 : 0) + 12;
    int vt = (f_tex ? GU_TEXTURE_32BITF : 0) | GU_COLOR_8888 | (f_lit ? GU_NORMAL_32BITF : 0) | GU_VERTEX_32BITF | GU_TRANSFORM_3D;
    u32 need = nv * vsize + ni * 2 + 1024;
    if (need > DL_SIZE / 2) { ONCE("draw too large for the display list (%u vertices)", nv); return; }
    if (dl_room() < need) list_flush();
    apply_state(t);
    ge_scissor(r[0], r[1], r[2], r[3]);
    oc_buf = grow(oc_buf, &oc_cap, nv, 1);
    if (gl_dbg & 64) fast_check(nv, vsize);
    int o_or, o_and;
    u32 *vbuf = emit_all(nv, vsize, &o_or, &o_and);
    st_draws++;
    if (gl_log > 0) {
        vtx v0; fetch(gvert(0), &v0); float c[4]; clipc(&v0, c);
        rt_log("[gl]   fmt v %x/%d/%u c %x/%d/%u t %x/%d/%u tm %d expand %d", sv.type, sv.size, sv.stride, sc.p ? sc.type : 0, sc.size, sc.stride,
               st.p ? st.type : 0, st.size, st.stride, f_tm, d_expand);
        rt_log("[gl]   gem %d n %u nv %u ni %u tex %d (%ux%u psm %d lv %d) lit %d sc %d,%d-%d,%d oc %x/%x v0 (%.2f %.2f %.2f) col %08x uv %.3f,%.3f -> clip (%.2f %.2f %.2f %.2f) blend %d %x/%x atest %d (%x %.3f) dtest %d cull %d",
               gem, n, nv, ni, t ? (int)S.tex_bound[0] : -1, t ? t->w : 0, t ? t->h : 0, t ? t->psm : 0, t ? t->nlev : 0, f_lit, r[0], r[1], r[2], r[3],
               o_or, o_and, v0.x, v0.y, v0.z, v0.c, v0.u, v0.v, c[0], c[1], c[2], c[3], S.blend, S.bsrc, S.bdst, S.atest, S.afunc, S.aref, S.dtest, S.cull);
    }
    if (o_and) return;                                   /* entirely outside one plane */
    if (!(o_or & OC_CLIP)) {                             /* fast path */
        if (ni) {
            u32 isz = i16 ? ni * 2 : ni;
            void *ib = sceGuGetMemory((isz + 3) & ~3u);
            memcpy(ib, i16 ? (const void *)i16 : (const void *)i8, isz);
            sceGuDrawArray(gem, vt | (i16 ? GU_INDEX_16BIT : GU_INDEX_8BIT), ni, ib, (const u8 *)vbuf - d_vmin * vsize);
        } else sceGuDrawArray(gem, vt, nv, 0, vbuf);
        st_tris += tris ? (gem == GU_TRIANGLES ? (ni ? ni : nv) / 3 : (ni ? ni : nv) - 2) : 0;
        return;
    }
    /* slow path: primitives fully inside are drawn indexed from vbuf, the others are clipped */
    st_slow++;
    if (ni) {
        li_buf = grow(li_buf, &li_cap, ni, 2);
        if (i16) for (u32 k = 0; k < ni; k++) li_buf[k] = (u16)(i16[k] - d_vmin);
        else for (u32 k = 0; k < ni; k++) li_buf[k] = (u16)(i8[k] - d_vmin);
    }
    u32 cnt = ni ? ni : nv, nt = 0;
#define LI(k) (ni ? li_buf[k] : (u16)(k))
    clip_n = 0;
    if (tris) {
        u32 ntri = gem == GU_TRIANGLES ? cnt / 3 : cnt - 2;
        tri_buf = grow(tri_buf, &tri_cap, ntri * 3, 2);
        for (u32 i = 0; i < ntri; i++) {
            u32 a, b, c;
            if (gem == GU_TRIANGLES) { a = LI(3 * i); b = LI(3 * i + 1); c = LI(3 * i + 2); }
            else if (gem == GU_TRIANGLE_STRIP) { if (i & 1) { a = LI(i + 1); b = LI(i); } else { a = LI(i); b = LI(i + 1); } c = LI(i + 2); }
            else { a = LI(0); b = LI(i + 1); c = LI(i + 2); }
            int o0 = oc_buf[a], o1 = oc_buf[b], o2 = oc_buf[c];
            if (o0 & o1 & o2) continue;
            if (!((o0 | o1 | o2) & OC_CLIP)) { tri_buf[nt++] = (u16)a; tri_buf[nt++] = (u16)b; tri_buf[nt++] = (u16)c; continue; }
            if (a == b || b == c || a == c) continue;        /* degenerate (strip joints) */
            vtx va, vb2, vc;
            fetch(gvert(a), &va); fetch(gvert(b), &vb2); fetch(gvert(c), &vc);
            clip_tri(&va, &vb2, &vc, o0 | o1 | o2);
        }
        st_tris += nt / 3 + clip_n / 3;
    } else {      /* points and lines: keep only primitives fully inside */
        int per = gem == GU_POINTS ? 1 : 2;
        u32 nprim = gem == GU_LINE_STRIP ? cnt - 1 : cnt / per;
        tri_buf = grow(tri_buf, &tri_cap, nprim * 2, 2);
        for (u32 i = 0; i < nprim; i++) {
            u32 a = gem == GU_LINE_STRIP ? LI(i) : LI(i * per), b = gem == GU_LINE_STRIP ? LI(i + 1) : per == 2 ? LI(i * 2 + 1) : a;
            if ((oc_buf[a] | oc_buf[b]) & OC_CLIP) continue;
            tri_buf[nt++] = (u16)a;
            if (per == 2) tri_buf[nt++] = (u16)b;
        }
        if (gem == GU_LINE_STRIP) gem = GU_LINES;
    }
#undef LI
    u32 more = nt * 2 + clip_n * vsize + 512;
    if (dl_room() < more) {                              /* re-emit the vertices into a fresh list */
        if (more + nv * vsize > DL_SIZE / 2) { ONCE("clipped draw too large"); return; }
        list_flush();
        vbuf = emit_all(nv, vsize, &o_or, &o_and);
        if (t) t->last_list = list_seq;
    }
    if (nt) {
        u16 *ib = sceGuGetMemory((nt * 2 + 3) & ~3u);
        memcpy(ib, tri_buf, nt * 2);
        sceGuDrawArray(tris ? GU_TRIANGLES : gem, vt | GU_INDEX_16BIT, nt, ib, vbuf);
    }
    if (clip_n) {
        u32 *cb = sceGuGetMemory(clip_n * vsize), *d = cb;
        for (u32 i = 0; i < clip_n; i++) d = emit(d, &clip_out[i]);
        sceGuDrawArray(GU_TRIANGLES, vt, clip_n, 0, cb);
    }
}

/* ---------- frames */
static void set_area(void) {
    int x = psp_stretch ? 0 : 36, w = psp_stretch ? 480 : 408;
    static int vp_set;
    if (vp_set && x == area_x && w == area_w) return;
    vp_set = 1; area_x = x; area_w = w;
    sceGuViewport(2048 + x + w / 2 - 240, 2048, w, 272);
}
static void begin_frame(void) {
    sceGuStart(GU_DIRECT, dlist);
    list_seq++;
    /* Re-send fog registers for the first draw every frame. */
    ge_en[GU_FOG] = -1; G.fog_s = NAN;
    set_area();
    ge_scissor(0, 0, 480, 272);
    if (G.pmask != 0) { G.pmask = 0; sceGuPixelMask(0); }
    sceGuClearColor(gl_dbg & 8 ? 0xff0000ffu : 0xff000000u);
    sceGuClearDepth(0);
    sceGuClear(GU_COLOR_BUFFER_BIT | GU_DEPTH_BUFFER_BIT);
    if (gl_dbg & 16) {      /* test triangles: identity matrices (green) and the current PF (yellow) */
        typedef struct { u32 c; float x, y, z; } tv;
        tv *v = sceGuGetMemory(6 * sizeof(tv));
        float P[6][2] = {{-0.5f, -0.5f}, {0.5f, -0.5f}, {0, 0.5f}, {-0.9f, -0.9f}, {-0.6f, -0.9f}, {-0.75f, -0.6f}};
        for (int i = 0; i < 6; i++) { v[i].c = i < 3 ? 0xff00ff00u : 0xff00ffffu; v[i].x = P[i][0]; v[i].y = P[i][1]; v[i].z = 0; }
        sceGuDisable(GU_TEXTURE_2D); sceGuDisable(GU_BLEND); sceGuDisable(GU_DEPTH_TEST); sceGuDisable(GU_CULL_FACE); sceGuDisable(GU_ALPHA_TEST);
        sceGuSetMatrix(GU_PROJECTION, (const ScePspFMatrix4 *)IDM);
        sceGuSetMatrix(GU_MODEL, (const ScePspFMatrix4 *)IDM);
        sceGuDrawArray(GU_TRIANGLES, GU_COLOR_8888 | GU_VERTEX_32BITF | GU_TRANSFORM_3D, 6, 0, v);
        ge_invalidate(); pf_dirty = 1;
    }
}
static void draw_cursor(void) {
    typedef struct { u32 c; s16 x, y, z, pad; } pv;
    int cx = area_x + (int)(psp_cursor_x * area_w / 480), cy = (int)(psp_cursor_y * 272 / 320);
    static const s8 R[4][4] = {{-7, -2, 8, 3}, {-2, -7, 3, 8}, {-6, -1, 7, 2}, {-1, -6, 2, 7}};
    ge_scissor(0, 0, 480, 272);
    ge_set(GU_TEXTURE_2D, 0); ge_set(GU_BLEND, 0); ge_set(GU_DEPTH_TEST, 0); ge_set(GU_ALPHA_TEST, 0);
    ge_set(GU_FOG, 0); ge_set(GU_LIGHTING, 0); ge_set(GU_CULL_FACE, 0);
    if (G.pmask != 0) { G.pmask = 0; sceGuPixelMask(0); }
    if (G.dmask != 1) { G.dmask = 1; sceGuDepthMask(1); }
    pv *v = sceGuGetMemory(8 * sizeof(pv));
    for (int i = 0; i < 4; i++) {
        u32 col = i < 2 ? 0xff000000u : 0xffffffffu;
        v[2 * i].c = col; v[2 * i].x = (s16)(cx + R[i][0]); v[2 * i].y = (s16)(cy + R[i][1]); v[2 * i].z = 0; v[2 * i].pad = 0;
        v[2 * i + 1].c = col; v[2 * i + 1].x = (s16)(cx + R[i][2]); v[2 * i + 1].y = (s16)(cy + R[i][3]); v[2 * i + 1].z = 0; v[2 * i + 1].pad = 0;
    }
    sceGuDrawArray(GU_SPRITES, GU_COLOR_8888 | GU_VERTEX_16BIT | GU_TRANSFORM_2D, 8, 0, v);
}
void gl_psp_init(void) {
    if (gu_ready) return;
    m_ident(MV); m_ident(PR); m_ident(TM); m_ident(IDM);
    state_defaults();
    sceKernelDcacheWritebackInvalidateRange(dlist, sizeof dlist);   /* the list is written through uncached addresses */
    sceGuInit();
    sceGuStart(GU_DIRECT, dlist);
    sceGuDrawBuffer(GU_PSM_5650, (void *)FB0, 512);
    sceGuDispBuffer(480, 272, (void *)FB1, 512);
    sceGuDepthBuffer((void *)ZBUF, 512);
    sceGuOffset(2048 - 240, 2048 - 136);
    sceGuDepthRange(65535, 0);
    /* drawing region = whole screen (libpspgu only sets it through sceGuScissor / GU_SCISSOR_TEST) */
    sceGuSendCommandi(21, 0);
    sceGuSendCommandi(22, (271 << 10) | 479);
    ge_invalidate();
    ge_set(GU_CLIP_PLANES, 1);
    sceGuTexLevelMode(GU_TEXTURE_AUTO, 0);
    sceGuTexMapMode(GU_TEXTURE_COORDS, 0, 0);
    sceGuTexScale(1, 1);
    sceGuTexOffset(0, 0);
    sceGuLightMode(GU_SINGLE_COLOR);
    sceGuSetMatrix(GU_VIEW, (const ScePspFMatrix4 *)IDM);
    sceGuSetMatrix(GU_TEXTURE, (const ScePspFMatrix4 *)IDM);
    static const ScePspIMatrix4 dith = {{-4, 0, -3, 1}, {2, -2, 3, -1}, {-3, 1, -4, 0}, {3, -1, 2, -2}};
    sceGuSetDither(&dith);
    ge_set(GU_DITHER, 1);
    sceGuFinish();
    sceGuSync(0, 0);
    sceDisplayWaitVblankStart();
    sceGuDisplay(GU_TRUE);
    u32 vend = sceGeEdramGetSize();
    if (vend > 0x200000) vend = 0x200000;
    vram_init(VPOOL, vend);
    tex_reserve = MEM_SIZE < (28u << 20) ? (3u << 20) : (2u << 20);
    gu_ready = 1;
    rt_log("[gl] GE ready: %u KB VRAM for textures, texture limit %d (paletted %d), %s", vram_size >> 10, tex_lim(), tex_lim_pal(), psp_stretch ? "stretched" : "4:3 area");
    begin_frame();
}
void gl_psp_shutdown(void) { if (!gu_ready) return; sceGuFinish(); sceGuSync(0, 0); sceGuTerm(); gu_ready = 0; }
static int movie_presenting;
void gl_present(void) {
    if (!gu_ready) return;
    if (!movie_presenting && manual_is_open()) { manual_draw(area_x, area_w); ge_invalidate(); pf_dirty = 1; }
    else if (!movie_presenting && psp_cursor_on) draw_cursor();
    u64 ta = plat_time_us();
    sceGuFinish();
    sceGuSync(0, 0);
    u64 tb = plat_time_us();
    st_gewait += (u32)(tb - ta);
    free_deferred();
    /* Limit actual presentation independently of config fps. A rolling
       deadline prevents vblank quantization from accumulating drift. */
    static u64 present_due;
    u64 now=plat_time_us();
    if (!present_due) present_due=now;
    if (psp_vsync) {
        do {
            if (present_due > now + 18000) plat_sleep_us((u32)(present_due-now-17000));
            sceDisplayWaitVblankStart();
            now=plat_time_us();
        } while (now < present_due);
    } else {
        while (now < present_due) { plat_sleep_us((u32)(present_due-now)); now=plat_time_us(); }
    }
    if (now > present_due + 43478) present_due=now;
    present_due += 43478;
    st_vwait += (u32)(plat_time_us() - tb);
    sceGuSwapBuffers();
    draw_off ^= FB0 ^ FB1;
    frames++;
    if (gl_log > 0) { rt_log("[gl] ---- present frame %u: %u draws (%u clipped), %u tris", frames, st_draws, st_slow, st_tris); gl_log--; }
    if (rt_verbose && (frames % 60) == 0) {
        u64 now = plat_time_us();
        static u64 idle0;
        u32 idle = (u32)(rt_idle_us - idle0), wall = st_t60 ? (u32)(now - st_t60) : 1;
        idle0 = rt_idle_us;
        extern volatile u32 audio_busy_us;
        static u32 abusy0;
        u32 abusy = audio_busy_us - abusy0;
        abusy0 = audio_busy_us;
        rt_log("[gl] %.1f fps, per frame: GE wait %u us, vblank wait %u us, idle %u us; CPU busy %u%% (GL draws %u us, audio thread %u us)",
               st_t60 ? 60e6 / (double)wall : 0.0, st_gewait / 60, st_vwait / 60, idle / 60,
               st_t60 ? (u32)(100.0 * (1.0 - (double)(idle + st_gewait + st_vwait) / wall)) : 0, st_draw_us / 60, abusy / 60);
        st_t60 = now; st_gewait = st_vwait = st_draw_us = 0;
        rt_log("[gl] frame %u: %u draws, %u clipped draws, %u clipped tris, %u tris; textures %u (VRAM %u/%u KB, %u in RAM); heap free %u KB (min %u KB)",
               frames, st_draws, st_slow, st_clip, st_tris, tex_count, vram_used >> 10, vram_size >> 10, tex_main_allocs,
               heap_free_bytes() >> 10, heap_min_free() >> 10);
        if (rt_verbose > 1) {
            struct mallinfo mi = mallinfo();
            rt_log("[gl] host heap: %d KB in use, %d KB arena; main stack free %d KB", mi.uordblks >> 10, mi.arena >> 10,
                   sceKernelGetThreadStackFreeSize(0) >> 10);
        }
    }
    st_draws = st_tris = st_slow = st_clip = 0;
    if (gl_log_at && frames == (u32)gl_log_at) gl_log = gl_log_n;
    begin_frame();
}

/* The normal renderer owns the active GU list. Draw the movie into it,
   finish through gl_present, then invalidate guest state for the next frame. */
void gl_movie_frame(const u16 *pixels) {
    if (!gu_ready || !pixels) return;
    typedef struct {float u,v; s16 x,y,z,pad;} vtx;
    sceKernelDcacheWritebackRange(pixels,512*273*2);
    sceGuDisable(GU_DEPTH_TEST);sceGuDisable(GU_ALPHA_TEST);sceGuDisable(GU_BLEND);
    sceGuDisable(GU_FOG);sceGuDisable(GU_LIGHTING);sceGuDisable(GU_CULL_FACE);
    sceGuEnable(GU_SCISSOR_TEST);sceGuScissor(0,0,480,272);sceGuPixelMask(0);
    sceGuEnable(GU_TEXTURE_2D);sceGuTexMode(GU_PSM_5650,0,0,0);
    sceGuTexImage(0,512,512,512,pixels);sceGuTexFunc(GU_TFX_REPLACE,GU_TCC_RGB);
    sceGuTexFilter(GU_LINEAR,GU_LINEAR);sceGuTexWrap(GU_CLAMP,GU_CLAMP);
    sceGuTexScale(1,1);sceGuTexOffset(0,0);sceGuTexMapMode(GU_TEXTURE_COORDS,0,0);sceGuTexFlush();
    vtx *v=sceGuGetMemory(2*sizeof *v);v[0]=(vtx){0,0,0,0,0,0};v[1]=(vtx){480,272,480,272,0,0};
    sceGuDrawArray(GU_SPRITES,GU_TEXTURE_32BITF|GU_VERTEX_16BIT|GU_TRANSFORM_2D,2,0,v);
    ge_invalidate();pf_dirty=1;movie_presenting=1;gl_present();movie_presenting=0;
}

/* ---------- framebuffer objects: the EAGL renderbuffer is the screen; FBOs with textures are not rendered */
#define MAXFB 32
static u32 fb_next = 1, rb_next = 1, cur_fb, cur_rb, fb_tex[MAXFB];
static int rb_w[MAXFB], rb_h[MAXFB], offscreen;
static u32 rb_fmt[MAXFB];
void gl_drawable_storage(int w, int h) {
    if (cur_rb < MAXFB) { rb_w[cur_rb] = w; rb_h[cur_rb] = h; rb_fmt[cur_rb] = 0x8058; }
    FW = w; FH = h; pf_dirty = 1;
    rt_log("[gl] drawable storage %dx%d on renderbuffer %u", w, h, cur_rb);
}
IMPORT(glGenFramebuffersOES) { for (u32 i = 0; i < r0; i++) WR32(r1 + 4 * i, fb_next < MAXFB ? fb_next++ : MAXFB - 1); RET(0); }
IMPORT(glGenRenderbuffersOES) { for (u32 i = 0; i < r0; i++) WR32(r1 + 4 * i, rb_next < MAXFB ? rb_next++ : MAXFB - 1); RET(0); }
IMPORT(glDeleteFramebuffersOES) { for (u32 i = 0; i < r0; i++) { u32 f = RD32(r1 + 4 * i); if (f < MAXFB) fb_tex[f] = 0; if (f == cur_fb) { cur_fb = 0; offscreen = 0; } } RET(0); }
IMPORT(glDeleteRenderbuffersOES) { RET(0); }
IMPORT(glBindFramebufferOES) { cur_fb = r1; offscreen = r1 < MAXFB && fb_tex[r1] != 0; L("BindFramebuffer %u", r1); RET(0); }
IMPORT(glBindRenderbufferOES) { cur_rb = r1; RET(0); }
IMPORT(glRenderbufferStorageOES) { if (cur_rb < MAXFB) { rb_fmt[cur_rb] = r1; rb_w[cur_rb] = r2; rb_h[cur_rb] = r3; } RET(0); }
IMPORT(glFramebufferRenderbufferOES) { if (r1 == GL_COLOR_ATTACHMENT0 && cur_fb < MAXFB) { fb_tex[cur_fb] = 0; offscreen = 0; } RET(0); }
IMPORT(glFramebufferTexture2DOES) {
    if (r1 == GL_COLOR_ATTACHMENT0 && cur_fb < MAXFB) { fb_tex[cur_fb] = r3; offscreen = r3 != 0; }
    ONCE("render to texture is not supported: framebuffer %u (texture %u) is not drawn", cur_fb, r3);
    RET(0); }
IMPORT(glCheckFramebufferStatusOES) { RET(GL_FRAMEBUFFER_COMPLETE); }
IMPORT(glGetRenderbufferParameterivOES) {
    s32 v = 0;
    if (cur_rb < MAXFB) v = r1 == GL_RENDERBUFFER_WIDTH ? rb_w[cur_rb] : r1 == GL_RENDERBUFFER_HEIGHT ? rb_h[cur_rb] : r1 == GL_RENDERBUFFER_INTERNAL_FORMAT ? (s32)rb_fmt[cur_rb] : 8;
    WR32(r2, (u32)v); RET(0); }

/* ---------- state entry points */
static void cap(u32 c, int on) {
    switch (c) {
    case GL_TEXTURE_2D: S.tex_en[act_tex] = on; break;
    case GL_LIGHTING: S.lighting = on; break;
    case GL_COLOR_MATERIAL: S.colmat = on; light_ver++; break;
    case GL_FOG: S.fog = on; break;
    case GL_ALPHA_TEST: S.atest = on; break;
    case GL_BLEND: S.blend = on; break;
    case GL_DEPTH_TEST: S.dtest = on; break;
    case GL_CULL_FACE: S.cull = on; break;
    case GL_SCISSOR_TEST: S.stest = on; break;
    case GL_POLYGON_OFFSET_FILL: S.pofs = on; break;
    case GL_NORMALIZE: case GL_RESCALE_NORMAL: case GL_DITHER: case 0x0B10: case 0x0B20: case 0x809D: case 0x809E: case 0x809F: case 0x0B90: break;
    default:
        if (c >= GL_LIGHT0 && c < GL_LIGHT0 + 8) { LT[c - GL_LIGHT0].on = on; light_ver++; }
        else ONCE("glEnable/glDisable of unhandled capability %x", c);
    }
}
IMPORT(glEnable) { L("Enable %x", r0); cap(r0, 1); RET(0); }
IMPORT(glDisable) { L("Disable %x", r0); cap(r0, 0); RET(0); }
IMPORT(glActiveTexture) { act_tex = (r0 - GL_TEXTURE0) & 1; RET(0); }
IMPORT(glClientActiveTexture) { client_tex = (r0 - GL_TEXTURE0) & 1; RET(0); }
IMPORT(glAlphaFunc) { S.afunc = r0; S.aref = F(r1); RET(0); }
IMPORT(glBlendFunc) { S.bsrc = r0; S.bdst = r1; RET(0); }
IMPORT(glClearColor) { S.clear_col[0] = F(r0); S.clear_col[1] = F(r1); S.clear_col[2] = F(r2); S.clear_col[3] = F(r3); RET(0); }
IMPORT(glColor4f) { float c[4] = {F(r0), F(r1), F(r2), F(r3)}; cur_color = pack4(c); RET(0); }
IMPORT(glColorMask) { S.cmask[0] = (r0 & 0xff) != 0; S.cmask[1] = (r1 & 0xff) != 0; S.cmask[2] = (r2 & 0xff) != 0; S.cmask[3] = (r3 & 0xff) != 0; RET(0); }
IMPORT(glCullFace) { S.cull_face = r0; RET(0); }
IMPORT(glFrontFace) { S.front_face = r0; RET(0); }
IMPORT(glDepthFunc) { S.dfunc = r0; RET(0); }
IMPORT(glDepthMask) { S.dmask = (r0 & 0xff) != 0; RET(0); }
IMPORT(glHint) { RET(0); }
IMPORT(glShadeModel) { S.shade = r0; RET(0); }
IMPORT(glPolygonOffset) { S.pofs_factor = F(r0); S.pofs_units = F(r1); RET(0); }
IMPORT(glScissor) { S.sc[0] = (s32)r0; S.sc[1] = (s32)r1; S.sc[2] = (s32)r2; S.sc[3] = (s32)r3; RET(0); }
IMPORT(glViewport) { S.vp[0] = (s32)r0; S.vp[1] = (s32)r1; S.vp[2] = (s32)r2; S.vp[3] = (s32)r3; pf_dirty = 1; L("Viewport %d %d %d %d", r0, r1, r2, r3); RET(0); }
IMPORT(glPixelStorei) { if (r0 == GL_UNPACK_ALIGNMENT && (r1 == 1 || r1 == 2 || r1 == 4 || r1 == 8)) S.unpack_align = (int)r1; RET(0); }
IMPORT(glGetError) { RET(0); }
IMPORT(glGetIntegerv) {
    s32 v[4] = {0, 0, 0, 0};
    int n = 1;
    switch (r0) {
    case GL_MAX_TEXTURE_SIZE: v[0] = 1024; break;
    case GL_MAX_TEXTURE_UNITS: v[0] = 2; break;
    case GL_MAX_LIGHTS: v[0] = 8; break;
    case GL_MAX_VIEWPORT_DIMS: v[0] = v[1] = 2048; n = 2; break;
    case GL_VIEWPORT: memcpy(v, S.vp, 16); n = 4; break;
    case GL_SCISSOR_BOX: memcpy(v, S.sc, 16); n = 4; break;
    case GL_FRAMEBUFFER_BINDING: v[0] = (s32)cur_fb; break;
    case GL_RENDERBUFFER_BINDING: v[0] = (s32)cur_rb; break;
    case GL_TEXTURE_BINDING_2D: v[0] = (s32)S.tex_bound[act_tex]; break;
    case GL_MAX_MODELVIEW_STACK_DEPTH: case GL_MAX_PROJECTION_STACK_DEPTH: case GL_MAX_TEXTURE_STACK_DEPTH: v[0] = 16; break;
    default: ONCE("glGetIntegerv of unhandled %x", r0); break;
    }
    for (int i = 0; i < n; i++) WR32(r1 + 4 * i, (u32)v[i]);
    RET(0); }
IMPORT(glClear) {
    if (!gu_ready || offscreen) RET(0);
    int flags = 0;
    if ((r0 & GL_COLOR_BUFFER_BIT) && (S.cmask[0] || S.cmask[1] || S.cmask[2])) flags |= GU_COLOR_BUFFER_BIT;
    if ((r0 & GL_DEPTH_BUFFER_BIT) && S.dmask) flags |= GU_DEPTH_BUFFER_BIT;
    if (!flags) RET(0);
    int r[4];
    if (S.stest) { if (!rect_map(S.sc[0], S.sc[1], S.sc[2], S.sc[3], r)) RET(0); }
    else { r[0] = area_x; r[1] = 0; r[2] = area_x + area_w; r[3] = 272; }
    if (dl_room() < 1024) list_flush();
    ge_scissor(r[0], r[1], r[2], r[3]);
    u32 pm = (S.cmask[0] ? 0 : 0xffu) | (S.cmask[1] ? 0 : 0xff00u) | (S.cmask[2] ? 0 : 0xff0000u);
    if (G.pmask != pm) { G.pmask = pm; sceGuPixelMask(pm); }
    sceGuClearColor(pack4(S.clear_col));
    sceGuClearDepth(0);
    sceGuClear(flags);
    L("Clear %x", r0);
    RET(0); }

/* ---------- fog, lights, materials */
static void fog_param(u32 pn, const float *v) {
    switch (pn) {
    case GL_FOG_MODE: S.fog_mode = (u32)v[0]; break;
    case GL_FOG_DENSITY: S.fog_density = v[0]; break;
    case GL_FOG_START: S.fog_start = v[0]; break;
    case GL_FOG_END: S.fog_end = v[0]; break;
    case GL_FOG_COLOR: memcpy(S.fog_col, v, 16); break;
    }
}
IMPORT(glFogf) { float v[4] = {F(r1), 0, 0, 0}; fog_param(r0, v); RET(0); }
IMPORT(glFogfv) { float v[4] = {0, 0, 0, 0}; rdv(r1, v, r0 == GL_FOG_COLOR ? 4 : 1); fog_param(r0, v); RET(0); }
IMPORT(glLightModelf) { RET(0); }
IMPORT(glLightModelfv) { if (r0 == GL_LIGHT_MODEL_AMBIENT) { rdv(r1, model_amb, 4); light_ver++; } RET(0); }
static int lv_count(u32 pname) {
    switch (pname) {
    case GL_AMBIENT: case GL_DIFFUSE: case GL_SPECULAR: case GL_POSITION: case GL_EMISSION: case GL_AMBIENT_AND_DIFFUSE: return 4;
    case GL_SPOT_DIRECTION: return 3;
    default: return 1;
    }
}
static void xform4(const float *m, const float *v, float *o) { for (int i = 0; i < 4; i++) o[i] = m[i] * v[0] + m[4 + i] * v[1] + m[8 + i] * v[2] + m[12 + i] * v[3]; }
static void xform3(const float *m, const float *v, float *o) { for (int i = 0; i < 3; i++) o[i] = m[i] * v[0] + m[4 + i] * v[1] + m[8 + i] * v[2]; }
static void light_param(u32 li, u32 pn, const float *v) {
    if (li < GL_LIGHT0 || li >= GL_LIGHT0 + 8) return;
    light_t *l = &LT[li - GL_LIGHT0];
    switch (pn) {
    case GL_AMBIENT: memcpy(l->amb, v, 16); break;
    case GL_DIFFUSE: memcpy(l->dif, v, 16); break;
    case GL_SPECULAR: memcpy(l->spe, v, 16); break;
    case GL_POSITION: xform4(MV, v, l->pos); break;          /* stored in eye space, like GL */
    case GL_SPOT_DIRECTION: xform3(MV, v, l->dir); break;
    case GL_SPOT_EXPONENT: l->exp = v[0]; break;
    case GL_SPOT_CUTOFF: l->cut = v[0]; break;
    case GL_CONSTANT_ATTENUATION: l->att[0] = v[0]; break;
    case GL_LINEAR_ATTENUATION: l->att[1] = v[0]; break;
    case GL_QUADRATIC_ATTENUATION: l->att[2] = v[0]; break;
    }
    light_ver++;
}
static void mat_param(u32 pn, const float *v) {
    switch (pn) {
    case GL_AMBIENT: memcpy(MAT.amb, v, 16); break;
    case GL_DIFFUSE: memcpy(MAT.dif, v, 16); break;
    case GL_AMBIENT_AND_DIFFUSE: memcpy(MAT.amb, v, 16); memcpy(MAT.dif, v, 16); break;
    case GL_SPECULAR: memcpy(MAT.spe, v, 16); break;
    case GL_EMISSION: memcpy(MAT.emi, v, 16); break;
    case GL_SHININESS: MAT.shin = v[0]; break;
    }
    light_ver++;
}
IMPORT(glLightf) { float v[4] = {F(r2), 0, 0, 0}; light_param(r0, r1, v); RET(0); }
IMPORT(glLightfv) { float v[4] = {0, 0, 0, 0}; rdv(r2, v, lv_count(r1)); light_param(r0, r1, v); RET(0); }
IMPORT(glMaterialf) { float v[4] = {F(r2), 0, 0, 0}; mat_param(r1, v); RET(0); }
IMPORT(glMaterialfv) { float v[4] = {0, 0, 0, 0}; rdv(r2, v, lv_count(r1)); mat_param(r1, v); RET(0); }

/* ---------- matrices */
IMPORT(glMatrixMode) { mmode = r0 == GL_PROJECTION ? 1 : r0 == GL_TEXTURE ? 2 : 0; RET(0); }
IMPORT(glLoadIdentity) { m_ident(cur_m()); m_changed(); RET(0); }
IMPORT(glLoadMatrixf) { rdv(r0, cur_m(), 16); m_changed(); RET(0); }
IMPORT(glMultMatrixf) { float m[16]; rdv(r0, m, 16); m_mul(cur_m(), cur_m(), m); m_changed(); RET(0); }
IMPORT(glOrthof) {
    float l = F(r0), r = F(r1), b = F(r2), t = F(r3), n = F(SARG(0)), f = F(SARG(1));
    float m[16] = {2 / (r - l), 0, 0, 0, 0, 2 / (t - b), 0, 0, 0, 0, -2 / (f - n), 0, -(r + l) / (r - l), -(t + b) / (t - b), -(f + n) / (f - n), 1};
    m_mul(cur_m(), cur_m(), m); m_changed(); RET(0); }
IMPORT(glRotatef) {
    float a = F(r0), x = F(r1), y = F(r2), z = F(r3), len = sqrtf(x * x + y * y + z * z);
    if (len == 0) RET(0);
    x /= len; y /= len; z /= len;
    float c, s, q = fmodf(a, 360.f);
    if (q < 0) q += 360;
    if (q == 0) { c = 1; s = 0; } else if (q == 90) { c = 0; s = 1; } else if (q == 180) { c = -1; s = 0; } else if (q == 270) { c = 0; s = -1; }
    else { c = cosf(a * (GU_PI / 180)); s = sinf(a * (GU_PI / 180)); }
    float k = 1 - c;
    float m[16] = {x * x * k + c, y * x * k + z * s, x * z * k - y * s, 0,
                   x * y * k - z * s, y * y * k + c, y * z * k + x * s, 0,
                   x * z * k + y * s, y * z * k - x * s, z * z * k + c, 0, 0, 0, 0, 1};
    m_mul(cur_m(), cur_m(), m); m_changed(); RET(0); }
IMPORT(glTranslatef) {
    float *m = cur_m(), x = F(r0), y = F(r1), z = F(r2);
    for (int i = 0; i < 4; i++) m[12 + i] += m[i] * x + m[4 + i] * y + m[8 + i] * z;
    m_changed(); RET(0); }

/* ---------- client arrays and drawing */
static carray *arr_of(u32 c) {
    switch (c) { case GL_VERTEX_ARRAY: return &A_v; case GL_COLOR_ARRAY: return &A_c; case GL_NORMAL_ARRAY: return &A_n;
    case GL_TEXTURE_COORD_ARRAY: return &A_t[client_tex]; default: return 0; }
}
IMPORT(glEnableClientState) { carray *a = arr_of(r0); if (a) a->on = 1; RET(0); }
IMPORT(glDisableClientState) { carray *a = arr_of(r0); if (a) a->on = 0; RET(0); }
static void set_arr(carray *a, int size, u32 type, u32 stride, u32 ptr) { a->size = size; a->type = type; a->stride = stride; a->ptr = ptr; }
IMPORT(glVertexPointer) { set_arr(&A_v, (int)r0, r1, r2, r3); RET(0); }
IMPORT(glColorPointer) { set_arr(&A_c, (int)r0, r1, r2, r3); RET(0); }
IMPORT(glNormalPointer) { set_arr(&A_n, 3, r0, r1, r2); RET(0); }
IMPORT(glTexCoordPointer) { set_arr(&A_t[client_tex], (int)r0, r1, r2, r3); RET(0); }
IMPORT(glDrawArrays) { L("DrawArrays %x %d %d", r0, r1, r2); if (offscreen) RET(0); draw(r0, r2, 0, 0, r1); RET(0); }
IMPORT(glDrawElements) {
    L("DrawElements %x %d %x %x", r0, r1, r2, r3);
    if (offscreen) RET(0);
    if (r2 == GL_UNSIGNED_BYTE) draw(r0, r1, MEM + r3, 0, 0);
    else draw(r0, r1, 0, (const u16 *)(MEM + r3), 0);
    RET(0); }

/* ---------- texture entry points */
IMPORT(glGenTextures) {
    for (u32 i = 0; i < r0; i++) {
        u32 name = 0;
        for (u32 k = 0; k < MAXTEX - 1 && !name; k++) { u32 c = 1 + (tex_hint + k - 1) % (MAXTEX - 1); if (!texs[c]) name = c; }
        if (!name) { ONCE("out of texture names"); WR32(r1 + 4 * i, 0); continue; }
        texs[name] = tex_new(); tex_hint = name + 1;
        WR32(r1 + 4 * i, name);
    }
    RET(0); }
IMPORT(glDeleteTextures) {
    for (u32 i = 0; i < r0; i++) {
        u32 name = RD32(r1 + 4 * i);
        if (!name || name >= MAXTEX || !texs[name]) continue;
        tex_free_storage(texs[name]);
        free(texs[name]); texs[name] = 0; tex_count--;
        for (int u = 0; u < 2; u++) if (S.tex_bound[u] == name) S.tex_bound[u] = 0;
        if (name < tex_hint) tex_hint = name;
    }
    RET(0); }
IMPORT(glBindTexture) { S.tex_bound[act_tex] = r1; if (r1) tex_get(r1); RET(0); }
static void tex_param(u32 pn, u32 v) {
    tex_t *t = bound_tex();
    if (!t) return;
    switch (pn) {
    case GL_TEXTURE_MIN_FILTER: t->minf = v; break;
    case GL_TEXTURE_MAG_FILTER: t->magf = v; break;
    case GL_TEXTURE_WRAP_S: t->wraps = v; break;
    case GL_TEXTURE_WRAP_T: t->wrapt = v; break;
    case GL_GENERATE_MIPMAP: if (v) ONCE("GL_GENERATE_MIPMAP ignored"); break;
    }
}
IMPORT(glTexParameteri) { tex_param(r1, r2); RET(0); }
IMPORT(glTexParameterf) { tex_param(r1, (u32)F(r2)); RET(0); }
IMPORT(glTexEnvf) { if (r1 == GL_TEXTURE_ENV_MODE) S.env_mode[act_tex] = (u32)F(r2); RET(0); }
IMPORT(glTexEnvfv) {
    if (r1 == GL_TEXTURE_ENV_COLOR) { float v[4]; rdv(r2, v, 4); S.env_color[act_tex] = pack4(v); }
    else if (r1 == GL_TEXTURE_ENV_MODE) S.env_mode[act_tex] = (u32)RDF(r2);
    RET(0); }
IMPORT(glTexImage2D) {   /* target level ifmt w h border fmt type pixels */
    u32 w = r3, h = SARG(0), fmt = SARG(2), type = SARG(3), px = SARG(4);
    if (gl_log > 0 || rt_verbose) rt_log("[gl] TexImage2D tex %u lvl %d ifmt %x %ux%u fmt %x type %x", S.tex_bound[act_tex], (int)r1, r2, w, h, fmt, type);
    tex_t *t = bound_tex();
    if (t && w && h) upload_image(t, (s32)r1, (int)w, (int)h, fmt, type, px);
    RET(0); }
IMPORT(glTexSubImage2D) {   /* target level x y w h fmt type pixels */
    if (gl_log > 0 || rt_verbose) rt_log("[gl] TexSubImage2D lvl %d %d,%d %ux%u", (int)r1, (int)r2, (int)r3, SARG(0), SARG(1));
    tex_t *t = bound_tex();
    if (t && SARG(4)) upload_sub(t, (s32)r1, (int)r2, (int)r3, (int)SARG(0), (int)SARG(1), SARG(2), SARG(3), SARG(4));
    RET(0); }
IMPORT(glCompressedTexImage2D) {   /* target level ifmt w h border size data */
    u32 w = r3, h = SARG(0), data = SARG(3);
    if (gl_log > 0 || rt_verbose) rt_log("[gl] CompressedTexImage2D tex %u lvl %d fmt %x %ux%u size %u", S.tex_bound[act_tex], (int)r1, r2, w, h, SARG(2));
    tex_t *t = bound_tex();
    if (!t || !w || !h || !data) RET(0);
    if (r2 >= 0x8B90 && r2 <= 0x8B99) upload_paletted(t, r2, (s32)r1, (int)w, (int)h, MEM + data);
    else if (r2 >= 0x8C00 && r2 <= 0x8C03) upload_pvrtc(t, r2, (s32)r1, (int)w, (int)h, MEM + data);
    else ONCE("unsupported compressed texture format %x", r2);
    RET(0); }
IMPORT(glCopyTexImage2D) {   /* target level ifmt x y w h border */
    if (gl_log > 0 || rt_verbose) rt_log("[gl] CopyTexImage2D lvl %d %d,%d %ux%u", (int)r1, (int)r3, (int)SARG(0), SARG(1), SARG(2));
    tex_t *t = bound_tex();
    if (t && gu_ready && SARG(1) && SARG(2)) copy_image(t, (s32)r1, (int)r3, (int)SARG(0), (int)SARG(1), (int)SARG(2));
    RET(0); }
