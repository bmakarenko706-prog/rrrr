/* 480x272 JPEG-frame cutscenes and optional streamed MP3, PSP only.
   Frame clock is wall time; late frames are dropped instead of slowing audio. */
#include "rt.h"
#include "platform.h"
#include "psp_movie.h"
#include <jpeglib.h>
#include <setjmp.h>
#include <malloc.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#define MW 480u
#define MH 272u
#define STRIDE 512u
#define TEXROWS 273u
#define MAX_FRAME (256u*1024u)
typedef struct {struct jpeg_error_mgr base;jmp_buf recover;} jpeg_error;
static void bad_jpeg(j_common_ptr c) {jpeg_error *err=(jpeg_error *)c->err;longjmp(err->recover,1);}
static u32 little(const unsigned char *p){return (u32)p[0]|(u32)p[1]<<8|(u32)p[2]<<16|(u32)p[3]<<24;}
static int jpeg_frame(u8 *buf,u32 size,u16 *pixels) {
    struct jpeg_decompress_struct c; jpeg_error e; volatile int created=0;
    memset(&c,0,sizeof c);c.err=jpeg_std_error(&e.base);e.base.error_exit=bad_jpeg;
    if(setjmp(e.recover)) {if(created)jpeg_destroy_decompress(&c);return 0;}
    jpeg_create_decompress(&c);created=1;jpeg_mem_src(&c,buf,size);
    if(jpeg_read_header(&c,TRUE)!=JPEG_HEADER_OK || c.image_width!=MW || c.image_height!=MH){jpeg_destroy_decompress(&c);return 0;}
    c.out_color_space=JCS_RGB;c.do_fancy_upsampling=FALSE;c.dct_method=JDCT_IFAST;
    jpeg_start_decompress(&c);
    if(c.output_width!=MW || c.output_height!=MH || c.output_components!=3){jpeg_destroy_decompress(&c);return 0;}
    u8 row[MW*3];
    while(c.output_scanline<MH) {u32 y=c.output_scanline;JSAMPROW rows[1]={row};jpeg_read_scanlines(&c,rows,1);
        u16 *d=pixels+y*STRIDE;for(u32 x=0;x<MW;x++){u32 r=row[3*x],g=row[3*x+1],b=row[3*x+2];d[x]=(u16)((r>>3)|((g>>2)<<5)|((b>>3)<<11));}
        memset(d+MW,0,(STRIDE-MW)*sizeof *d);
    }
    memcpy(pixels+MH*STRIDE,pixels+(MH-1)*STRIDE,STRIDE*sizeof *pixels);
    jpeg_finish_decompress(&c);jpeg_destroy_decompress(&c);return 1;
}
static int base_name(const char *path,char out[16]) {
    if(!path)return 0;const char *p=strrchr(path,'/');p=p?p+1:path;
    static const char *allow[]={"bio4.m4v","buki.m4v","kuro.m4v","res4.m4v"};
    char low[16];size_t len=strlen(p);if(len>=sizeof low)return 0;
    for(size_t i=0;i<=len;i++)low[i]=(char)tolower((unsigned char)p[i]);
    for(int i=0;i<4;i++)if(!strcmp(low,allow[i])) {memcpy(out,low,len-4);out[len-4]=0;return 1;}
    return 0;
}
int psp_movie_play(const char *original_path) {
    char name[16],path[512],sound[512];if(!base_name(original_path,name))return 0;
    snprintf(path,sizeof path,"%s/psp_video/%s.r4v",rt_bundle_dir,name);
    snprintf(sound,sizeof sound,"%s/psp_video/%s.mp3",rt_bundle_dir,name);
    FILE *f=fopen(path,"rb");if(!f){rt_log("[movie] missing %s, skipped",path);return 0;}
    u8 head[32];int ok=fread(head,1,sizeof head,f)==sizeof head && !memcmp(head,"RE4MV01\0",8);
    u32 w=ok?little(head+8):0,h=ok?little(head+12):0,fps=ok?little(head+16):0,den=ok?little(head+20):0,count=ok?little(head+24):0,max=ok?little(head+28):0;
    if(!ok || w!=MW || h!=MH || fps!=20 || den!=1 || !count || count>72000 || !max || max>MAX_FRAME){fclose(f);rt_log("[movie] bad video header: %s",path);return 0;}
    u8 *compressed=malloc(max);u16 *pixels=memalign(64,STRIDE*TEXROWS*sizeof *pixels);
    if(!compressed || !pixels){free(compressed);free(pixels);fclose(f);rt_log("[movie] out of memory");return 0;}
    /* All setup succeeded: suppress gameplay audio even for silent movies. */
    FILE *sf=fopen(sound,"rb");int song=-1;if(sf){fclose(sf);song=plat_music_open(sound,0,0);}
    psp_movie_input_begin();movie_music_begin(song);
    u64 start=plat_time_us(), frame_us=1000000u/fps;int shown=0;
    u32 i;for(i=0;i<count;i++) {
        u8 raw[4];if(psp_movie_input_cancel() || fread(raw,1,4,f)!=4)break;
        u32 len=little(raw);if(!len || len>max){rt_log("[movie] invalid frame length");break;}
        u64 due=start+(u64)i*frame_us,now=plat_time_us();
        if(now>due+frame_us){if(fseek(f,(long)len,SEEK_CUR))break;continue;}
        if(fread(compressed,1,len,f)!=len || !jpeg_frame(compressed,len,pixels)){rt_log("[movie] corrupt frame");break;}
        while((now=plat_time_us())<due && !psp_movie_input_cancel()) {u64 wait=due-now;plat_sleep_us((u32)(wait>10000?10000:wait));}
        if(psp_movie_input_cancel())break;
        gl_movie_frame(pixels);shown++;
    }
    /* Let the final frame and audio run to their nominal duration. */
    u64 end=start+(u64)count*frame_us;
    while(i==count && shown && plat_time_us()<end && !psp_movie_input_cancel()) {
        u64 now=plat_time_us();if(now>=end)break;u64 wait=end-now;plat_sleep_us((u32)(wait>10000?10000:wait));
    }
    movie_music_end(song);psp_movie_input_end();fclose(f);free(compressed);free(pixels);
    rt_log("[movie] %s: shown %d/%u frames",name,shown,count);return shown>0;
}
