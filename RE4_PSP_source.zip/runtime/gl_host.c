/* OpenGL ES 1.1 for the host build: forwarded to desktop OpenGL (Mesa llvmpipe, offscreen EGL).
   Used to validate the recompiled game and to produce reference screenshots. */
#define GL_GLEXT_PROTOTYPES 1
#include <EGL/egl.h>
#include <GL/gl.h>
#include <GL/glext.h>
#include "rt.h"
#include "funcs.h"
#include "tex_decode.h"
#include <string.h>

void plat_frame(const u8 *rgba, int w, int h);   /* platform_host.c: screenshots */
int gl_log = 0;          /* log calls while > 0 (frames) */
static u32 gl_frames, gl_draws, gl_tris, gl_uploads;
#define L(...) do { if (gl_log > 0) rt_log("[gl] " __VA_ARGS__); } while (0)
static float F(u32 x) { return U2F(x); }

static int inited;
void gl_host_init(void) {
    if (inited) return;
    inited = 1;
    setenv("EGL_PLATFORM", "surfaceless", 0);
    EGLDisplay d = eglGetDisplay(EGL_DEFAULT_DISPLAY);
    EGLint maj, min, n;
    if (!eglInitialize(d, &maj, &min)) rt_fatal("EGL init failed");
    EGLint ca[] = {EGL_SURFACE_TYPE, EGL_PBUFFER_BIT, EGL_RED_SIZE, 8, EGL_GREEN_SIZE, 8, EGL_BLUE_SIZE, 8,
                   EGL_DEPTH_SIZE, 16, EGL_RENDERABLE_TYPE, EGL_OPENGL_BIT, EGL_NONE};
    EGLConfig c;
    eglChooseConfig(d, ca, &c, 1, &n);
    EGLint pa[] = {EGL_WIDTH, 16, EGL_HEIGHT, 16, EGL_NONE};
    EGLSurface s = eglCreatePbufferSurface(d, c, pa);
    eglBindAPI(EGL_OPENGL_API);
    EGLContext ctx = eglCreateContext(d, c, EGL_NO_CONTEXT, NULL);
    if (!eglMakeCurrent(d, s, s, ctx)) rt_fatal("eglMakeCurrent failed");
    rt_log("[gl] host GL %s / %s", glGetString(GL_VERSION), glGetString(GL_RENDERER));
}

/* ---------- screen renderbuffer (EAGL drawable) */
static GLuint screen_rb, read_fb;
static int screen_w = 320, screen_h = 480;
void gl_drawable_storage(int w, int h) {
    GLint rb; glGetIntegerv(GL_RENDERBUFFER_BINDING, &rb);
    screen_rb = rb; screen_w = w; screen_h = h;
    glRenderbufferStorage(GL_RENDERBUFFER, GL_RGBA8, w, h);
    rt_log("[gl] drawable storage %dx%d on renderbuffer %d", w, h, rb);
}
void gl_present(void) {
    static u8 *px;
    if (!px) px = malloc(screen_w * screen_h * 4);
    GLint fb; glGetIntegerv(GL_READ_FRAMEBUFFER_BINDING, &fb);
    if (!read_fb) glGenFramebuffers(1, &read_fb);
    glBindFramebuffer(GL_READ_FRAMEBUFFER, read_fb);
    glFramebufferRenderbuffer(GL_READ_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_RENDERBUFFER, screen_rb);
    glReadPixels(0, 0, screen_w, screen_h, GL_RGBA, GL_UNSIGNED_BYTE, px);
    glBindFramebuffer(GL_READ_FRAMEBUFFER, fb);
    gl_frames++;
    if (gl_log > 0) { rt_log("[gl] ---- present frame %u: %u draws, %u tris", gl_frames, gl_draws, gl_tris); gl_log--; }
    if (rt_verbose && (gl_frames % 60) == 0) rt_log("[gl] frame %u: %u draws %u tris, %u uploads so far, heap free %u KB (min %u KB)", gl_frames, gl_draws, gl_tris, gl_uploads, heap_free_bytes() >> 10, heap_min_free() >> 10);
    gl_draws = gl_tris = 0;
    plat_frame(px, screen_w, screen_h);
}
u32 gl_frame_count(void) { return gl_frames; }

/* ---------- state */
typedef struct { int on, size; u32 type, stride, ptr; } carray;
static carray A_v, A_c, A_n, A_t[2];
static int client_tex, act_tex, tex_en[2], tex_env[2], light_on, colmat_on;
static u32 tex_bound[2], unit1_draws;

IMPORT(glActiveTexture) { (void)r1; (void)r2; (void)r3; (void)sp; L("ActiveTexture %x", r0); act_tex = (r0 - GL_TEXTURE0) & 1; glActiveTexture(r0); RET(0); }
IMPORT(glClientActiveTexture) { (void)r1; (void)r2; (void)r3; (void)sp; L("ClientActiveTexture %x", r0); client_tex = (r0 - GL_TEXTURE0) & 1; glClientActiveTexture(r0); RET(0); }
IMPORT(glAlphaFunc) { (void)r2; (void)r3; (void)sp; L("AlphaFunc %x %g", r0, F(r1)); glAlphaFunc(r0, F(r1)); RET(0); }
IMPORT(glBlendFunc) { (void)r2; (void)r3; (void)sp; L("BlendFunc %x %x", r0, r1); glBlendFunc(r0, r1); RET(0); }
IMPORT(glClear) { (void)r1; (void)r2; (void)r3; (void)sp; L("Clear %x", r0); glClear(r0); RET(0); }
IMPORT(glClearColor) { (void)sp; L("ClearColor %g %g %g %g", F(r0), F(r1), F(r2), F(r3)); glClearColor(F(r0), F(r1), F(r2), F(r3)); RET(0); }
IMPORT(glColor4f) { (void)sp; L("Color4f %g %g %g %g", F(r0), F(r1), F(r2), F(r3)); glColor4f(F(r0), F(r1), F(r2), F(r3)); RET(0); }
IMPORT(glColorMask) { (void)sp; L("ColorMask %d %d %d %d", r0 & 0xff, r1 & 0xff, r2 & 0xff, r3 & 0xff); glColorMask(r0 & 0xff, r1 & 0xff, r2 & 0xff, r3 & 0xff); RET(0); }
IMPORT(glCullFace) { (void)r1; (void)r2; (void)r3; (void)sp; L("CullFace %x", r0); glCullFace(r0); RET(0); }
IMPORT(glDepthFunc) { (void)r1; (void)r2; (void)r3; (void)sp; L("DepthFunc %x", r0); glDepthFunc(r0); RET(0); }
IMPORT(glDepthMask) { (void)r1; (void)r2; (void)r3; (void)sp; L("DepthMask %d", r0 & 0xff); glDepthMask(r0 & 0xff); RET(0); }
static void cap_shadow(u32 cap, int v) {
    if (cap == GL_TEXTURE_2D) tex_en[act_tex] = v;
    if (cap == GL_LIGHTING) light_on = v;
    if (cap == GL_COLOR_MATERIAL) colmat_on = v;
}
IMPORT(glEnable) { (void)r1; (void)r2; (void)r3; (void)sp; L("Enable %x", r0); cap_shadow(r0, 1); glEnable(r0); RET(0); }
IMPORT(glDisable) { (void)r1; (void)r2; (void)r3; (void)sp; L("Disable %x", r0); cap_shadow(r0, 0); glDisable(r0); RET(0); }
IMPORT(glFrontFace) { (void)r1; (void)r2; (void)r3; (void)sp; L("FrontFace %x", r0); glFrontFace(r0); RET(0); }
IMPORT(glHint) { (void)r2; (void)r3; (void)sp; L("Hint %x %x", r0, r1); glHint(r0, r1); RET(0); }
IMPORT(glShadeModel) { (void)r1; (void)r2; (void)r3; (void)sp; L("ShadeModel %x", r0); glShadeModel(r0); RET(0); }
IMPORT(glPolygonOffset) { (void)r2; (void)r3; (void)sp; L("PolygonOffset %g %g", F(r0), F(r1)); glPolygonOffset(F(r0), F(r1)); RET(0); }
IMPORT(glScissor) { (void)sp; L("Scissor %d %d %d %d", r0, r1, r2, r3); glScissor(r0, r1, r2, r3); RET(0); }
IMPORT(glViewport) { (void)sp; L("Viewport %d %d %d %d", r0, r1, r2, r3); glViewport(r0, r1, r2, r3); RET(0); }
IMPORT(glPixelStorei) { (void)r2; (void)r3; (void)sp; L("PixelStorei %x %d", r0, r1); glPixelStorei(r0, r1); RET(0); }
IMPORT(glGetError) { (void)r0; (void)r1; (void)r2; (void)r3; (void)sp; GLenum e = glGetError(); if (e) rt_log("[gl] error %x", e); RET(e); }
IMPORT(glGetIntegerv) { (void)r2; (void)r3; (void)sp;
    GLint v[16] = {0};
    glGetIntegerv(r0, v);
    if (r0 == GL_MAX_TEXTURE_SIZE) v[0] = 1024;
    if (r0 == GL_MAX_TEXTURE_UNITS) v[0] = 2;
    int n = (r0 == GL_VIEWPORT || r0 == GL_SCISSOR_BOX) ? 4 : 1;
    for (int i = 0; i < n; i++) WR32(r1 + 4 * i, v[i]);
    L("GetIntegerv %x -> %d", r0, v[0]); RET(0); }

/* ---------- fog / lights / materials */
IMPORT(glFogf) { (void)r2; (void)r3; (void)sp; L("Fogf %x %g", r0, F(r1)); glFogf(r0, F(r1)); RET(0); }
static void rdv(u32 p, float *v, int n) { for (int i = 0; i < n; i++) v[i] = RDF(p + 4 * i); }
IMPORT(glFogfv) { (void)r2; (void)r3; (void)sp; float v[4]; rdv(r1, v, r0 == GL_FOG_COLOR ? 4 : 1); L("Fogfv %x %g..", r0, v[0]); glFogfv(r0, v); RET(0); }
IMPORT(glLightModelf) { (void)r2; (void)r3; (void)sp; L("LightModelf %x %g", r0, F(r1)); glLightModelf(r0, F(r1)); RET(0); }
IMPORT(glLightModelfv) { (void)r2; (void)r3; (void)sp; float v[4]; rdv(r1, v, r0 == GL_LIGHT_MODEL_AMBIENT ? 4 : 1); L("LightModelfv %x %g %g %g %g", r0, v[0], v[1], v[2], v[3]); glLightModelfv(r0, v); RET(0); }
IMPORT(glLightf) { (void)r3; (void)sp; L("Lightf %x %x %g", r0, r1, F(r2)); glLightf(r0, r1, F(r2)); RET(0); }
static int lv_count(u32 pname) {
    switch (pname) { case GL_AMBIENT: case GL_DIFFUSE: case GL_SPECULAR: case GL_POSITION: case GL_EMISSION: case GL_AMBIENT_AND_DIFFUSE: return 4;
    case GL_SPOT_DIRECTION: return 3; default: return 1; }
}
IMPORT(glLightfv) { (void)r3; (void)sp; float v[4]; rdv(r2, v, lv_count(r1)); L("Lightfv %x %x %g %g %g %g", r0, r1, v[0], v[1], v[2], v[3]); glLightfv(r0, r1, v); RET(0); }
IMPORT(glMaterialf) { (void)r3; (void)sp; L("Materialf %x %x %g", r0, r1, F(r2)); glMaterialf(r0, r1, F(r2)); RET(0); }
IMPORT(glMaterialfv) { (void)r3; (void)sp; float v[4]; rdv(r2, v, lv_count(r1)); L("Materialfv %x %x %g %g %g %g", r0, r1, v[0], v[1], v[2], v[3]); glMaterialfv(r0, r1, v); RET(0); }

/* ---------- matrices */
IMPORT(glMatrixMode) { (void)r1; (void)r2; (void)r3; (void)sp; L("MatrixMode %x", r0); glMatrixMode(r0); RET(0); }
IMPORT(glLoadIdentity) { (void)r0; (void)r1; (void)r2; (void)r3; (void)sp; L("LoadIdentity"); glLoadIdentity(); RET(0); }
IMPORT(glLoadMatrixf) { (void)r1; (void)r2; (void)r3; (void)sp; float m[16]; rdv(r0, m, 16); L("LoadMatrixf %g %g %g %g / %g %g %g", m[0], m[5], m[10], m[15], m[12], m[13], m[14]); glLoadMatrixf(m); RET(0); }
IMPORT(glMultMatrixf) { (void)r1; (void)r2; (void)r3; (void)sp; float m[16]; rdv(r0, m, 16); L("MultMatrixf"); glMultMatrixf(m); RET(0); }
IMPORT(glOrthof) { L("Orthof %g %g %g %g %g %g", F(r0), F(r1), F(r2), F(r3), F(SARG(0)), F(SARG(1))); glOrtho(F(r0), F(r1), F(r2), F(r3), F(SARG(0)), F(SARG(1))); RET(0); }
IMPORT(glRotatef) { (void)sp; L("Rotatef %g %g %g %g", F(r0), F(r1), F(r2), F(r3)); glRotatef(F(r0), F(r1), F(r2), F(r3)); RET(0); }
IMPORT(glTranslatef) { (void)r3; (void)sp; L("Translatef %g %g %g", F(r0), F(r1), F(r2)); glTranslatef(F(r0), F(r1), F(r2)); RET(0); }

/* ---------- client arrays: remembered so GL_FIXED data can be converted at draw time */
static carray *arr_of(u32 cap) {
    switch (cap) { case GL_VERTEX_ARRAY: return &A_v; case GL_COLOR_ARRAY: return &A_c; case GL_NORMAL_ARRAY: return &A_n;
    case GL_TEXTURE_COORD_ARRAY: return &A_t[client_tex]; default: return 0; }
}
IMPORT(glEnableClientState) { (void)r1; (void)r2; (void)r3; (void)sp; L("EnableClientState %x", r0); carray *a = arr_of(r0); if (a) a->on = 1; glEnableClientState(r0); RET(0); }
IMPORT(glDisableClientState) { (void)r1; (void)r2; (void)r3; (void)sp; L("DisableClientState %x", r0); carray *a = arr_of(r0); if (a) a->on = 0; glDisableClientState(r0); RET(0); }
static void set_arr(carray *a, int size, u32 type, u32 stride, u32 ptr) { a->size = size; a->type = type; a->stride = stride; a->ptr = ptr; }
IMPORT(glVertexPointer) { (void)sp; L("VertexPointer %d %x %d %x", r0, r1, r2, r3); set_arr(&A_v, r0, r1, r2, r3); if (r1 != GL_FIXED) glVertexPointer(r0, r1, r2, MEM + r3); RET(0); }
IMPORT(glColorPointer) { (void)sp; L("ColorPointer %d %x %d %x", r0, r1, r2, r3); set_arr(&A_c, r0, r1, r2, r3); if (r1 != GL_FIXED) glColorPointer(r0, r1, r2, MEM + r3); RET(0); }
IMPORT(glNormalPointer) { (void)r3; (void)sp; L("NormalPointer %x %d %x", r0, r1, r2); set_arr(&A_n, 3, r0, r1, r2); if (r0 != GL_FIXED) glNormalPointer(r0, r1, MEM + r2); RET(0); }
IMPORT(glTexCoordPointer) { (void)sp; L("TexCoordPointer %d %x %d %x", r0, r1, r2, r3); set_arr(&A_t[client_tex], r0, r1, r2, r3); if (r1 != GL_FIXED) glTexCoordPointer(r0, r1, r2, MEM + r3); RET(0); }
static float *fixbuf[5]; static int fixcap[5];
static void fix_arrays(int maxv) {
    carray *as[5] = {&A_v, &A_c, &A_n, &A_t[0], &A_t[1]};
    for (int k = 0; k < 5; k++) {
        carray *a = as[k];
        if (!a->on || a->type != GL_FIXED) continue;
        int n = a->size, st = a->stride ? a->stride : 4 * n;
        if (fixcap[k] < maxv * n) { fixcap[k] = maxv * n; fixbuf[k] = realloc(fixbuf[k], fixcap[k] * 4); }
        for (int i = 0; i < maxv; i++) for (int j = 0; j < n; j++) fixbuf[k][i * n + j] = (s32)RD32(a->ptr + i * st + 4 * j) / 65536.0f;
        if (k == 0) glVertexPointer(n, GL_FLOAT, 0, fixbuf[k]);
        else if (k == 1) glColorPointer(n, GL_FLOAT, 0, fixbuf[k]);
        else if (k == 2) glNormalPointer(GL_FLOAT, 0, fixbuf[k]);
        else { glClientActiveTexture(GL_TEXTURE0 + k - 3); glTexCoordPointer(n, GL_FLOAT, 0, fixbuf[k]); glClientActiveTexture(GL_TEXTURE0 + client_tex); }
    }
}
static void log_arrays(void) {
    if (tex_en[1] && !unit1_draws++) rt_log("[gl] NOTE: draw with texture unit 1 enabled (tex %u env %x)", tex_bound[1], tex_env[1]);
    if (gl_log <= 0) return;
    rt_log("[gl]   state tex0 %d/%u env %x tex1 %d/%u env %x light %d colmat %d", tex_en[0], tex_bound[0], tex_env[0], tex_en[1], tex_bound[1], tex_env[1], light_on, colmat_on);
    carray *as[4] = {&A_v, &A_c, &A_n, &A_t[0]}; const char *nm[4] = {"v", "c", "n", "t"};
    char b[256]; int o = 0;
    for (int k = 0; k < 4; k++) if (as[k]->on) o += snprintf(b + o, sizeof b - o, " %s%d:%x/%d@%x", nm[k], as[k]->size, as[k]->type, as[k]->stride, as[k]->ptr);
    rt_log("[gl]   arrays%s", o ? b : " none");
}
static u32 prim_tris(u32 mode, u32 n) { return mode == GL_TRIANGLES ? n / 3 : (mode == GL_TRIANGLE_STRIP || mode == GL_TRIANGLE_FAN) && n > 2 ? n - 2 : 0; }
IMPORT(glDrawArrays) { (void)r3; (void)sp;
    L("DrawArrays %x %d %d", r0, r1, r2); log_arrays();
    fix_arrays(r1 + r2);
    glDrawArrays(r0, r1, r2); gl_draws++; gl_tris += prim_tris(r0, r2); RET(0); }
IMPORT(glDrawElements) { (void)sp;
    L("DrawElements %x %d %x %x", r0, r1, r2, r3); log_arrays();
    int maxv = 0;
    for (u32 i = 0; i < r1; i++) { int v = r2 == GL_UNSIGNED_BYTE ? RD8(r3 + i) : RD16(r3 + 2 * i); if (v + 1 > maxv) maxv = v + 1; }
    fix_arrays(maxv);
    glDrawElements(r0, r1, r2, MEM + r3); gl_draws++; gl_tris += prim_tris(r0, r1); RET(0); }

/* ---------- textures */
IMPORT(glGenTextures) { (void)r2; (void)r3; (void)sp; GLuint t[64]; int n = r0 > 64 ? 64 : r0; glGenTextures(n, t); for (int i = 0; i < n; i++) WR32(r1 + 4 * i, t[i]); L("GenTextures %d -> %u", n, t[0]); RET(0); }
IMPORT(glDeleteTextures) { (void)r2; (void)r3; (void)sp; for (u32 i = 0; i < r0; i++) { GLuint t = RD32(r1 + 4 * i); glDeleteTextures(1, &t); } L("DeleteTextures %d", r0); RET(0); }
IMPORT(glBindTexture) { (void)r2; (void)r3; (void)sp; L("BindTexture %x %u", r0, r1); tex_bound[act_tex] = r1; glBindTexture(r0, r1); RET(0); }
IMPORT(glTexParameteri) { (void)r3; (void)sp; L("TexParameteri %x %x %x", r0, r1, r2); glTexParameteri(r0, r1, r2); RET(0); }
IMPORT(glTexParameterf) { (void)r3; (void)sp; L("TexParameterf %x %x %g", r0, r1, F(r2)); glTexParameterf(r0, r1, F(r2)); RET(0); }
IMPORT(glTexEnvf) { (void)r3; (void)sp; L("TexEnvf %x %x %g", r0, r1, F(r2)); if (r1 == GL_TEXTURE_ENV_MODE) tex_env[act_tex] = (int)F(r2); glTexEnvf(r0, r1, F(r2)); RET(0); }
IMPORT(glTexEnvfv) { (void)r3; (void)sp; float v[4]; rdv(r2, v, r1 == GL_TEXTURE_ENV_COLOR ? 4 : 1); L("TexEnvfv %x %x %g", r0, r1, v[0]); glTexEnvfv(r0, r1, v); RET(0); }
IMPORT(glTexImage2D) {   /* target level ifmt w h border fmt type pixels */
    u32 w = r3, h = SARG(0), fmt = SARG(2), type = SARG(3), px = SARG(4);
    if (gl_log > 0 || rt_verbose) rt_log("[gl] TexImage2D lvl %d ifmt %x %dx%d fmt %x type %x data %x", r1, r2, w, h, fmt, type, px);
    gl_uploads++;
    glTexImage2D(r0, r1, r2, w, h, 0, fmt, type, px ? MEM + px : 0); RET(0); }
IMPORT(glTexSubImage2D) {   /* target level x y w h fmt type pixels */
    if (gl_log > 0 || rt_verbose) rt_log("[gl] TexSubImage2D lvl %d %d,%d %dx%d fmt %x type %x", r1, r2, r3, SARG(0), SARG(1), SARG(2), SARG(3));
    glTexSubImage2D(r0, r1, r2, r3, SARG(0), SARG(1), SARG(2), SARG(3), MEM + SARG(4)); RET(0); }
IMPORT(glCompressedTexImage2D) {   /* target level ifmt w h border size data */
    u32 w = r3, h = SARG(0), size = SARG(2), data = SARG(3);
    if (gl_log > 0 || rt_verbose) rt_log("[gl] CompressedTexImage2D lvl %d fmt %x %dx%d size %u data %x", r1, r2, w, h, size, data);
    gl_uploads++;
    u8 *rgba = malloc(w * h * 4 + 64);
    if (r2 >= 0x8C00 && r2 <= 0x8C03) pvrtc_decode(MEM + data, w, h, r2 & 1, rgba);
    else if (!palette_decode(r2, MEM + data, w, h, rgba)) { rt_log("[gl] unsupported compressed format %x", r2); memset(rgba, 0xff, w * h * 4); }
    if (r2 >= 0x8B90 && r2 <= 0x8B99 && (s32)r1 < 0) {   /* paletted with mip levels: decode all levels (level = -n) */
        int bits, eb; palette_info(r2, &bits, &eb);
        int levels = 1 - (s32)r1; const u8 *ix = MEM + data + (bits == 4 ? 16 : 256) * eb;
        (void)ix; (void)levels;
    }
    glTexImage2D(r0, (s32)r1 < 0 ? 0 : r1, GL_RGBA, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, rgba);
    free(rgba); RET(0); }
IMPORT(glCopyTexImage2D) {   /* target level ifmt x y w h border */
    if (gl_log > 0 || rt_verbose) rt_log("[gl] CopyTexImage2D lvl %d ifmt %x %d,%d %dx%d", r1, r2, r3, SARG(0), SARG(1), SARG(2));
    glCopyTexImage2D(r0, r1, r2, r3, SARG(0), SARG(1), SARG(2), 0); RET(0); }

/* ---------- framebuffer objects */
IMPORT(glGenFramebuffersOES) { (void)r2; (void)r3; (void)sp; GLuint t[8]; int n = r0 > 8 ? 8 : r0; glGenFramebuffers(n, t); for (int i = 0; i < n; i++) WR32(r1 + 4 * i, t[i]); L("GenFramebuffers -> %u", t[0]); RET(0); }
IMPORT(glGenRenderbuffersOES) { (void)r2; (void)r3; (void)sp; GLuint t[8]; int n = r0 > 8 ? 8 : r0; glGenRenderbuffers(n, t); for (int i = 0; i < n; i++) WR32(r1 + 4 * i, t[i]); L("GenRenderbuffers -> %u", t[0]); RET(0); }
IMPORT(glDeleteFramebuffersOES) { (void)r2; (void)r3; (void)sp; for (u32 i = 0; i < r0; i++) { GLuint t = RD32(r1 + 4 * i); glDeleteFramebuffers(1, &t); } RET(0); }
IMPORT(glDeleteRenderbuffersOES) { (void)r2; (void)r3; (void)sp; for (u32 i = 0; i < r0; i++) { GLuint t = RD32(r1 + 4 * i); glDeleteRenderbuffers(1, &t); } RET(0); }
IMPORT(glBindFramebufferOES) { (void)r2; (void)r3; (void)sp; if (gl_log > 0 || rt_verbose > 1) rt_log("[gl] BindFramebuffer %u", r1); glBindFramebuffer(GL_FRAMEBUFFER, r1); RET(0); }
IMPORT(glBindRenderbufferOES) { (void)r2; (void)r3; (void)sp; L("BindRenderbuffer %u", r1); glBindRenderbuffer(GL_RENDERBUFFER, r1); RET(0); }
IMPORT(glRenderbufferStorageOES) { (void)r0; (void)sp; L("RenderbufferStorage %x %dx%d", r1, r2, r3); glRenderbufferStorage(GL_RENDERBUFFER, r1 == 0x81A5 ? GL_DEPTH_COMPONENT16 : r1, r2, r3); RET(0); }
IMPORT(glFramebufferRenderbufferOES) { (void)r0; (void)r2; (void)sp; L("FramebufferRenderbuffer %x %u", r1, r3); glFramebufferRenderbuffer(GL_FRAMEBUFFER, r1, GL_RENDERBUFFER, r3); RET(0); }
IMPORT(glFramebufferTexture2DOES) { (void)r0; rt_log("[gl] FramebufferTexture2D %x %x %u", r1, r2, r3); glFramebufferTexture2D(GL_FRAMEBUFFER, r1, r2, r3, SARG(0)); RET(0); }
IMPORT(glCheckFramebufferStatusOES) { (void)r0; (void)r1; (void)r2; (void)r3; (void)sp; GLenum s = glCheckFramebufferStatus(GL_FRAMEBUFFER); L("CheckFramebufferStatus -> %x", s); RET(s); }
IMPORT(glGetRenderbufferParameterivOES) { (void)r0; (void)r3; (void)sp; GLint v = 0; glGetRenderbufferParameteriv(GL_RENDERBUFFER, r1, &v); WR32(r2, v); L("GetRenderbufferParameteriv %x -> %d", r1, v); RET(0); }
