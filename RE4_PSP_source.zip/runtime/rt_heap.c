/* Guest heap: boundary-tag allocator with segregated free lists, metadata inside guest memory.
   chunk c: [c+0] prev_size (valid when previous chunk is free) [c+4] size|PINUSE|CINUSE, payload at c+8.
   free chunks keep list links at c+8 (next) / c+12 (prev). */
#include "rt.h"
#include <string.h>

#define CINUSE 1u
#define PINUSE 2u
#define FLAGS 3u
#define NBINS 160
static u32 bins[NBINS];
static u32 free_bytes;
#define W(a) (*(u32 *)(MEM + (a)))
#define CSIZE(c) (W((c) + 4) & ~FLAGS)

static u32 bin_of(u32 sz) {
    if (sz < 1024) return sz >> 4;
    u32 l = 31 - __builtin_clz(sz);
    u32 b = 64 + 4 * (l - 10) + ((sz >> (l - 2)) & 3);
    return b < NBINS ? b : NBINS - 1;
}
static void bin_insert(u32 c) {
    u32 b = bin_of(CSIZE(c)), h = bins[b];
    W(c + 8) = h; W(c + 12) = 0;
    if (h) W(h + 12) = c;
    bins[b] = c;
    free_bytes += CSIZE(c);
}
static void bin_remove(u32 c) {
    u32 n = W(c + 8), p = W(c + 12);
    if (p) W(p + 8) = n; else bins[bin_of(CSIZE(c))] = n;
    if (n) W(n + 12) = p;
    free_bytes -= CSIZE(c);
}
static void set_free(u32 c, u32 sz, u32 pinuse) {
    W(c + 4) = sz | pinuse;
    W(c + sz) = sz;                         /* next chunk's prev_size */
    W(c + sz + 4) &= ~PINUSE;
}

void heap_add(u32 lo, u32 hi) {
    lo = (lo + 7) & ~7u; hi &= ~7u;
    if (hi < lo + 64) return;
    u32 c = lo, end = hi - 8;               /* end: sentinel chunk header (in use, size 0) */
    W(end + 4) = 0 | CINUSE;
    W(c + 4) = PINUSE;
    set_free(c, end - c, PINUSE);
    bin_insert(c);
}
void heap_init(u32 lo, u32 hi) { memset(bins, 0, sizeof bins); free_bytes = 0; heap_add(lo, hi); }
static u32 min_free = 0xffffffff;
u32 heap_log_min;                 /* log allocations of at least this size (0 = off) */
#define NTRACK 512
static u32 trk_addr[NTRACK], trk_size[NTRACK];
u32 heap_free_bytes(void) { return free_bytes; }
u32 heap_min_free(void) { return min_free; }

u32 gmalloc(u32 n) {
    if (n > 0x7ffffff0) return 0;
    u32 req = ((n + 7) & ~7u) + 8;
    if (req < 16) req = 16;
    u32 b = bin_of(req), c = 0;
    for (u32 x = bins[b]; x; x = W(x + 8)) if (CSIZE(x) >= req) { c = x; break; }
    if (!c) for (b = b + 1; b < NBINS; b++) if (bins[b]) { c = bins[b]; break; }
    if (!c) {
        rt_log("[heap] out of guest memory: request %u bytes, %u KB free", n, free_bytes >> 10);
        return 0;
    }
    bin_remove(c);
    u32 sz = CSIZE(c), pin = W(c + 4) & PINUSE;
    if (sz - req >= 32) {
        u32 r = c + req;
        W(c + 4) = req | pin | CINUSE;
        W(r + 4) = PINUSE;
        set_free(r, sz - req, PINUSE);
        bin_insert(r);
    } else {
        W(c + 4) = sz | pin | CINUSE;
        W(c + sz + 4) |= PINUSE;
    }
    if (free_bytes < min_free) min_free = free_bytes;
    if (heap_log_min && n >= heap_log_min) {
        for (int i = 0; i < NTRACK; i++) if (!trk_addr[i]) { trk_addr[i] = c + 8; trk_size[i] = n; break; }
        rt_log("[heap] +%u KB (%u bytes) at %x (free %u KB)", n >> 10, n, c + 8, free_bytes >> 10);
    }
    return c + 8;
}

void heap_dump_tracked(void) {
    u32 tot = 0; int n = 0;
    for (int i = 0; i < NTRACK; i++) if (trk_addr[i]) { tot += trk_size[i]; n++; rt_log("[heap] live %x %u KB", trk_addr[i], trk_size[i] >> 10); }
    rt_log("[heap] %d big blocks live, %u KB total; free %u KB", n, tot >> 10, free_bytes >> 10);
}
void gfree(u32 p) {
    if (!p) return;
    if (heap_log_min) for (int i = 0; i < NTRACK; i++) if (trk_addr[i] == p) { rt_log("[heap] -%u KB at %x", trk_size[i] >> 10, p); trk_addr[i] = 0; break; }
    u32 c = p - 8, sz = CSIZE(c);
    if (!(W(c + 4) & CINUSE)) { rt_log("[heap] double free of %x", p); return; }
    u32 pin = W(c + 4) & PINUSE;
    u32 nx = c + sz;
    if (!(W(nx + 4) & CINUSE)) { bin_remove(nx); sz += CSIZE(nx); }
    if (!pin) { u32 ps = W(c), pc = c - ps; bin_remove(pc); c = pc; sz += ps; pin = W(pc + 4) & PINUSE; }
    set_free(c, sz, pin);
    bin_insert(c);
}

u32 gcalloc(u32 n) { u32 p = gmalloc(n); if (p) memset(MEM + p, 0, n); return p; }

u32 grealloc(u32 p, u32 n) {
    if (!p) return gmalloc(n);
    if (!n) { gfree(p); return 0; }
    u32 c = p - 8, sz = CSIZE(c), req = ((n + 7) & ~7u) + 8;
    if (req < 16) req = 16;
    if (sz >= req) return p;
    u32 nx = c + sz;
    if (!(W(nx + 4) & CINUSE) && sz + CSIZE(nx) >= req) {
        u32 tot = sz + CSIZE(nx); bin_remove(nx);
        u32 pin = W(c + 4) & PINUSE;
        if (tot - req >= 32) {
            u32 r = c + req;
            W(c + 4) = req | pin | CINUSE; W(r + 4) = PINUSE;
            set_free(r, tot - req, PINUSE); bin_insert(r);
        } else {
            W(c + 4) = tot | pin | CINUSE; W(c + tot + 4) |= PINUSE;
        }
        return p;
    }
    u32 q = gmalloc(n);
    if (q) { memcpy(MEM + q, MEM + p, sz - 8); gfree(p); }
    return q;
}

/* rcx::font::TextBoard keeps 5 per-character arrays (new[]-allocated, trivially copyable):
   +12 capacity, +16 count, +32 positions 48 B, +36 UVs 32 B, +40 colours 16 B, +44 indices 12 B, +48 info 24 B.
   gen.py starts boards at 64 characters; TextBoard::_writeCS calls this when a board is full.
   Doubles the capacity up to the game's original 1024; on failure the text is cut off as the game would. */
void rc_textboard_grow(u32 tb) {
    static const u8 off[5] = {32, 36, 40, 44, 48}, esz[5] = {48, 32, 16, 12, 24};
    u32 cap = W(tb + 12), cnt = W(tb + 16), ncap = cap * 2, np[5];
    if (cap >= 1024 || cap == 0) return;
    if (ncap > 1024) ncap = 1024;
    for (int i = 0; i < 5; i++) {
        np[i] = gmalloc(ncap * esz[i]);
        if (!np[i]) { while (i--) gfree(np[i]); return; }
    }
    for (int i = 0; i < 5; i++) {
        u32 old = W(tb + off[i]);
        if (old) { memcpy(MEM + np[i], MEM + old, (cnt < cap ? cnt : cap) * esz[i]); gfree(old); }
        W(tb + off[i]) = np[i];
    }
    W(tb + 12) = ncap;
}
