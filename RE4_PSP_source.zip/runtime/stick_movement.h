#ifndef RE4_STICK_MOVEMENT_H
#define RE4_STICK_MOVEMENT_H
#include <math.h>
/* Player run requires virtual-pad displacement > 40. Old default/configs
   used 40, so an axis-aligned full tilt could never cross the threshold.
   Limit the vector radially so diagonals do not overshoot the pad. */
static inline void stick_movement_offset(float x, float y, float radius, float *dx, float *dy) {
    if (radius < 50.0f) radius = 50.0f;
    float magnitude = sqrtf(x*x + y*y);
    if (magnitude > 1.0f) { x /= magnitude; y /= magnitude; }
    *dx = x * radius;
    *dy = y * radius;
}
#endif
