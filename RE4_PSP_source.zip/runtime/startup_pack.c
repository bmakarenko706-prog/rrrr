/* Optional pack of immutable startup assets: validated against the original
   file's size; FAT/copy tools may alter timestamps. Localizations/saves are never packed.
   Same-size asset modifications require rebuilding or removing the pack. */
#include "rt.h"
#include "startup_pack.h"
#include "bundle_stat.h"
#include <sys/stat.h>
#include <string.h>
#ifdef STARTUP_PROFILE
#include "startup_profile.h"
#endif
#define PACK_MAX 128
#define NAME_MAX_LEN 96
typedef struct { char name[NAME_MAX_LEN]; u32 off,size,mtime; int invalid; } PackEntry;
static PackEntry entries[PACK_MAX];
static int nentries, attempted;
static unsigned candidates, hits, mismatches;
static FILE *pack;
static u32 read32(const unsigned char *p) {return (u32)p[0] | (u32)p[1]<<8 | (u32)p[2]<<16 | (u32)p[3]<<24;}
static void pack_init(void) {
    char path[512]; unsigned char h[8],e[108];
    attempted=1; snprintf(path,sizeof path,"%s/startup_cache.bin",rt_bundle_dir);
    FILE *f=fopen(path,"rb"); if(!f) return;
    if(fseek(f,0,SEEK_END)) { fclose(f);return; }
    long len=ftell(f); rewind(f);
    if(len<8 || fread(h,1,8,f)!=8 || memcmp(h,"R4P1",4)) {fclose(f);return;}
    u32 count=read32(h+4);
    if(count==0 || count>PACK_MAX || len < (long)(8+count*108)) {fclose(f);return;}
    for(u32 i=0;i<count;i++) {
        if(fread(e,1,sizeof e,f)!=sizeof e || !memchr(e,0,NAME_MAX_LEN)) {fclose(f);return;}
        PackEntry *x=&entries[i]; memcpy(x->name,e,NAME_MAX_LEN);
        x->off=read32(e+96);x->size=read32(e+100);x->mtime=read32(e+104);
        if(!x->name[0] || strchr(x->name,'/') || strchr(x->name,'\\') ||
           x->off < 8+count*108 || x->off > (u32)len || x->size > (u32)len-x->off) {fclose(f);return;}
    }
    nentries=(int)count;pack=f;
    rt_log("[startup] optional resource pack ready: %d entries",nentries);
}
int startup_pack_find(const char *path) {
    size_t base=strlen(rt_bundle_dir);
    if(strncmp(path,rt_bundle_dir,base) || path[base]!='/') return -1;
    if(!attempted) pack_init();
    if(!pack) return -1;
    const char *name=path+base+1;
    for(int i=0;i<nentries;i++) if(!entries[i].invalid && !strcmp(name,entries[i].name)) {
        struct stat st; candidates++;
        if(bundle_stat(path,&st) || !S_ISREG(st.st_mode) || st.st_size != (long)entries[i].size) { mismatches++; return -1; }
        hits++; return i;
    }
    return -1;
}
uint32_t startup_pack_size(int i) {return i>=0 && i<nentries ? entries[i].size:0;}
int startup_pack_read(int i, uint32_t pos, void *dst, uint32_t len) {
    if(!pack || i<0 || i>=nentries || entries[i].invalid || pos>entries[i].size || len>entries[i].size-pos) return -1;
    if(!len) return 0;
    if(fseek(pack,(long)(entries[i].off+pos),SEEK_SET)) return -1;
    return fread(dst,1,len,pack)==len ? (int)len : -1;
}
const char *startup_pack_path(int i) {
    static char path[512]; if(i<0 || i>=nentries) return NULL;
    snprintf(path,sizeof path,"%s/%s",rt_bundle_dir,entries[i].name);return path;
}
void startup_pack_invalidate(const char *path) {
    size_t base=strlen(rt_bundle_dir);
    if(strncmp(path,rt_bundle_dir,base) || path[base]!='/') return;
    if(!attempted) pack_init();
    for(int i=0;i<nentries;i++) if(!strcmp(path+base+1,entries[i].name)) entries[i].invalid=1;
}
void startup_pack_get_stats(unsigned *h, unsigned *c) { *h=hits; *c=candidates; }
void startup_pack_report(void) {
    rt_log("[startup] pack hits=%u candidates=%u changed=%u", hits, candidates, mismatches);
}

