/* Host (Linux) platform layer for testing: offscreen GL, virtual clock, scripted touches, screenshots.
   Environment:
     RE4_BUNDLE   folder with the .app contents (default /data/re4psp/ipa/Payload/Res4.app)
     RE4_DOCS     save folder (default /data/re4psp/run/Documents)
     RE4_SECONDS  quit after this much (virtual) time, default 20
     RE4_FAST=1   virtual clock: never sleep (runs as fast as possible)
     RE4_TAPS     "t:x,y[:dur];..." touches in landscape screen coordinates (480x320)
     RE4_SHOTS    "t1,t2,..." save screenshots at these times; RE4_SHOT_DIR (default /data/re4psp/run/shots)
     RE4_VERBOSE  runtime log level, RE4_GLLOG frames of GL call logging (RE4_GLLOG_AT=t: RE4_GLLOG_N frames from time t)
     RE4_MEM_MB   guest memory size (default 24) */
#include "rt.h"
#include "platform.h"
#include "language.h"
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <sys/stat.h>

int rt_main(int argc, char **argv, u32 mem_size);
void gl_host_init(void);
extern int gl_log;
extern char rt_home_dir[256];

static int fast;
static double quit_at = 20;
static u64 vclock, t0;
static u64 real_us(void) { struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts); return (u64)ts.tv_sec * 1000000 + ts.tv_nsec / 1000; }
u64 plat_time_us(void) { return fast ? vclock : real_us() - t0; }
void plat_sleep_us(u32 us) { if (fast) vclock += us; else usleep(us); }

static const char *env(const char *k, const char *d) { const char *v = getenv(k); return v && *v ? v : d; }
void plat_init(int argc, char **argv) {
    (void)argc; (void)argv;
    snprintf(rt_bundle_dir, sizeof rt_bundle_dir, "%s", env("RE4_BUNDLE", "/data/re4psp/ipa/Payload/Res4.app"));
    snprintf(rt_docs_dir, sizeof rt_docs_dir, "%s", env("RE4_DOCS", "/data/re4psp/run/Documents"));
    snprintf(rt_home_dir, sizeof rt_home_dir, "%s", rt_docs_dir);
    char *s = strrchr(rt_home_dir, '/'); if (s) *s = 0;
    mkdir(rt_home_dir, 0755); mkdir(rt_docs_dir, 0755);
    language_init(rt_home_dir);
    fast = atoi(env("RE4_FAST", "0"));
    quit_at = atof(env("RE4_SECONDS", "20"));
    rt_verbose = atoi(env("RE4_VERBOSE", "0"));
    rt_target_fps = atoi(env("RE4_FPS", "30")) == 20 ? 20 : 30;
    gl_log = atoi(env("RE4_GLLOG", "0"));
    { extern u32 heap_log_min; heap_log_min = atoi(env("RE4_ALLOCLOG", "0")); }
    t0 = real_us();
    gl_host_init();
}

/* ---------- scripted input */
typedef struct { double t, dur; float x, y; } tap;
static tap taps[64]; static int ntaps = -1;
static void parse_taps(void) {
    ntaps = 0;
    const char *s = getenv("RE4_TAPS");
    while (s && *s && ntaps < 64) {
        tap *t = &taps[ntaps];
        t->dur = 0.15;
        int n = 0;
        if (sscanf(s, "%lf:%f,%f%n", &t->t, &t->x, &t->y, &n) < 3) break;
        s += n;
        if (*s == ':') { s++; sscanf(s, "%lf%n", &t->dur, &n); s += n; }
        ntaps++;
        while (*s == ';' || *s == ' ') s++;
    }
}
/* landscape (home button right) screen point -> portrait window coordinates */
static void land2port(float X, float Y, float *px, float *py) { *px = 320 - Y; *py = X; }
int plat_poll(plat_input *in) {
    if (ntaps < 0) parse_taps();
    double t = plat_time_us() / 1e6;
    memset(in, 0, sizeof *in);
    for (int i = 0; i < ntaps; i++) if (t >= taps[i].t && t < taps[i].t + taps[i].dur) {
        in->touch[0].down = 1; land2port(taps[i].x, taps[i].y, &in->touch[0].x, &in->touch[0].y);
    }
    return t >= quit_at ? PLAT_QUIT : PLAT_RUN;
}

/* ---------- frames: screenshots at requested times (rotated to landscape) */
static double shots[64]; static int nshots = -1, shot_i;
void plat_frame(const u8 *rgba, int w, int h) {
    if (nshots < 0) {
        nshots = 0;
        const char *s = getenv("RE4_SHOTS");
        while (s && *s && nshots < 64) { shots[nshots++] = atof(s); s = strchr(s, ','); if (!s) break; s++; }
    }
    double t = plat_time_us() / 1e6;
    static double log_at = -1;
    if (log_at < 0) log_at = atof(env("RE4_GLLOG_AT", "0"));
    if (log_at > 0 && t >= log_at) { gl_log = atoi(env("RE4_GLLOG_N", "1")); log_at = 0; }
    static double dump_at = -1;
    if (dump_at < 0) dump_at = atof(env("RE4_HEAPDUMP_AT", "0"));
    if (dump_at > 0 && t >= dump_at) { void heap_dump_tracked(void); heap_dump_tracked(); dump_at = 0; }
    if (shot_i >= nshots || t < shots[shot_i]) return;
    shot_i++;
    char path[512];
    snprintf(path, sizeof path, "%s/shot_%06.2f.ppm", env("RE4_SHOT_DIR", "/data/re4psp/run/shots"), t);
    FILE *f = fopen(path, "wb");
    if (!f) return;
    /* GL rows are bottom-up; output landscape: X = portrait y, Y = 320 - portrait x */
    fprintf(f, "P6\n%d %d\n255\n", h, w);
    for (int Y = 0; Y < w; Y++) for (int X = 0; X < h; X++) {
        int px = w - 1 - Y, py = X;
        const u8 *p = rgba + 4 * ((h - 1 - py) * w + px);
        fputc(p[0], f); fputc(p[1], f); fputc(p[2], f);
    }
    fclose(f);
    rt_log("[host] screenshot %s", path);
}

/* ---------- audio: consumed at real (or virtual) speed, optionally recorded */
static int a_rate; static u64 a_written, a_t0; static FILE *a_wav;
void plat_audio_open(int rate) {
    a_rate = rate; a_t0 = plat_time_us(); a_written = 0;
    const char *p = getenv("RE4_WAV");
    if (p && !a_wav) { a_wav = fopen(p, "wb"); if (a_wav) { u8 hdr[44] = {0}; fwrite(hdr, 1, 44, a_wav); } }
    rt_log("[host] audio output %d Hz", rate);
}
int plat_audio_space(void) {
    u64 played = (plat_time_us() - a_t0) * (u64)a_rate / 1000000;
    s64 queued = (s64)a_written - (s64)played;
    if (queued < 0) { a_written = played; queued = 0; }
    int space = (int)(a_rate / 10 - queued);      /* keep 100 ms queued */
    return space > 0 ? space : 0;
}
static void wav_finish(void) {
    if (!a_wav) return;
    long n = ftell(a_wav) - 44;
    u32 h[11] = {0x46464952, (u32)(36 + n), 0x45564157, 0x20746d66, 16, 0x00020001, (u32)a_rate, (u32)a_rate * 4, 0x00100004, 0x61746164, (u32)n};
    fseek(a_wav, 0, SEEK_SET); fwrite(h, 4, 11, a_wav); fclose(a_wav); a_wav = 0;
}
void plat_audio_write(const s16 *frames, int n) { a_written += n; if (a_wav) fwrite(frames, 4, n, a_wav); }

/* ---------- music: no decoding on the host, durations estimated from size (128 kbit/s) */
typedef struct { int used, loops, playing; double dur, start, paused_at; float vol; } music;
static music mus[32];
int plat_music_open(const char *path, const void *data, u32 len) {
    for (int h = 0; h < 32; h++) if (!mus[h].used) {
        long sz = len;
        if (path) { FILE *f = fopen(path, "rb"); if (!f) return -1; fseek(f, 0, SEEK_END); sz = ftell(f); fclose(f); }
        (void)data;
        memset(&mus[h], 0, sizeof mus[h]); mus[h].used = 1; mus[h].dur = sz * 8.0 / 128000.0; mus[h].vol = 1;
        if (rt_verbose) rt_log("[host] music open %s (%.1fs)", path ? path : "(memory)", mus[h].dur);
        return h;
    }
    return -1;
}
void plat_music_close(int h) { if (h >= 0 && h < 32) mus[h].used = 0; }
void plat_music_play(int h, int loops) { if (h < 0) return; mus[h].loops = loops; mus[h].playing = 1; mus[h].start = plat_time_us() / 1e6 - mus[h].paused_at; mus[h].paused_at = 0; }
void plat_music_stop(int h) { if (h < 0) return; mus[h].playing = 0; mus[h].paused_at = 0; }
void plat_music_pause(int h) { if (h < 0 || !mus[h].playing) return; mus[h].paused_at = plat_time_us() / 1e6 - mus[h].start; mus[h].playing = 0; }
void plat_music_volume(int h, float v) { if (h >= 0) mus[h].vol = v; }
int plat_music_playing(int h) {
    if (h < 0 || !mus[h].playing) return 0;
    if (mus[h].loops < 0) return 1;
    if (plat_time_us() / 1e6 - mus[h].start > mus[h].dur * (mus[h].loops + 1)) mus[h].playing = 0;
    return mus[h].playing;
}
double plat_music_time(int h) { if (h < 0 || !mus[h].playing) return h >= 0 ? mus[h].paused_at : 0; double t = plat_time_us() / 1e6 - mus[h].start; return mus[h].dur > 0 ? t - mus[h].dur * (int)(t / mus[h].dur) : 0; }
void plat_music_seek(int h, double t) { if (h < 0) return; if (mus[h].playing) mus[h].start = plat_time_us() / 1e6 - t; else mus[h].paused_at = t; }
double plat_music_duration(int h) { return h >= 0 ? mus[h].dur : 0; }

int main(int argc, char **argv) {
    u32 mb = atoi(env("RE4_MEM_MB", "24"));
    atexit(wav_finish);
    return rt_main(argc, argv, mb << 20);
}
