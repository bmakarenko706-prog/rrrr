#ifndef RE4_LANGUAGE_H
#define RE4_LANGUAGE_H
#include "recomp.h"
/* Russian is an optional overlay on the original English resource slot. */
void language_init(const char *game_dir);
int language_selected_russian(void);
int language_active_russian(void);
int language_russian_font_available(void);
int language_use_russian_font(void);
void language_force_original_font(int on);
void language_original_font_ready(void);
u32 language_font_index(u32 requested);
void language_menu_begin(void);
void language_menu_end(void);
int language_menu_is_open(void);
u32 language_menu_initial(u32 guest);
u32 language_menu_commit(u32 choice, u32 previous);
void language_set_guest(u32 lang);
int language_translate_for(u32 lang);
int language_translate_story(void);
int language_manual_id(void);
#endif
