/* Texture decoders: PVRTC 2/4 bpp (after the PowerVR SDK reference decoder) and OES paletted formats */
#include "tex_decode.h"
#include <stdlib.h>

typedef struct { int r, g, b, a; } px;
static px color_a(u32 c) {
    px p;
    if (c & 0x8000) { p.r = (c & 0x7c00) >> 10; p.g = (c & 0x3e0) >> 5; p.b = (c & 0x1e) | ((c & 0x1e) >> 4); p.a = 0xf; }
    else { p.a = (c & 0x7000) >> 11; p.r = ((c & 0xf00) >> 7) | ((c & 0xf00) >> 11); p.g = ((c & 0xf0) >> 3) | ((c & 0xf0) >> 7);
           p.b = ((c & 0xe) << 1) | ((c & 0xe) >> 2); }
    return p;
}
static px color_b(u32 c) {
    px p;
    if (c & 0x80000000u) { p.r = (c & 0x7c000000) >> 26; p.g = (c & 0x3e00000) >> 21; p.b = (c & 0x1f0000) >> 16; p.a = 0xf; }
    else { p.a = (c & 0x70000000) >> 27; p.r = ((c & 0xf000000) >> 23) | ((c & 0xf000000) >> 27);
           p.g = ((c & 0xf00000) >> 19) | ((c & 0xf00000) >> 23); p.b = ((c & 0xf0000) >> 15) | ((c & 0xf0000) >> 19); }
    return p;
}
static void interp(px P, px Q, px R, px S, px *out, int bpp2) {
    int ww = bpp2 ? 8 : 4, wh = 4;
    px hp = P, hq = Q, hr = R, hs = S, qp, sr;
    qp.r = hq.r - hp.r; qp.g = hq.g - hp.g; qp.b = hq.b - hp.b; qp.a = hq.a - hp.a;
    sr.r = hs.r - hr.r; sr.g = hs.g - hr.g; sr.b = hs.b - hr.b; sr.a = hs.a - hr.a;
    hp.r *= ww; hp.g *= ww; hp.b *= ww; hp.a *= ww;
    hr.r *= ww; hr.g *= ww; hr.b *= ww; hr.a *= ww;
    for (int x = 0; x < ww; x++) {
        px res = {4 * hp.r, 4 * hp.g, 4 * hp.b, 4 * hp.a}, dy = {hr.r - hp.r, hr.g - hp.g, hr.b - hp.b, hr.a - hp.a};
        for (int y = 0; y < wh; y++) {
            px *o = &out[y * ww + x];
            /* 5-bit colour and 4-bit alpha, scaled by 4 * ww, to 8 bits (white is 255) */
            if (!bpp2) { o->r = (res.r >> 6) + (res.r >> 1); o->g = (res.g >> 6) + (res.g >> 1); o->b = (res.b >> 6) + (res.b >> 1);
                         o->a = (res.a >> 4) + res.a; }
            else { o->r = (res.r >> 7) + (res.r >> 2); o->g = (res.g >> 7) + (res.g >> 2); o->b = (res.b >> 7) + (res.b >> 2);
                   o->a = (res.a >> 5) + (res.a >> 1); }
            res.r += dy.r; res.g += dy.g; res.b += dy.b; res.a += dy.a;
        }
        hp.r += qp.r; hp.g += qp.g; hp.b += qp.b; hp.a += qp.a;
        hr.r += sr.r; hr.g += sr.g; hr.b += sr.b; hr.a += sr.a;
    }
}
static void unpack_mod(u32 mod, u32 col, int ox, int oy, int vals[16][8], int modes[16][8], int bpp2) {
    u32 mode = col & 1;
    if (bpp2) {
        if (mode) {
            if (mod & 1) { mode = (mod & (1u << 20)) ? 3 : 2; if (mod & (1u << 21)) mod |= 1u << 20; else mod &= ~(1u << 20); }
            if (mod & 2) mod |= 1; else mod &= ~1u;
            for (int y = 0; y < 4; y++) for (int x = 0; x < 8; x++) {
                modes[x + ox][y + oy] = mode;
                if (((x ^ y) & 1) == 0) { vals[x + ox][y + oy] = mod & 3; mod >>= 2; }
            }
        } else {
            for (int y = 0; y < 4; y++) for (int x = 0; x < 8; x++) {
                modes[x + ox][y + oy] = mode; vals[x + ox][y + oy] = (mod & 1) ? 3 : 0; mod >>= 1;
            }
        }
    } else {
        for (int y = 0; y < 4; y++) for (int x = 0; x < 4; x++) { modes[x + ox][y + oy] = mode; vals[x + ox][y + oy] = mod & 3; mod >>= 2; }
    }
}
static int get_mod(int vals[16][8], int modes[16][8], int x, int y, int bpp2) {
    static const int rep0[4] = {0, 3, 5, 8}, rep1[4] = {0, 4, 14, 8};
    if (bpp2) {
        if (modes[x][y] == 0 || ((x ^ y) & 1) == 0) return rep0[vals[x][y]];
        if (modes[x][y] == 1) return (rep0[vals[x][y - 1]] + rep0[vals[x][y + 1]] + rep0[vals[x - 1][y]] + rep0[vals[x + 1][y]] + 2) / 4;
        if (modes[x][y] == 2) return (rep0[vals[x - 1][y]] + rep0[vals[x + 1][y]] + 1) / 2;
        return (rep0[vals[x][y - 1]] + rep0[vals[x][y + 1]] + 1) / 2;
    }
    return modes[x][y] == 0 ? rep0[vals[x][y]] : rep1[vals[x][y]];
}
static u32 twiddle(u32 xs, u32 ys, u32 x, u32 y) {
    u32 mind = xs, maxv = y, tw = 0, sb = 1, db = 1; int sh = 0;
    if (ys < xs) { mind = ys; maxv = x; }
    while (sb < mind) { if (y & sb) tw |= db; if (x & sb) tw |= db << 1; sb <<= 1; db <<= 2; sh++; }
    maxv >>= sh;
    return tw | (maxv << (2 * sh));
}
/* output sink: full RGBA8, or a 16-bit GE texel format (R in the low bits) with downscaling/swizzle */
typedef struct { int kind, shift, pitch, swz; u8 *out; } sink;   /* kind 0 RGBA8, 1 GE 4444, 2 GE 5650 */
u32 tex_swz_off(u32 xb, u32 y, u32 pitch) {
    return (((y >> 3) * (pitch >> 4) + (xb >> 4)) << 7) | ((y & 7) << 4) | (xb & 15);
}
static void put16(const sink *k, int X, int Y, const px *p) {
    int m = (1 << k->shift) - 1;
    if ((X & m) | (Y & m)) return;
    int x = X >> k->shift, y = Y >> k->shift;
    u32 o = k->swz ? tex_swz_off(2 * x, y, k->pitch) : (u32)(y * k->pitch + 2 * x);
    u16 v = k->kind == 1 ? (u16)(((p->a >> 4) << 12) | ((p->b >> 4) << 8) | ((p->g >> 4) << 4) | (p->r >> 4))
                         : (u16)(((p->b >> 3) << 11) | ((p->g >> 2) << 5) | (p->r >> 3));
    *(u16 *)(k->out + o) = v;
}
static void decode_core_k(const u32 *words, int w, int h, int bpp2, const sink *K);
static void decode_core(const u32 *words, int w, int h, int bpp2, u8 *out) {
    sink k = {0, 0, 0, 0, out}; decode_core_k(words, w, h, bpp2, &k);
}
static void decode_core_k(const u32 *words, int w, int h, int bpp2, const sink *K) {
    u8 *out = K->out;
    int ww = bpp2 ? 8 : 4, wh = 4, nx = w / ww, ny = h / wh;
    px pix[32], ua[32], ub[32];
    static int vals[16][8], modes[16][8];
    for (int wy = -1; wy < ny - 1; wy++) for (int wx = -1; wx < nx - 1; wx++) {
        int ix[4], iy[4];
        ix[0] = (wx + nx) % nx; iy[0] = (wy + ny) % ny;
        ix[1] = (wx + 1 + nx) % nx; iy[1] = iy[0];
        ix[2] = ix[0]; iy[2] = (wy + 1 + ny) % ny;
        ix[3] = ix[1]; iy[3] = iy[2];
        u32 mod[4], col[4];
        for (int k = 0; k < 4; k++) { u32 o = twiddle(nx, ny, ix[k], iy[k]) * 2; mod[k] = words[o]; col[k] = words[o + 1]; }
        unpack_mod(mod[0], col[0], 0, 0, vals, modes, bpp2);
        unpack_mod(mod[1], col[1], ww, 0, vals, modes, bpp2);
        unpack_mod(mod[2], col[2], 0, wh, vals, modes, bpp2);
        unpack_mod(mod[3], col[3], ww, wh, vals, modes, bpp2);
        interp(color_a(col[0]), color_a(col[1]), color_a(col[2]), color_a(col[3]), ua, bpp2);
        interp(color_b(col[0]), color_b(col[1]), color_b(col[2]), color_b(col[3]), ub, bpp2);
        for (int y = 0; y < wh; y++) for (int x = 0; x < ww; x++) {
            int m = get_mod(vals, modes, x + ww / 2, y + wh / 2, bpp2), punch = 0;
            if (m > 10) { punch = 1; m -= 10; }
            px *a = &ua[y * ww + x], *b = &ub[y * ww + x], *o = &pix[y * ww + x];
            o->r = (a->r * (8 - m) + b->r * m) / 8; o->g = (a->g * (8 - m) + b->g * m) / 8;
            o->b = (a->b * (8 - m) + b->b * m) / 8; o->a = punch ? 0 : (a->a * (8 - m) + b->a * m) / 8;
        }
        /* map the four quadrants back to the image */
        for (int y = 0; y < wh / 2; y++) for (int x = 0; x < ww / 2; x++) {
            struct { int bx, by, ox, oy, sx, sy; } q[4] = {
                {ix[0], iy[0], ww / 2, wh / 2, 0, 0}, {ix[1], iy[1], 0, wh / 2, ww / 2, 0},
                {ix[2], iy[2], ww / 2, 0, 0, wh / 2}, {ix[3], iy[3], 0, 0, ww / 2, wh / 2}};
            for (int k = 0; k < 4; k++) {
                int X = q[k].bx * ww + x + q[k].ox, Y = q[k].by * wh + y + q[k].oy;
                px *p = &pix[(y + q[k].sy) * ww + x + q[k].sx];
                if (K->kind) { put16(K, X, Y, p); continue; }
                u8 *d = out + 4 * (Y * w + X);
                d[0] = p->r; d[1] = p->g; d[2] = p->b; d[3] = p->a;
            }
        }
    }
}
void pvrtc_decode(const u8 *src, int w, int h, int bpp2, u8 *rgba) {
    int minw = bpp2 ? 16 : 8, minh = 8;
    if (w >= minw && h >= minh) { decode_core((const u32 *)src, w, h, bpp2, rgba); return; }
    int pw = w < minw ? minw : w, ph = h < minh ? minh : h;
    /* tiny mip levels: the data covers the padded size */
    u8 *tmp = malloc(pw * ph * 4);
    decode_core((const u32 *)src, pw, ph, bpp2, tmp);
    for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) for (int c = 0; c < 4; c++) rgba[4 * (y * w + x) + c] = tmp[4 * (y * pw + x) + c];
    free(tmp);
}
void pvrtc_decode16(const u8 *src, int w, int h, int bpp2, int shift, int alpha, u8 *out, int pitch, int swz) {
    int minw = bpp2 ? 16 : 8, minh = 8;
    sink k = {alpha ? 1 : 2, shift, pitch, swz, out};
    if (w >= minw && h >= minh) { decode_core_k((const u32 *)src, w, h, bpp2, &k); return; }
    u8 *tmp = malloc(w * h * 4);
    if (!tmp) return;
    pvrtc_decode(src, w, h, bpp2, tmp);
    for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
        const u8 *c = tmp + 4 * (y * w + x); px p = {c[0], c[1], c[2], c[3]};
        put16(&k, x, y, &p);
    }
    free(tmp);
}
void palette_rgba(u32 fmt, const u8 *src, u32 *pal) {
    int bits, eb;
    if (!palette_info(fmt, &bits, &eb)) return;
    int n = bits == 4 ? 16 : 256, kind = (fmt - 0x8B90) % 5;
    for (int i = 0; i < n; i++) {
        const u8 *e = src + i * eb;
        u32 v = e[0] | (eb > 1 ? e[1] << 8 : 0), r, g, b, a;
        switch (kind) {
        case 0: r = e[0]; g = e[1]; b = e[2]; a = 255; break;
        case 1: r = e[0]; g = e[1]; b = e[2]; a = e[3]; break;
        case 2: r = ((v >> 11) & 31) * 255 / 31; g = ((v >> 5) & 63) * 255 / 63; b = (v & 31) * 255 / 31; a = 255; break;
        case 3: r = ((v >> 12) & 15) * 17; g = ((v >> 8) & 15) * 17; b = ((v >> 4) & 15) * 17; a = (v & 15) * 17; break;
        default: r = ((v >> 11) & 31) * 255 / 31; g = ((v >> 6) & 31) * 255 / 31; b = ((v >> 1) & 31) * 255 / 31; a = (v & 1) * 255; break;
        }
        pal[i] = r | (g << 8) | (b << 16) | (a << 24);
    }
}
int palette_info(u32 fmt, int *bits, int *eb) {
    if (fmt < 0x8B90 || fmt > 0x8B99) return 0;
    int i = fmt - 0x8B90;
    *bits = i < 5 ? 4 : 8;
    static const int sz[5] = {3, 4, 2, 2, 2};   /* RGB8, RGBA8, R5G6B5, RGBA4, RGB5A1 */
    *eb = sz[i % 5];
    return 1;
}
int palette_decode(u32 fmt, const u8 *src, int w, int h, u8 *rgba) {
    int bits, eb;
    if (!palette_info(fmt, &bits, &eb)) return 0;
    int n = bits == 4 ? 16 : 256, kind = (fmt - 0x8B90) % 5;
    u8 pal[256][4];
    for (int i = 0; i < n; i++) {
        const u8 *e = src + i * eb;
        u32 v = e[0] | (eb > 1 ? e[1] << 8 : 0);
        switch (kind) {
        case 0: pal[i][0] = e[0]; pal[i][1] = e[1]; pal[i][2] = e[2]; pal[i][3] = 255; break;
        case 1: pal[i][0] = e[0]; pal[i][1] = e[1]; pal[i][2] = e[2]; pal[i][3] = e[3]; break;
        case 2: pal[i][0] = ((v >> 11) & 31) * 255 / 31; pal[i][1] = ((v >> 5) & 63) * 255 / 63; pal[i][2] = (v & 31) * 255 / 31; pal[i][3] = 255; break;
        case 3: pal[i][0] = ((v >> 12) & 15) * 17; pal[i][1] = ((v >> 8) & 15) * 17; pal[i][2] = ((v >> 4) & 15) * 17; pal[i][3] = (v & 15) * 17; break;
        default: pal[i][0] = ((v >> 11) & 31) * 255 / 31; pal[i][1] = ((v >> 6) & 31) * 255 / 31; pal[i][2] = ((v >> 1) & 31) * 255 / 31; pal[i][3] = (v & 1) * 255; break;
        }
    }
    const u8 *ix = src + n * eb;
    for (int i = 0; i < w * h; i++) {
        int k = bits == 8 ? ix[i] : (i & 1) ? (ix[i >> 1] & 15) : (ix[i >> 1] >> 4);
        for (int c = 0; c < 4; c++) rgba[4 * i + c] = pal[k][c];
    }
    return 1;
}
