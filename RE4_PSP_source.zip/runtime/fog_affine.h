#ifndef RE4_FOG_AFFINE_H
#define RE4_FOG_AFFINE_H
#include <math.h>
/* Tiny rounding error in the homogeneous scale must not drop eye-space fog.
   Keep genuinely projective matrices on the existing full-matrix path. */
static inline int ge_model_is_affine(const float *m) {
    return m[3] == 0.0f && m[7] == 0.0f && m[11] == 0.0f && fabsf(m[15] - 1.0f) <= 0.00000025f;
}
#endif
