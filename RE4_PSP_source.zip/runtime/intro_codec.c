/* ChaCha20 (original 64-bit nonce/counter form) plus plaintext CRC-32.
   The key is embedded in the program, so this is asset hiding, not DRM. */
#include "intro_codec.h"
static const uint8_t key[32]={0xd3,0x8c,0x21,0x64,0x5a,0x94,0xb7,0xe0,0x1f,0x43,0x9b,0x35,0x70,0x22,0x6c,0xf1,0x80,0x2d,0xbb,0x7a,0xc3,0x50,0x16,0x9e,0x0f,0xa1,0x4b,0xd7,0x69,0x92,0x55,0x3e};
static uint32_t rd(const uint8_t *p){return (uint32_t)p[0]|(uint32_t)p[1]<<8|(uint32_t)p[2]<<16|(uint32_t)p[3]<<24;}
static uint32_t rot(uint32_t x,unsigned b){return x<<b|x>>(32-b);}
#define QR(a,b,c,d) (a+=b,d=rot(d^a,16),c+=d,b=rot(b^c,12),a+=b,d=rot(d^a,8),c+=d,b=rot(b^c,7))
void intro_crypt(uint8_t *data,size_t n,const uint8_t nonce[8]) {
    uint32_t s[16]={0x61707865,0x3320646e,0x79622d32,0x6b206574};
    for(int i=0;i<8;i++)s[4+i]=rd(key+i*4);
    s[12]=s[13]=0; s[14]=rd(nonce);s[15]=rd(nonce+4);
    while(n){uint32_t x[16];for(int i=0;i<16;i++)x[i]=s[i];
        for(int i=0;i<10;i++){
            QR(x[0],x[4],x[8],x[12]); QR(x[1],x[5],x[9],x[13]); QR(x[2],x[6],x[10],x[14]); QR(x[3],x[7],x[11],x[15]);
            QR(x[0],x[5],x[10],x[15]); QR(x[1],x[6],x[11],x[12]); QR(x[2],x[7],x[8],x[13]); QR(x[3],x[4],x[9],x[14]);
        }
        size_t k=n<64?n:64;for(size_t i=0;i<k;i++){uint32_t v=x[i/4]+s[i/4];data[i]^=(uint8_t)(v>>(8*(i%4)));}
        data+=k;n-=k;if(++s[12]==0)s[13]++;
    }
}
int intro_decode(uint8_t *data,size_t n,const uint8_t nonce[8]) {
    if(!data || !nonce || n != INTRO_DATA_BYTES)return 0;
    intro_crypt(data,n,nonce);
    uint32_t want=rd(data),crc=~0u;
    for(size_t i=4;i<n;i++){crc^=data[i];for(int b=0;b<8;b++)crc=(crc>>1)^((0u-(crc&1u))&0xedb88320u);}
    return ~crc==want;
}
