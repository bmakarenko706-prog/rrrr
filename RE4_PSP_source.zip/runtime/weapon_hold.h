/* State controller for mapping held physical buttons to touch-toggle weapons.
   Include after rt.h. Actual pulses and UI coordinates are platform-owned. */
#ifndef RE4_WEAPON_HOLD_H
#define RE4_WEAPON_HOLD_H
#define WH_NONE 0
#define WH_GUN 1
#define WH_KNIFE 2
#define WH_LOWER 3
typedef struct { int owned; u64 pulse_end, retry_at, last_request; } weapon_hold;
static int wh_decide(weapon_hold *s, u64 now, int enabled, int desired,
                     int has_gun, int has_knife, int has_post, int gun_out, int knife_out) {
    if (!enabled || now < s->pulse_end || now < s->retry_at) return WH_NONE;
    if (desired == WH_GUN) return has_gun && !gun_out ? WH_GUN : WH_NONE;
    if (desired == WH_KNIFE) return has_knife && !knife_out ? WH_KNIFE : WH_NONE;
    if (s->owned && (gun_out || knife_out)) return has_post ? WH_LOWER : WH_NONE;
    /* Allow time for a quick press's earlier tap to take effect before forgetting it. */
    if (s->owned && !gun_out && !knife_out && (!s->last_request || now - s->last_request >= 1000000)) s->owned = 0;
    return WH_NONE;
}
static void wh_begin(weapon_hold *s, u64 now) {
    s->pulse_end = now + 120000; s->retry_at = now + 350000; s->last_request = now;
}
#endif
