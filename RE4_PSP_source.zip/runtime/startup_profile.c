/* Optional startup diagnostics, compiled only for PROFILE_STARTUP=1. */
#ifdef STARTUP_PROFILE
#define STARTUP_PROFILE_IMPL
#include "startup_profile.h"
#include "rt.h"
#include "startup_pack.h"
#include <pspkernel.h>
#include <pspctrl.h>
#include <psppower.h>
#include <stdint.h>
#include <string.h>
#include "profile_font.h"
void gl_movie_frame(const u16 *pixels);
static int active, shown;
static u64 start, io_us, stat_us, read_us, common_stat_us;
static unsigned nopen,nread,nseek,nstat,nclose,common_stat;
static u64 now(void){return sceKernelGetSystemTimeWide();}
void startup_profile_begin(void){if(!active && !shown){start=now();active=1;}}
#define TIMED_BEGIN u64 t=active?now():0
#define TIMED_END(c) do {if(t){io_us+=now()-t;c++;}}while(0)
int profile_stat(const char*p,struct stat*s){TIMED_BEGIN;int r=stat(p,s);if(t){u64 d=now()-t;io_us+=d;stat_us+=d;nstat++;if(strstr(p,"common.h2z")){common_stat++;common_stat_us+=d;}}return r;}
FILE *profile_fopen(const char*p,const char*m){TIMED_BEGIN;FILE*r=fopen(p,m);TIMED_END(nopen);return r;}
int profile_fclose(FILE*f){TIMED_BEGIN;int r=fclose(f);TIMED_END(nclose);return r;}
int profile_fseek(FILE*f,long x,int o){TIMED_BEGIN;int r=fseek(f,x,o);TIMED_END(nseek);return r;}
long profile_ftell(FILE*f){TIMED_BEGIN;long r=ftell(f);TIMED_END(nseek);return r;}
size_t profile_fread(void*p,size_t s,size_t n,FILE*f){TIMED_BEGIN;size_t r=fread(p,s,n,f);if(t){u64 d=now()-t;io_us+=d;read_us+=d;nread++;}return r;}
static void line(u16 *p,int y,const char*s){int x=12;for(;*s && x<472;s++,x+=8){unsigned c=(unsigned char)*s;if(c<32||c>126)continue;for(int j=0;j<16;j++)for(int i=0;i<8;i++)if(profile_font[c-32][j]&(128>>i))p[(y+j)*512+x+i]=0xffff;}}
void startup_profile_show(void){
 if(shown || !active)return;
 u64 elapsed=now()-start, io=io_us; active=0;shown=1;
 u32 raw=gmalloc(512u*273u*2u+64u);if(!raw)return;
 u16 *pixels=(u16 *)(MEM+((raw+63u)&~63u));memset(pixels,0,512u*273u*2u);
 unsigned hits,candidates;startup_pack_get_stats(&hits,&candidates);
 char b[100];int y=12;
 line(pixels,y,"STARTUP DIAGNOSTIC - NO LOG REQUIRED");y+=24;
 snprintf(b,sizeof b,"Logo resource to video: %u.%03u s",(unsigned)(elapsed/1000000),(unsigned)(elapsed/1000%1000));line(pixels,y,b);y+=20;
 snprintf(b,sizeof b,"File calls measured:    %u.%03u s",(unsigned)(io/1000000),(unsigned)(io/1000%1000));line(pixels,y,b);y+=20;
 snprintf(b,sizeof b,"Other (CPU/wait/other I/O): %u.%03u s",(unsigned)((elapsed>io?elapsed-io:0)/1000000),(unsigned)((elapsed>io?elapsed-io:0)/1000%1000));line(pixels,y,b);y+=24;
 snprintf(b,sizeof b,"stat %u: %u.%03u s (common %u: %u.%03u s)",nstat,(unsigned)(stat_us/1000000),(unsigned)(stat_us/1000%1000),common_stat,(unsigned)(common_stat_us/1000000),(unsigned)(common_stat_us/1000%1000));line(pixels,y,b);y+=18;
 snprintf(b,sizeof b,"read %u: %u.%03u s",nread,(unsigned)(read_us/1000000),(unsigned)(read_us/1000%1000));line(pixels,y,b);y+=18;
 snprintf(b,sizeof b,"open %u  seek/tell %u  close %u",nopen,nseek,nclose);line(pixels,y,b);y+=18;
 snprintf(b,sizeof b,"Pack hits %u / %u, CPU %d MHz",hits,candidates,scePowerGetCpuClockFrequency());line(pixels,y,b);y+=24;
 line(pixels,y,"Photo this screen, then press X.");y+=18;
 line(pixels,y,"Other includes unmeasured file operations.");
 gl_movie_frame(pixels);gfree(raw);
 SceCtrlData pad;u64 deadline=now()+120000000u;
 do{sceCtrlPeekBufferPositive(&pad,1);sceKernelDelayThread(16000);}while((pad.Buttons&PSP_CTRL_CROSS)&&now()<deadline);
 do{sceCtrlPeekBufferPositive(&pad,1);sceKernelDelayThread(16000);}while(!(pad.Buttons&PSP_CTRL_CROSS)&&now()<deadline);
 do{sceCtrlPeekBufferPositive(&pad,1);sceKernelDelayThread(16000);}while((pad.Buttons&PSP_CTRL_CROSS)&&now()<deadline);
}
#endif
