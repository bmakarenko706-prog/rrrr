/* libstdc++ / libsupc++ imports: GCC 4.x COW std::basic_string, _Rb_tree helpers, RTTI. */
#include "rt.h"
#include "funcs.h"
#include <string.h>

static u32 empty_rep;           /* guest address of the shared empty _Rep (chars at +12) */
static u32 ti_class_vt, ti_si_vt;   /* stand-ins for the typeinfo vtables */
#define EMPTY_P (empty_rep + 12)

void cxx_init(void) {
    empty_rep = gcalloc(32);
    ti_class_vt = gcalloc(64);
    ti_si_vt = gcalloc(64);
    rt_register_data("__ZTVN10__cxxabiv117__class_type_infoE", ti_class_vt);
    rt_register_data("__ZTVN10__cxxabiv120__si_class_type_infoE", ti_si_vt);
}

IMPORT(_Znwm) { u32 p = gmalloc(r0 ? r0 : 1); if (!p) rt_fatal("operator new(%u) failed: out of guest memory", r0); RET(p); }
IMPORT(_Znam) { u32 p = gmalloc(r0 ? r0 : 1); if (!p) rt_fatal("operator new[](%u) failed: out of guest memory", r0); RET(p); }
IMPORT(_ZdlPv) { gfree(r0); RET(0); }
IMPORT(_ZdaPv) { gfree(r0); RET(0); }
IMPORT(__cxa_guard_acquire) { RET(RD8(r0) == 0); }
IMPORT(__cxa_guard_release) { WR8(r0, 1); RET(0); }
IMPORT(__cxa_guard_abort) { RET(0); }
IMPORT(__cxa_pure_virtual) { rt_fatal("pure virtual function called"); }
IMPORT(_ZNSt8ios_base4InitC1Ev) { RET(0); }
IMPORT(_ZNSt8ios_base4InitD1Ev) { RET(0); }
IMPORT(_ZSt17__throw_bad_allocv) { rt_fatal("std::bad_alloc"); }
IMPORT(_ZSt20__throw_length_errorPKc) { rt_fatal("std::length_error: %s", r0 ? GSTR(r0) : ""); }

/* __dynamic_cast(src, src_type, dst_type, src2dst): this game only uses single inheritance */
IMPORT(__dynamic_cast) {
    if (!r0) RET(0);
    u32 vt = RD32(r0);
    u32 whole = r0 + RD32(vt - 8);
    u32 t = RD32(vt - 4);
    for (int depth = 0; t && depth < 64; depth++) {
        if (t == r2) RET(whole);
        if (RD32(t) == ti_si_vt + 8) t = RD32(t + 8); else break;
    }
    RET(0);
}

/* ---- std::basic_string<char/wchar_t>: object = pointer to chars; _Rep {len, cap, refcount} precedes them */
static u32 s_create(u32 len, u32 cap, u32 cs) {
    if (cap < len) cap = len;
    u32 rep = gmalloc(12 + (cap + 1) * cs);
    if (!rep) rt_fatal("std::string allocation of %u failed", cap);
    WR32(rep, len); WR32(rep + 4, cap); WR32(rep + 8, 0);
    memset(MEM + rep + 12 + len * cs, 0, cs);
    return rep + 12;
}
static void s_dispose(u32 p) {
    if (!p || p == EMPTY_P) return;
    s32 rc = (s32)RD32(p - 4);
    if (rc <= 0) gfree(p - 12); else WR32(p - 4, rc - 1);
}
static u32 s_grab(u32 p, u32 cs) {   /* share or clone */
    if (p == EMPTY_P) return p;
    s32 rc = (s32)RD32(p - 4);
    if (rc >= 0) { WR32(p - 4, rc + 1); return p; }
    u32 len = RD32(p - 12), q = s_create(len, len, cs);
    memcpy(MEM + q, MEM + p, len * cs);
    return q;
}
static u32 s_from(u32 src, u32 len, u32 cs) {
    if (!len) return EMPTY_P;
    u32 q = s_create(len, len, cs);
    memmove(MEM + q, MEM + src, len * cs);
    return q;
}
static u32 wlen(u32 s) { u32 n = 0; while (RD32(s + 4 * n)) n++; return n; }

IMPORT(_ZNSsC2Ev) { WR32(r0, EMPTY_P); RET(r0); }
IMPORT(_ZNSsC1EPKcRKSaIcE) { WR32(r0, r1 ? s_from(r1, strlen(GSTR(r1)), 1) : EMPTY_P); RET(r0); }
IMPORT(_ZNSsC1ERKSs) { WR32(r0, s_grab(RD32(r1), 1)); RET(r0); }
IMPORT(_ZNSsC1ERKSsmm) {   /* basic_string(const basic_string&, pos, n) */
    u32 p = RD32(r1), len = RD32(p - 12);
    if (r2 > len) rt_fatal("basic_string::substr out of range");
    u32 n = len - r2 < r3 ? len - r2 : r3;
    WR32(r0, s_from(p + r2, n, 1));
    RET(r0);
}
IMPORT(_ZNSsD2Ev) { s_dispose(RD32(r0)); RET(0); }
IMPORT(_ZNSs6assignEPKcm) { u32 old = RD32(r0); WR32(r0, s_from(r1, r2, 1)); s_dispose(old); RET(r0); }
IMPORT(_ZNSs6assignERKSs) {
    u32 old = RD32(r0), p = RD32(r1);
    if (old != p) { WR32(r0, s_grab(p, 1)); s_dispose(old); }
    RET(r0);
}
IMPORT(_ZNSs6appendEPKcm) {
    if (!r2) RET(r0);
    u32 p = RD32(r0), len = RD32(p - 12), cap = RD32(p - 8), nl = len + r2;
    if (p != EMPTY_P && (s32)RD32(p - 4) <= 0 && cap >= nl && !(r1 >= p && r1 < p + len)) {
        memcpy(MEM + p + len, MEM + r1, r2);
    } else {
        u32 q = s_create(nl, nl > 2 * cap ? nl : 2 * cap, 1);
        memcpy(MEM + q, MEM + p, len); memcpy(MEM + q + len, MEM + r1, r2);
        s_dispose(p); WR32(r0, q); p = q;
    }
    WR32(p - 12, nl); WR8(p + nl, 0);
    RET(r0);
}
static int s_cmp(u32 p, u32 len, u32 q, u32 qlen) {
    u32 n = len < qlen ? len : qlen;
    int r = memcmp(MEM + p, MEM + q, n);
    return r ? r : (int)(len - qlen);
}
IMPORT(_ZNKSs7compareEPKc) { u32 p = RD32(r0); RET((u32)s_cmp(p, RD32(p - 12), r1, strlen(GSTR(r1)))); }
IMPORT(_ZNKSs7compareERKSs) { u32 p = RD32(r0), q = RD32(r1); RET((u32)s_cmp(p, RD32(p - 12), q, RD32(q - 12))); }
IMPORT(_ZNSbIwSt11char_traitsIwESaIwEEC1EPKwRKS1_) { WR32(r0, r1 ? s_from(r1, wlen(r1), 4) : EMPTY_P); RET(r0); }
IMPORT(_ZNSbIwSt11char_traitsIwESaIwEED2Ev) { s_dispose(RD32(r0)); RET(0); }
IMPORT(_ZNSbIwSt11char_traitsIwESaIwEE6assignEPKwm) { u32 old = RD32(r0); WR32(r0, s_from(r1, r2, 4)); s_dispose(old); RET(r0); }

/* ---- red-black tree helpers (port of libstdc++ tree.cc). node: color@0 parent@4 left@8 right@12 */
#define C_(x) RD32(x)
#define P_(x) RD32((x) + 4)
#define L_(x) RD32((x) + 8)
#define R_(x) RD32((x) + 12)
#define SC(x, v) WR32(x, v)
#define SP(x, v) WR32((x) + 4, v)
#define SL(x, v) WR32((x) + 8, v)
#define SR(x, v) WR32((x) + 12, v)
enum { RED = 0, BLACK = 1 };
IMPORT(_ZSt18_Rb_tree_incrementPSt18_Rb_tree_node_base) {
    u32 x = r0;
    if (R_(x)) { x = R_(x); while (L_(x)) x = L_(x); }
    else { u32 y = P_(x); while (x == R_(y)) { x = y; y = P_(y); } if (R_(x) != y) x = y; }
    RET(x);
}
IMPORT(_ZSt18_Rb_tree_decrementPSt18_Rb_tree_node_base) {
    u32 x = r0;
    if (C_(x) == RED && P_(P_(x)) == x) x = R_(x);
    else if (L_(x)) { u32 y = L_(x); while (R_(y)) y = R_(y); x = y; }
    else { u32 y = P_(x); while (x == L_(y)) { x = y; y = P_(y); } x = y; }
    RET(x);
}
static void rot_left(u32 x, u32 rootp) {
    u32 y = R_(x);
    SR(x, L_(y));
    if (L_(y)) SP(L_(y), x);
    SP(y, P_(x));
    if (x == RD32(rootp)) WR32(rootp, y);
    else if (x == L_(P_(x))) SL(P_(x), y);
    else SR(P_(x), y);
    SL(y, x); SP(x, y);
}
static void rot_right(u32 x, u32 rootp) {
    u32 y = L_(x);
    SL(x, R_(y));
    if (R_(y)) SP(R_(y), x);
    SP(y, P_(x));
    if (x == RD32(rootp)) WR32(rootp, y);
    else if (x == R_(P_(x))) SR(P_(x), y);
    else SL(P_(x), y);
    SR(y, x); SP(x, y);
}
IMPORT(_ZSt29_Rb_tree_insert_and_rebalancebPSt18_Rb_tree_node_baseS0_RS_) {
    u32 left = r0 & 0xff, x = r1, p = r2, hdr = r3, rootp = hdr + 4;
    SP(x, p); SL(x, 0); SR(x, 0); SC(x, RED);
    if (left) {
        SL(p, x);
        if (p == hdr) { SP(hdr, x); SR(hdr, x); }
        else if (p == L_(hdr)) SL(hdr, x);
    } else {
        SR(p, x);
        if (p == R_(hdr)) SR(hdr, x);
    }
    while (x != RD32(rootp) && C_(P_(x)) == RED) {
        u32 xpp = P_(P_(x));
        if (P_(x) == L_(xpp)) {
            u32 y = R_(xpp);
            if (y && C_(y) == RED) { SC(P_(x), BLACK); SC(y, BLACK); SC(xpp, RED); x = xpp; }
            else {
                if (x == R_(P_(x))) { x = P_(x); rot_left(x, rootp); }
                SC(P_(x), BLACK); SC(xpp, RED); rot_right(xpp, rootp);
            }
        } else {
            u32 y = L_(xpp);
            if (y && C_(y) == RED) { SC(P_(x), BLACK); SC(y, BLACK); SC(xpp, RED); x = xpp; }
            else {
                if (x == L_(P_(x))) { x = P_(x); rot_right(x, rootp); }
                SC(P_(x), BLACK); SC(xpp, RED); rot_left(xpp, rootp);
            }
        }
    }
    SC(RD32(rootp), BLACK);
    RET(0);
}
