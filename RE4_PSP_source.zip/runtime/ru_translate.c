#include "rt.h"
#include "language.h"
#include "ru_strings.h"
#include "ru_missions.h"
#include "ru_extra.h"
#include "ru_story.h"
extern u32 ru_external_sys(u32), ru_external_mission(u32,u32), ru_external_extra(u32,u32), ru_external_story(u32);
/* Match exact original English text against the compiled table. */
int ru_story_index(const u16 *s) {
    u32 h=2166136261u; for(unsigned i=0;s[i];i++) h=(h^s[i])*16777619u;
    unsigned count=sizeof(ru_story)/sizeof(ru_story[0]),lo=0,hi=count;
    while(lo<hi) { unsigned m=lo+(hi-lo)/2; if(ru_story[m].hash<h)lo=m+1;else hi=m; }
    for(unsigned i=lo;i<count && ru_story[i].hash==h;i++){const u16 *e=ru_story[i].en; unsigned j=0;while(s[j] && e[j]==s[j])j++;if(!s[j]&&!e[j])return (int)i;}
    return -1;
}
u32 ru_sys_string(u32 id, u32 lang) {
    static u32 cache[sizeof(ru_table)/sizeof(ru_table[0])];
    /* Use the active font for all labels. Cyrillic custom name is shown
       only with the Russian font; other languages use a separately editable label. */
    if (language_menu_is_open() && (id==193 || id==198)) {
        static u32 english, russian, russian_ascii;
        static const u16 en[]={ 'E','N','G','L','I','S','H',0 };
        static const u16 ru[]={0x420,0x423,0x421,0x421,0x41a,0x418,0x419,0};
        static const u16 ru_ascii[]={ 'R','U','S','S','I','A','N',0 };
        if(id==198) {
            extern u32 ru_external_language_name(void), ru_external_language_name_en(void);
            u32 p=language_translate_for(lang) && language_russian_font_available()
                ? ru_external_language_name() : ru_external_language_name_en();
            if(p && RD16(p))return p;
        }
        u32 *slot=id==193 ? &english : language_translate_for(lang) && language_russian_font_available() ? &russian : &russian_ascii;
        const u16 *text=id==193 ? en : language_translate_for(lang) && language_russian_font_available() ? ru : ru_ascii;
        if(!*slot) { unsigned n=0; while(text[n])n++; u32 p=gmalloc((n+1)*2); if(!p)return 0;
            for(unsigned i=0;i<=n;i++)WR16(p+i*2,text[i]); *slot=p; }
        return *slot;
    }
    if (!language_translate_for(lang)) return 0;
    {u32 p=ru_external_sys(id);if(p)return p;}
    for (unsigned i=0; i<sizeof(ru_table)/sizeof(ru_table[0]); ++i) {
        if (ru_table[i].id != id) continue;
        if (!cache[i]) {
            const u16 *s=ru_table[i].text; unsigned n=0; while(s[n]) ++n;
            u32 p=gmalloc((n+2)*2); if (!p) return 0;
            for (unsigned j=0; j<=n; ++j) WR16(p+2*j,s[j]);
            WR16(p+2*(n+1),0); cache[i]=p;
        }
        return cache[i];
    }
    return 0;
}

u32 ru_mission_string(u32 kind,u32 group,u32 index,u32 lang) {
    static u32 cache[2][36];
    if (kind>1 || group>2 || index>11 || !language_translate_for(lang)) return 0;
    u32 id=group*12+index;
    {u32 p=ru_external_mission(kind,id);if(p)return p;}
    if (!cache[kind][id]) {
        const u16 *s=kind ? ru_info_table[id] : ru_name_table[id]; unsigned n=0; while(s[n]) ++n;
        u32 p=gmalloc((n+2)*2); if(!p) return 0;
        for(unsigned j=0;j<=n;++j) WR16(p+2*j,s[j]); WR16(p+2*(n+1),0); cache[kind][id]=p;
    }
    return cache[kind][id];
}

u32 ru_extra_string(u32 kind,u32 id,u32 lang) {
    static u32 cache[4][130];
    if(!language_translate_for(lang) || kind>3 || id>=130) return 0;
    {u32 p=ru_external_extra(kind,id);if(p)return p;}
    if(cache[kind][id]) return cache[kind][id];
    const u16 *txt=0;
#define LOOKUP(T) for(unsigned i=0;i<sizeof(T)/sizeof(T[0]);++i) if(T[i].id==id) {txt=T[i].text;break;}
    if(kind==0){LOOKUP(ru_extra_stage)}
    else if(kind==1){LOOKUP(ru_extra_item_name)}
    else if(kind==2){LOOKUP(ru_extra_item_info)}
    else {LOOKUP(ru_extra_file)}
#undef LOOKUP
    if(!txt) return 0;
    unsigned n=0;while(txt[n]) ++n; u32 p=gmalloc((n+2)*2);if(!p)return 0;
    for(unsigned j=0;j<=n;++j)WR16(p+2*j,txt[j]); WR16(p+2*(n+1),0); cache[kind][id]=p;return p;
}

u32 ru_translate_story(u32 ptr) {
    static u32 cache[sizeof(ru_story)/sizeof(ru_story[0])];
    if (!language_translate_story()) return ptr;
    const unsigned count=sizeof(ru_story)/sizeof(ru_story[0]);
    if(ptr<0x1000 || ptr>MEM_SIZE-4) return ptr;
    u32 h=2166136261u; unsigned n=0;
    while(n<1024 && ptr+2*n+2<=MEM_SIZE) {
        u32 c=RD16(ptr+2*n); if(!c) break; h=(h^c)*16777619u; ++n;
    }
    if(n==1024 || ptr+2*n+2>MEM_SIZE) return ptr;
    unsigned lo=0,hi=count; while(lo<hi) { unsigned mid=lo+(hi-lo)/2; if(ru_story[mid].hash<h)lo=mid+1;else hi=mid; }
    for(unsigned i=lo;i<count && ru_story[i].hash==h;++i) {
        const u16 *e=ru_story[i].en; unsigned j=0;
        while(j<n && e[j] && RD16(ptr+2*j)==e[j])++j;
        if(j!=n || e[j]) continue;
        {u32 p=ru_external_story(i);if(p)return p;}
        if(!cache[i]) { const u16 *t=ru_story[i].ru; unsigned k=0; while(t[k]) ++k;
            u32 p=gmalloc((k+2)*2);if(!p)return ptr;
            for(unsigned z=0;z<=k;++z) WR16(p+2*z,t[z]); WR16(p+2*(k+1),0); cache[i]=p; }
        return cache[i];
    }
    return ptr;
}
