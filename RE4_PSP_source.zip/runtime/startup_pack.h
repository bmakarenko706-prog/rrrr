#ifndef STARTUP_PACK_H
#define STARTUP_PACK_H
#include <stdint.h>
/* Optional read-only asset cache. -1 means always use original file. */
int startup_pack_find(const char *path);
uint32_t startup_pack_size(int entry);
int startup_pack_read(int entry, uint32_t pos, void *dst, uint32_t len);
const char *startup_pack_path(int entry);
void startup_pack_invalidate(const char *path);
void startup_pack_report(void);
void startup_pack_get_stats(unsigned *hits, unsigned *candidates);
#endif
