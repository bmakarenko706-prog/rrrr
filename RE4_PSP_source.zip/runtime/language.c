#include "rt.h"
#include "language.h"
#include <stdio.h>
#include <string.h>
/* Existing RU-alpha builds used Russian by default; preserve that default. */
static int active_ru=1, selected_ru=1, russian_font_available;
static u32 guest_language=1;
static int font_preload_original, original_font_ready;
static char selection_path[512];
void language_init(const char *game_dir) {
    active_ru=selected_ru=1; guest_language=1; font_preload_original=0; original_font_ready=0;
    snprintf(selection_path,sizeof selection_path,"%s/re4_language.txt",game_dir);
    FILE *f=fopen(selection_path,"rb");
    if(f) { char b[16]={0}; size_t n=fread(b,1,sizeof b-1,f);fclose(f);
        while(n && (b[n-1]=='\n'||b[n-1]=='\r'||b[n-1]==' '||b[n-1]=='\t')) b[--n]=0;
        if(!strcmp(b,"en")) selected_ru=0; else if(!strcmp(b,"ru")) selected_ru=1;
    }
    active_ru=selected_ru;
    char font_path[512]; snprintf(font_path,sizeof font_path,"%s/ru_font_U16le.fnt",game_dir);
    FILE *font=fopen(font_path,"rb"); russian_font_available=(font!=NULL); if(font)fclose(font);
}
int language_selected_russian(void){return selected_ru;}
int language_active_russian(void){return active_ru;}
int language_russian_font_available(void){return russian_font_available;}
int language_use_russian_font(void){return !font_preload_original;}
void language_force_original_font(int on){font_preload_original=!!on;}
void language_original_font_ready(void){original_font_ready=1;}
u32 language_font_index(u32 requested){
    u32 result=requested==1 && original_font_ready && !(active_ru && guest_language==1) ? 2 : requested;
    rt_log("[font] select requested=%u chosen=%u ru=%d guest=%u orig_ready=%d",requested,result,active_ru,guest_language,original_font_ready);
    return result;
}
static int menu_open;
void language_menu_begin(void) { menu_open=1; }
void language_menu_end(void) { menu_open=0; }
int language_menu_is_open(void) { return menu_open; }
u32 language_menu_initial(u32 guest) {
    return guest==1 && selected_ru ? 0 : guest;
}
/* The original 0=default slot is now Russian; 1 remains English.
   The actual game always receives its original English slot for either. */
u32 language_menu_commit(u32 choice, u32 previous) {
    rt_log("[font] menu choice=%u previous=%u active_ru=%d",choice,previous,active_ru);
    if (choice<=1) {
        int next=(choice==0);
        if (next!=selected_ru) {
            FILE *f=selection_path[0] ? fopen(selection_path,"wb") : NULL;
            int ok=0;
            if(f) { ok=fputs(next?"ru\n":"en\n",f)>=0; if(fclose(f)!=0) ok=0; }
            if(ok) selected_ru=next;
            else { extern void rt_log(const char *, ...); rt_log("[language] failed to save selection"); return previous==0 ? 1 : previous; }
        }
        active_ru=selected_ru;
        return 1;
    }
    return choice;
}
void language_set_guest(u32 lang){guest_language=lang;rt_log("[font] guest language=%u russian=%d",lang,active_ru);}
int language_translate_for(u32 lang){return active_ru && lang==1;}
int language_translate_story(void){return language_translate_for(guest_language);}

/* Language numbers do not follow the visual order of the buttons. Read the
   same CFString language codes that the game's GetDeviceLanguage compares.
   That function maps the constants at these addresses to IDs 2,4,5,3. */
int language_manual_id(void) {
    if (guest_language == 1) return active_ru ? 0 : 1;
    u32 obj;
    switch (guest_language) {
        case 2: obj=0xe15e4u; break;
        case 3: obj=0xe1614u; break;
        case 4: obj=0xe15f4u; break;
        case 5: obj=0xe1604u; break;
        default: return 1;
    }
    if (MEM && obj <= MEM_SIZE && MEM_SIZE - obj >= 16) {
        u32 p=RD32(obj+8), n=RD32(obj+12);
        if (n>=2 && n<=32 && p<MEM_SIZE && n<=MEM_SIZE-p) {
            unsigned a=MEM[p], b=MEM[p+1];
            if(a>='A' && a<='Z')a+='a'-'A';
            if(b>='A' && b<='Z')b+='a'-'A';
            /* Locale may have a territory suffix (e.g. es-ES). */
            if(n==2 || MEM[p+2]=='-' || MEM[p+2]=='_') {
                if(a=='f'&&b=='r')return 2;
                if(a=='d'&&b=='e')return 3;
                if(a=='i'&&b=='t')return 4;
                if(a=='e'&&b=='s')return 5;
                if(a=='e'&&b=='n')return 1;
            }
        }
    }
    /* Report rather than silently present another foreign language. */
    rt_log("[manual] unknown game language id=%u; using English", guest_language);
    return 1;
}
