/* UIKit / QuartzCore / OpenGLES (EAGL) / MediaPlayer / CoreMotion-era classes, UIApplicationMain and the run loop */
#include "objc.h"
#include "funcs.h"
#include "platform.h"
#include <string.h>
#ifdef RE4_PSP
#include "psp_movie.h"
#include "startup_pack.h"
#include "bundle_stat.h"
#ifdef STARTUP_PROFILE
#include "startup_profile.h"
#endif
#endif

double timers_run(u32 sp);
u32 nsdict_make(int n, const u32 *keys, const u32 *vals);
void gl_drawable_storage(int w, int h);   /* hle_gl.c */
void gl_present(void);
void audio_pump(u32 sp);                   /* hle_audio.c */

/* stret natives receive (ret, self, sel, arg0, sp) */
#define NMS(n) static u64 n(u32 ret, u32 self, u32 _cmd, u32 a2, u32 sp)
#define UNUSED_S (void)ret; (void)self; (void)_cmd; (void)a2; (void)sp
static void wr_rect(u32 p, float x, float y, float w, float h) { WRF(p, x); WRF(p + 4, y); WRF(p + 8, w); WRF(p + 12, h); }
static u32 singleton(const char *cls, u32 *slot) {
    if (!*slot) { *slot = objc_new_named(cls); WR32(*slot - 4, 0x7fffffffu); }
    return *slot;
}
NM(u_self) { UNUSED_ARGS; RET(self); }
NM(u_nop) { UNUSED_ARGS; RET(0); }
NM(u_yes) { UNUSED_ARGS; RET(1); }

/* deferred notifications (movie player callbacks are delivered on a later run-loop pass) */
static const char *MP_FINISHED = "MPMoviePlayerPlaybackDidFinishNotification";
static const char *MP_PRELOADED = "MPMoviePlayerContentPreloadDidFinishNotification";
#ifdef RE4_PSP
static const char *MP_START_INTERNAL = "@re4:movie-start";
static void movie_pending_play(u32 object);
#endif
typedef struct { const char *name; u32 object; int delay; } pending_note;
static pending_note pend[16]; static int npend;
static int post_later(const char *name, u32 object, int frames) {
    if (npend >= 16) return 0;
    pend[npend].name = name; pend[npend].object = objc_retain(object); pend[npend++].delay = frames;
    return 1;
}
/* Cancel only this player's stale preload; another player's notification stays queued. */
static int cancel_later(const char *name, u32 object) {
    int count = 0;
    for (int i = 0; i < npend; i++) {
        if (pend[i].object != object || strcmp(pend[i].name, name)) continue;
        u32 held = pend[i].object;
        memmove(&pend[i], &pend[i + 1], (npend - i - 1) * sizeof *pend);
        npend--; i--; count++;
        objc_release(held);
    }
    return count;
}
static void run_pending(u32 sp) {
    for (int i = 0; i < npend; i++) {
        if (pend[i].delay-- > 0) continue;
        pending_note p = pend[i];
        memmove(&pend[i], &pend[i + 1], (npend - i - 1) * sizeof *pend); npend--; i--;
#ifdef RE4_PSP
        if (!strcmp(p.name, MP_START_INTERNAL)) movie_pending_play(p.object);
        else {
            /* Permit a real replay from inside a completion observer. */
            if (!strcmp(p.name, MP_FINISHED)) WR32(p.object + 16, 0);
            post_notification(sp, p.name, p.object);
        }
#else
        post_notification(sp, p.name, p.object);
#endif
        objc_release(p.object);
    }
}

/* ---------- UIApplication: [isa][delegate][keyWindow][orientation][idle] */
static u32 g_app;
NM(app_shared) { UNUSED_ARGS; RET(singleton("UIApplication", &g_app)); }
NM(app_delegate) { UNUSED_ARGS; RET(RD32(self + 4)); }
NM(app_setdelegate) { UNUSED_ARGS; WR32(self + 4, a2); RET(0); }
NM(app_keywindow) { UNUSED_ARGS; RET(RD32(self + 8)); }
NM(app_windows) { UNUSED_ARGS; u32 a = nsarray_new(); if (RD32(self + 8)) nsarray_add(a, RD32(self + 8)); RET(objc_autorelease(a)); }
NM(app_setorient) { UNUSED_ARGS; WR32(self + 12, a2); RET(0); }
NM(app_orient) { UNUSED_ARGS; RET(RD32(self + 12)); }
NM(app_openurl) { UNUSED_ARGS; rt_log("[uikit] openURL: %s (ignored)", a2 ? objc_nsstring_cstr(RD32(a2 + 4)) : "nil"); RET(0); }
static nmdef app_im[] = {{"delegate", app_delegate}, {"setDelegate:", app_setdelegate}, {"keyWindow", app_keywindow},
    {"windows", app_windows}, {"setStatusBarOrientation:", app_setorient}, {"setStatusBarOrientation:animated:", app_setorient},
    {"statusBarOrientation", app_orient}, {"openURL:", app_openurl}, {"setIdleTimerDisabled:", u_nop},
    {"setStatusBarHidden:", u_nop}, {"setStatusBarHidden:animated:", u_nop}, {0}};
static nmdef app_cm[] = {{"sharedApplication", app_shared}, {0}};

/* ---------- UIScreen */
static u32 g_screen;
NM(scr_main) { UNUSED_ARGS; RET(singleton("UIScreen", &g_screen)); }
NMS(scr_frame) { UNUSED_S; wr_rect(ret, 0, 0, 320, 480); RET(ret); }
static nmdef scr_im[] = {{"applicationFrame", (nmeth)scr_frame}, {"bounds", (nmeth)scr_frame}, {0}};
static nmdef scr_cm[] = {{"mainScreen", scr_main}, {0}};

/* ---------- CALayer / CAEAGLLayer: [isa][view][opaque][drawableProperties] */
NM(ly_setopaque) { UNUSED_ARGS; WR32(self + 8, a2 & 0xff); RET(0); }
NM(ly_opaque) { UNUSED_ARGS; RET(RD32(self + 8)); }
NM(ly_setprops) { UNUSED_ARGS; objc_retain(a2); objc_release(RD32(self + 12)); WR32(self + 12, a2); RET(0); }
NM(ly_props) { UNUSED_ARGS; RET(RD32(self + 12)); }
NM(ly_dealloc) { UNUSED_ARGS; objc_release(RD32(self + 12)); objc_dealloc_raw(self); RET(0); }
static nmdef layer_im[] = {{"setOpaque:", ly_setopaque}, {"isOpaque", ly_opaque}, {"setDrawableProperties:", ly_setprops},
    {"drawableProperties", ly_props}, {"dealloc", ly_dealloc}, {"setNeedsDisplay", u_nop}, {0}};
NM(ly_class) { UNUSED_ARGS; RET(self); }
static nmdef layer_cm[] = {{"layer", ly_class}, {0}};

/* ---------- UIView: [isa][x][y][w][h][layer][superview][subviews]  (game ivars start at 32) */
static u32 view_init(u32 self, u32 sp, float x, float y, float w, float h) {
    wr_rect(self + 4, x, y, w, h);
    u32 lc = (u32)objc_send(sp, RD32(self), sel_named("layerClass"), 0, 0);
    if (!lc) lc = objc_class_named("CALayer");
    u32 layer = objc_new(lc);
    WR32(layer + 4, self);
    WR32(self + 20, layer);
    return self;
}
NM(v_initframe) { UNUSED_ARGS; RET(view_init(self, sp, U2F(a2), U2F(a3), U2F(SARG(0)), U2F(SARG(1)))); }
NM(v_initcoder) { UNUSED_ARGS; RET(view_init(self, sp, 0, 0, 320, 480)); }
NM(v_init) { UNUSED_ARGS; RET(view_init(self, sp, 0, 0, 320, 480)); }
NM(v_layer) { UNUSED_ARGS; RET(RD32(self + 20)); }
NM(v_superview) { UNUSED_ARGS; RET(RD32(self + 24)); }
NM(v_addsub) { UNUSED_ARGS;
    if (!a2) RET(0);
    if (!RD32(self + 28)) WR32(self + 28, nsarray_new());
    nsarray_add(RD32(self + 28), a2);
    WR32(a2 + 24, self);
    RET(0); }
NM(v_remove) { UNUSED_ARGS;
    u32 sv = RD32(self + 24), arr = sv ? RD32(sv + 28) : 0;
    if (arr) { u32 n = RD32(arr + 4), it = RD32(arr + 12);
        for (u32 i = 0; i < n; i++) if (RD32(it + 4 * i) == self) {
            memmove(MEM + it + 4 * i, MEM + it + 4 * i + 4, 4 * (n - i - 1)); WR32(arr + 4, n - 1);
            WR32(self + 24, 0); objc_release(self); break; } }
    RET(0); }
NM(v_subviews) { UNUSED_ARGS; if (!RD32(self + 28)) WR32(self + 28, nsarray_new()); RET(RD32(self + 28)); }
NMS(v_frame) { UNUSED_S; memcpy(MEM + ret, MEM + self + 4, 16); RET(ret); }
NMS(v_bounds) { UNUSED_S; wr_rect(ret, 0, 0, RDF(self + 12), RDF(self + 16)); RET(ret); }
NM(v_setframe) { UNUSED_ARGS; wr_rect(self + 4, U2F(a2), U2F(a3), U2F(SARG(0)), U2F(SARG(1))); RET(0); }
NM(v_layerclass) { UNUSED_ARGS; RET(objc_class_named("CALayer")); }
NM(v_dealloc) { UNUSED_ARGS;
    u32 subs = RD32(self + 28);
    if (subs) objc_release(subs);
    objc_release(RD32(self + 20));
    objc_dealloc_raw(self); RET(0); }
NM(v_bg) { UNUSED_ARGS; static u32 c; if (!c) c = objc_new_named("UIColor"); RET(c); }
static nmdef view_im[] = {{"initWithFrame:", v_initframe}, {"initWithCoder:", v_initcoder}, {"init", v_init},
    {"layer", v_layer}, {"superview", v_superview}, {"addSubview:", v_addsub}, {"removeFromSuperview", v_remove},
    {"subviews", v_subviews}, {"frame", (nmeth)v_frame}, {"bounds", (nmeth)v_bounds}, {"setFrame:", v_setframe},
    {"dealloc", v_dealloc}, {"setBackgroundColor:", u_nop}, {"backgroundColor", v_bg}, {"setMultipleTouchEnabled:", u_nop},
    {"setUserInteractionEnabled:", u_nop}, {"setExclusiveTouch:", u_nop}, {"setOpaque:", u_nop}, {"isOpaque", u_yes},
    {"setHidden:", u_nop}, {"setAlpha:", u_nop}, {"setTransform:", u_nop}, {"setCenter:", u_nop}, {"setNeedsDisplay", u_nop},
    {"setAutoresizingMask:", u_nop}, {"setAutoresizesSubviews:", u_nop}, {"setClearsContextBeforeDrawing:", u_nop},
    {"setContentMode:", u_nop}, {"bringSubviewToFront:", u_nop}, {"sendSubviewToBack:", u_nop}, {"layoutSubviews", u_nop},
    {"touchesBegan:withEvent:", u_nop}, {"touchesMoved:withEvent:", u_nop}, {"touchesEnded:withEvent:", u_nop},
    {"touchesCancelled:withEvent:", u_nop}, {"window", v_superview}, {0}};
static nmdef view_cm[] = {{"layerClass", v_layerclass}, {0}};
NM(w_makekey) { UNUSED_ARGS; if (g_app) WR32(g_app + 8, self); RET(0); }
static nmdef window_im[] = {{"makeKeyAndVisible", w_makekey}, {"makeKeyWindow", w_makekey}, {0}};

/* ---------- UIViewController: [isa][view] */
NM(vc_view) { UNUSED_ARGS; RET(RD32(self + 4)); }
NM(vc_setview) { UNUSED_ARGS; objc_retain(a2); objc_release(RD32(self + 4)); WR32(self + 4, a2); RET(0); }
NM(vc_dealloc) { UNUSED_ARGS; objc_release(RD32(self + 4)); objc_dealloc_raw(self); RET(0); }
NM(vc_present) { UNUSED_ARGS; rt_log("[uikit] presentModalViewController (ignored)"); RET(0); }
static nmdef vc_im[] = {{"view", vc_view}, {"setView:", vc_setview}, {"initWithCoder:", u_self}, {"init", u_self},
    {"initWithNibName:bundle:", u_self}, {"dealloc", vc_dealloc}, {"didReceiveMemoryWarning", u_nop},
    {"presentModalViewController:animated:", vc_present}, {"dismissModalViewControllerAnimated:", u_nop},
    {"setWantsFullScreenLayout:", u_nop}, {0}};

/* ---------- UIColor */
static u32 g_color;
NM(col_any) { UNUSED_ARGS; RET(singleton("UIColor", &g_color)); }
static nmdef color_cm[] = {{"blackColor", col_any}, {"whiteColor", col_any}, {"clearColor", col_any},
    {"colorWithRed:green:blue:alpha:", col_any}, {"colorWithWhite:alpha:", col_any}, {0}};

/* ---------- UIDevice */
static u32 g_device;
NM(dev_current) { UNUSED_ARGS; RET(singleton("UIDevice", &g_device)); }
NM(dev_orient) { UNUSED_ARGS; RET(3); }   /* UIDeviceOrientationLandscapeLeft */
NM(dev_model) { UNUSED_ARGS; RET(nsstr("iPhone")); }
NM(dev_version) { UNUSED_ARGS; RET(nsstr("3.1.3")); }
NM(dev_udid) { UNUSED_ARGS; RET(nsstr("0000000000000000000000000000000000000000")); }
static nmdef dev_im[] = {{"orientation", dev_orient}, {"beginGeneratingDeviceOrientationNotifications", u_nop},
    {"endGeneratingDeviceOrientationNotifications", u_nop}, {"model", dev_model}, {"systemVersion", dev_version},
    {"uniqueIdentifier", dev_udid}, {"name", dev_model}, {0}};
static nmdef dev_cm[] = {{"currentDevice", dev_current}, {0}};

/* ---------- UIAccelerometer: [isa][delegate][interval d]; UIAcceleration: [isa][pad][x d][y d][z d] */
static u32 g_accel;
NM(acc_shared) { UNUSED_ARGS; RET(singleton("UIAccelerometer", &g_accel)); }
NM(acc_setdelegate) { UNUSED_ARGS; WR32(self + 4, a2); RET(0); }
NM(acc_delegate) { UNUSED_ARGS; RET(RD32(self + 4)); }
NM(acc_setinterval) { UNUSED_ARGS; WR32(self + 8, a2); WR32(self + 12, a3); RET(0); }
static nmdef acc_im[] = {{"setDelegate:", acc_setdelegate}, {"delegate", acc_delegate}, {"setUpdateInterval:", acc_setinterval}, {0}};
static nmdef acc_cm[] = {{"sharedAccelerometer", acc_shared}, {0}};
NM(acn_x) { UNUSED_ARGS; RETD(RDD(self + 8)); }
NM(acn_y) { UNUSED_ARGS; RETD(RDD(self + 16)); }
NM(acn_z) { UNUSED_ARGS; RETD(RDD(self + 24)); }
static nmdef accn_im[] = {{"x", acn_x}, {"y", acn_y}, {"z", acn_z}, {0}};

/* ---------- UITouch: [isa][phase][x][y][px][py][view][tapCount][timestamp d]; UIEvent: [isa][touches] */
static void touch_point(u32 ret, u32 touch, u32 view, int prev) {
    float x = RDF(touch + (prev ? 16 : 8)), y = RDF(touch + (prev ? 20 : 12));
    for (u32 v = view; v; v = RD32(v + 24)) { x -= RDF(v + 4); y -= RDF(v + 8); }   /* window -> view coordinates */
    WRF(ret, x); WRF(ret + 4, y);
}
NMS(t_loc) { UNUSED_S; touch_point(ret, self, a2, 0); RET(ret); }
NMS(t_prevloc) { UNUSED_S; touch_point(ret, self, a2, 1); RET(ret); }
NM(t_phase) { UNUSED_ARGS; RET(RD32(self + 4)); }
NM(t_view) { UNUSED_ARGS; RET(RD32(self + 24)); }
NM(t_taps) { UNUSED_ARGS; RET(RD32(self + 28)); }
NM(t_time) { UNUSED_ARGS; RETD(RDD(self + 32)); }
static nmdef touch_im[] = {{"locationInView:", (nmeth)t_loc}, {"previousLocationInView:", (nmeth)t_prevloc},
    {"phase", t_phase}, {"view", t_view}, {"tapCount", t_taps}, {"timestamp", t_time}, {0}};
NM(ev_all) { UNUSED_ARGS; RET(RD32(self + 4)); }
static nmdef event_im[] = {{"allTouches", ev_all}, {"touchesForView:", ev_all}, {"touchesForWindow:", ev_all}, {0}};

/* ---------- EAGLContext: [isa][api] */
static u32 g_ctx;
NM(ctx_initapi) { UNUSED_ARGS; WR32(self + 4, a2); rt_log("[eagl] context API %u", a2); RET(self); }
NM(ctx_setcurrent) { UNUSED_ARGS; g_ctx = a2; RET(1); }
NM(ctx_current) { UNUSED_ARGS; RET(g_ctx); }
NM(ctx_storage) { UNUSED_ARGS;   /* renderbufferStorage:(target) fromDrawable:(layer) */
    u32 view = a3 ? RD32(a3 + 4) : 0;
    int w = view ? (int)RDF(view + 12) : 320, h = view ? (int)RDF(view + 16) : 480;
    gl_drawable_storage(w, h);
    RET(1); }
NM(ctx_present) { UNUSED_ARGS; gl_present(); RET(1); }
NM(ctx_api) { UNUSED_ARGS; RET(RD32(self + 4)); }
static nmdef ctx_im[] = {{"initWithAPI:", ctx_initapi}, {"renderbufferStorage:fromDrawable:", ctx_storage},
    {"presentRenderbuffer:", ctx_present}, {"API", ctx_api}, {0}};
static nmdef ctx_cm[] = {{"setCurrentContext:", ctx_setcurrent}, {"currentContext", ctx_current}, {0}};

/* ---------- MPMoviePlayerController: [isa][url][controlMode][scalingMode][playing]
   Preload and completion notifications are posted on later run-loop passes. */
NM(mp_init) { UNUSED_ARGS;
    WR32(self + 4, objc_retain(a2));
    rt_log("[movie] request %s", a2 ? objc_nsstring_cstr(RD32(a2 + 4)) : "nil");
    post_later(MP_PRELOADED, self, 1);
    RET(self); }
#ifdef RE4_PSP
/* Execute only after the guest finishes its current callback. Until completion
   is delivered, repeated play requests for this same controller are idempotent.
   The queue keeps the player alive. 1 = scheduled/playing, 2 = finish queued. */
static void movie_pending_play(u32 self) {
    if (RD32(self + 16) != 1) return;
    u32 url = RD32(self + 4);
    const char *movie = url ? objc_nsstring_cstr(RD32(url + 4)) : NULL;
    char trace[256];
    snprintf(trace, sizeof trace, "movie: start %s player=%08x", movie ? movie : "nil", self);
    plat_exit_trace(trace);
    bundle_stat_stop();
    startup_pack_report();
#ifdef STARTUP_PROFILE
    startup_profile_show();
#endif
    psp_movie_play(movie);
    plat_exit_trace("movie: playback ended");
    WR32(self + 16, 2);
    if (!post_later(MP_FINISHED, self, 2)) {
        WR32(self + 16, 0);
        plat_exit_trace("movie: finish notification queue full");
    }
}
#endif
NM(mp_play) { UNUSED_ARGS;
#ifdef RE4_PSP
    if (RD32(self + 16)) {
        char trace[96]; snprintf(trace, sizeof trace, "movie: duplicate ignored player=%08x phase=%u", self, RD32(self + 16));
        plat_exit_trace(trace); RET(0);
    }
    objc_retain(self); /* cancellation can release the queued retain */
    int canceled = cancel_later(MP_PRELOADED, self);
    WR32(self + 16, 1);
    char trace[96]; snprintf(trace, sizeof trace, "movie: queued player=%08x stale preload=%d", self, canceled);
    plat_exit_trace(trace);
    if (!post_later(MP_START_INTERNAL, self, 0)) {
        WR32(self + 16, 0);
        plat_exit_trace("movie: start queue full");
    }
    objc_release(self);
#else
    WR32(self + 16, 0); post_later(MP_FINISHED, self, 2);
#endif
    RET(0);
}
NM(mp_stop) { UNUSED_ARGS;
#ifdef RE4_PSP
    objc_retain(self);
    cancel_later(MP_START_INTERNAL, self);
    cancel_later(MP_FINISHED, self);
    WR32(self + 16, 0);
    objc_release(self);
#else
    WR32(self + 16, 0);
#endif
    RET(0);
}
NM(mp_setmode) { UNUSED_ARGS; WR32(self + 8, a2); RET(0); }
NM(mp_mode) { UNUSED_ARGS; RET(RD32(self + 8)); }
NM(mp_setscale) { UNUSED_ARGS; WR32(self + 12, a2); RET(0); }
NM(mp_scale) { UNUSED_ARGS; RET(RD32(self + 12)); }
NM(mp_dealloc) { UNUSED_ARGS; objc_release(RD32(self + 4)); objc_dealloc_raw(self); RET(0); }
static nmdef mp_im[] = {{"initWithContentURL:", mp_init}, {"play", mp_play}, {"stop", mp_stop}, {"pause", mp_stop},
    {"setMovieControlMode:", mp_setmode}, {"movieControlMode", mp_mode}, {"setScalingMode:", mp_setscale},
    {"scalingMode", mp_scale}, {"setBackgroundColor:", u_nop}, {"setShouldAutoplay:", u_nop}, {"dealloc", mp_dealloc},
    {"prepareToPlay", u_nop}, {0}};

static nclass uikit_cls[] = {
    {"UIResponder", "NSObject", 0, 0, 4},
    {"UIApplication", "UIResponder", app_im, app_cm, 20},
    {"UIScreen", "NSObject", scr_im, scr_cm, 4},
    {"CALayer", "NSObject", layer_im, layer_cm, 16},
    {"CAEAGLLayer", "CALayer", 0, 0, 16},
    {"UIView", "UIResponder", view_im, view_cm, 32},
    {"UIWindow", "UIView", window_im, 0, 32},
    {"UIViewController", "UIResponder", vc_im, 0, 8},
    {"UIColor", "NSObject", 0, color_cm, 8},
    {"UIDevice", "NSObject", dev_im, dev_cm, 4},
    {"UIAccelerometer", "NSObject", acc_im, acc_cm, 16},
    {"UIAcceleration", "NSObject", accn_im, 0, 32},
    {"UITouch", "NSObject", touch_im, 0, 40},
    {"UIEvent", "NSObject", event_im, 0, 8},
    {"EAGLContext", "NSObject", ctx_im, ctx_cm, 8},
    {"MPMoviePlayerController", "NSObject", mp_im, 0, 20},
    {0}};

/* data symbols that are NSString constants: the import is the address of a variable holding the string */
static void const_string(const char *sym, const char *value) {
    u32 var = gmalloc(4); u32 s = nsstr_owned(value);
    WR32(s - 4, 0x7fffffffu);
    WR32(var, s);
    rt_register_data(sym, var);
}
void avaudio_classes(void);
void uikit_classes(void) { objc_add_classes(uikit_cls); avaudio_classes(); }
void uikit_constants(void) {
    const_string("_kEAGLColorFormatRGB565", "EAGLColorFormatRGB565");
    const_string("_kEAGLColorFormatRGBA8", "EAGLColorFormatRGBA8");
    const_string("_kEAGLDrawablePropertyColorFormat", "EAGLDrawablePropertyColorFormat");
    const_string("_kEAGLDrawablePropertyRetainedBacking", "EAGLDrawablePropertyRetainedBacking");
    const_string("_MPMoviePlayerPlaybackDidFinishNotification", MP_FINISHED);
    const_string("_MPMoviePlayerContentPreloadDidFinishNotification", MP_PRELOADED);
    const_string("_UIDeviceOrientationDidChangeNotification", "UIDeviceOrientationDidChangeNotification");
}

/* ---------- touches: the platform layer reports up to PLAT_MAX_TOUCH fingers in 320x480 window coordinates */
static u32 g_touch[PLAT_MAX_TOUCH];
static int g_down[PLAT_MAX_TOUCH];
static u32 g_view;
static void send_touches(u32 sp, const char *selname, u32 set) {
    u32 ev = objc_new_named("UIEvent");
    WR32(ev + 4, objc_retain(set));
    objc_send(sp, g_view, sel_named(selname), set, ev);
    objc_release(set); objc_release(ev);
}
static void deliver_touches(u32 sp, const plat_input *in) {
    u32 began = 0, moved = 0, ended = 0;
    double ts = plat_time_us() / 1e6;
    for (int i = 0; i < PLAT_MAX_TOUCH; i++) {
        const plat_touch *t = &in->touch[i];
        u32 o = g_touch[i];
        if (t->down && !g_down[i]) {
            if (!o) { o = g_touch[i] = objc_new_named("UITouch"); WR32(o - 4, 0x7fffffffu); }
            WRF(o + 8, t->x); WRF(o + 12, t->y); WRF(o + 16, t->x); WRF(o + 20, t->y);
            WR32(o + 4, 0); WR32(o + 24, g_view); WR32(o + 28, 1); WRD(o + 32, ts);
            if (!began) began = nsarray_new();
            nsarray_add(began, o);
        } else if (t->down && g_down[i]) {
            if (RDF(o + 8) != t->x || RDF(o + 12) != t->y) {
                WRF(o + 16, RDF(o + 8)); WRF(o + 20, RDF(o + 12));
                WRF(o + 8, t->x); WRF(o + 12, t->y); WR32(o + 4, 1); WRD(o + 32, ts);
                if (!moved) moved = nsarray_new();
                nsarray_add(moved, o);
            }
        } else if (!t->down && g_down[i]) {
            WRF(o + 16, RDF(o + 8)); WRF(o + 20, RDF(o + 12));
            WR32(o + 4, 3); WRD(o + 32, ts);
            if (!ended) ended = nsarray_new();
            nsarray_add(ended, o);
        }
        g_down[i] = t->down;
    }
    if (began) send_touches(sp, "touchesBegan:withEvent:", began);
    if (moved) send_touches(sp, "touchesMoved:withEvent:", moved);
    if (ended) send_touches(sp, "touchesEnded:withEvent:", ended);
}

u64 rt_idle_us;

/* ---------- UIApplicationMain: emulate MainWindow.nib, then run the main loop */
IMPORT(UIApplicationMain) {
    (void)r0; (void)r1; (void)r2; (void)r3;
    u32 app = singleton("UIApplication", &g_app);
    u32 cls_delegate = objc_class_named("Bio4AppDelegate"), cls_vc = objc_class_named("Bio4AppViewController"),
        cls_view = objc_class_named("Bio4AppView");
    if (!cls_delegate || !cls_vc || !cls_view) rt_fatal("game classes not found");
    u32 delegate = (u32)objc_send(sp, objc_new(cls_delegate), sel_named("init"), 0, 0);
    u32 window = objc_new_named("UIWindow");
    view_init(window, sp, 0, 0, 320, 480);
    u32 vc = (u32)objc_send(sp, objc_new(cls_vc), sel_named("initWithCoder:"), 0, 0);
    u32 view = (u32)objc_send(sp, objc_new(cls_view), sel_named("initWithCoder:"), 0, 0);
    if (!view) rt_fatal("Bio4AppView initWithCoder: failed");
    g_view = view;
    objc_send(sp, vc, sel_named("setView:"), view, 0);
    objc_release(view);
    objc_send(sp, delegate, sel_named("setWindow:"), window, 0);
    objc_send(sp, delegate, sel_named("setViewController:"), vc, 0);
    WR32(app + 4, delegate);
    objc_send(sp, view, sel_named("awakeFromNib"), 0, 0);
    rt_log("[uikit] nib loaded: delegate %x window %x vc %x view %x", delegate, window, vc, view);
    objc_send(sp, delegate, sel_named("applicationDidFinishLaunching:"), app, 0);
    objc_set_sp(sp);
    objc_drain_pool();
    rt_log("[uikit] applicationDidFinishLaunching done, heap free %u KB", heap_free_bytes() >> 10);
    plat_input in;
    int active = 1;
    for (;;) {
        int r = plat_poll(&in);
        if (r == PLAT_QUIT) break;
        if (r == PLAT_SUSPEND && active) { objc_send(sp, delegate, sel_named("applicationWillResignActive:"), app, 0); active = 0; }
        if (r == PLAT_RESUME && !active) { objc_send(sp, delegate, sel_named("applicationDidBecomeActive:"), app, 0); active = 1; }
        if (active) deliver_touches(sp, &in);
        double next = timers_run(sp);
        run_pending(sp);
        audio_pump(sp);
        objc_set_sp(sp);
        objc_drain_pool();
        if (next > 0) {
            u64 t0 = plat_time_us();
            plat_sleep_us(next * 1e6 > 20000 ? 20000 : (u32)(next * 1e6) + 1);
            rt_idle_us += plat_time_us() - t0;
        }
    }
#ifdef RE4_PSP
    plat_exit_trace("guest: before applicationWillTerminate");
#endif
    objc_send(sp, delegate, sel_named("applicationWillTerminate:"), app, 0);
#ifdef RE4_PSP
    plat_exit_trace("guest: applicationWillTerminate returned");
#endif
    /* Return through guest main to the platform for orderly shutdown. */
    RET(0);
}
