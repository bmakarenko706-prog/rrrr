#include "objc.h"
#include "funcs.h"
#include <string.h>

#define NTAG 0x4e430000u
#define NMETA 0x8000u
#define MAXNC 96
static nclass *ncl[MAXNC]; static int nncl;
static u32 heap_lo;

/* ---- selectors: canonical guest address per name */
#define SH 2048
static const char *sh_name[SH]; static u32 sh_sel[SH];
static u32 strhash(const char *s) { u32 h = 5381; while (*s) h = h * 33 + (u8)*s++; return h; }
static u32 sel_lookup(const char *s, u32 candidate) {
    u32 h = strhash(s) & (SH - 1);
    while (sh_name[h]) { if (!strcmp(sh_name[h], s)) return sh_sel[h]; h = (h + 1) & (SH - 1); }
    if (!candidate) candidate = gstrdup(s);
    sh_name[h] = GSTR(candidate); sh_sel[h] = candidate;
    return candidate;
}
u32 sel_named(const char *s) { return sel_lookup(s, 0); }
const char *sel_name(u32 sel) { return sel ? GSTR(sel) : "(null)"; }

/* ---- method cache */
#define MC 4096
typedef struct { u32 cls, sel, imp; nmeth nat; } mce;
static mce mc[MC];
static inline u32 mc_hash(u32 c, u32 s) { return ((c >> 2) * 31 + (s >> 2) * 2654435761u) & (MC - 1); }

static void lookup(u32 cls, u32 sel, u32 *imp, nmeth *nat) {
    u32 h = mc_hash(cls, sel);
    for (int i = 0; i < 8; i++) {
        mce *e = &mc[(h + i) & (MC - 1)];
        if (e->cls == cls && e->sel == sel) { *imp = e->imp; *nat = e->nat; return; }
        if (!e->cls) break;
    }
    *imp = 0; *nat = 0;
    for (u32 c = cls; c; c = RD32(c + 4)) {
        u32 tag = RD32(c + 8);
        if ((tag & 0xffff0000u) == NTAG) {
            nclass *n = ncl[tag & 0xfff];
            nmdef *m = (tag & NMETA) ? n->cm : n->im;
            for (; m && m->name; m++) if (m->sel == sel) { *nat = m->fn; goto found; }
        } else {
            u32 ro = RD32(c + 16) & ~3u, ml = ro ? RD32(ro + 20) : 0;
            if (ml) {
                u32 es = RD32(ml) & ~3u, n = RD32(ml + 4);
                for (u32 i = 0; i < n; i++) if (RD32(ml + 8 + i * es) == sel) { *imp = RD32(ml + 8 + i * es + 8); goto found; }
            }
        }
    }
    return;
found:
    for (int i = 0; i < 8; i++) {
        mce *e = &mc[(h + i) & (MC - 1)];
        if (!e->cls || i == 7) { e->cls = cls; e->sel = sel; e->imp = *imp; e->nat = *nat; break; }
    }
}

const char *objc_class_name(u32 cls) {
    if (!cls) return "nil";
    u32 tag = RD32(cls + 8);
    if ((tag & 0xffff0000u) == NTAG) return ncl[tag & 0xfff]->name;
    u32 ro = RD32(cls + 16) & ~3u;
    return ro ? GSTR(RD32(ro + 16)) : "?";
}
u32 objc_isa(u32 o) { return o ? RD32(o) : 0; }
static int is_meta(u32 cls) {
    u32 tag = RD32(cls + 8);
    if ((tag & 0xffff0000u) == NTAG) return (tag & NMETA) != 0;
    return RD32(RD32(cls + 16) & ~3u) & 1;   /* RO_META */
}

static u64 dispatch(u32 cls, u32 recv, u32 sel, u32 r2, u32 r3, u32 sp, int stret, u32 r0) {
    u32 imp; nmeth nat;
    lookup(cls, sel, &imp, &nat);
    if (rt_verbose > 1) rt_log("[objc] %c[%s %s]", is_meta(cls) ? '+' : '-', objc_class_name(cls), sel_name(sel));
    if (stret) {
        if (imp) return rc_call(imp, r0, recv, sel, r2, sp);
        if (nat) return nat(r0, recv, sel, r2, sp);   /* stret natives get (ret, self, sel, arg0) */
    } else {
        if (imp) return rc_call(imp, recv, sel, r2, r3, sp);
        if (nat) return nat(recv, sel, r2, r3, sp);
    }
    rt_log("[objc] unrecognized selector %c[%s %s]", is_meta(cls) ? '+' : '-', objc_class_name(cls), sel_name(sel));
    return 0;
}
/* g_sp: lowest guest stack pointer known to be in use; host-initiated sends (dealloc on release, ...) run below it */
static u32 g_sp;
#define SP_HINT(s) (g_sp = (s))
static inline u32 host_sp(void) { return g_sp ? g_sp - 128 : rt_cb_sp; }
void objc_set_sp(u32 sp) { g_sp = sp; }
IMPORT(objc_msgSend) { if (!r0) RET(0); SP_HINT(sp); return dispatch(RD32(r0), r0, r1, r2, r3, sp, 0, 0); }
IMPORT(objc_msgSend_stret) { if (!r1) RET(0); SP_HINT(sp); return dispatch(RD32(r1), r1, r2, r3, SARG(0), sp, 1, r0); }
IMPORT(objc_msgSendSuper2) {
    u32 recv = RD32(r0), cls = RD32(r0 + 4);
    SP_HINT(sp);
    return dispatch(RD32(cls + 4), recv, r1, r2, r3, sp, 0, 0);
}
u64 objc_send(u32 sp, u32 obj, u32 sel, u32 a2, u32 a3) { if (!obj) return 0; SP_HINT(sp); return dispatch(RD32(obj), obj, sel, a2, a3, sp, 0, 0); }
u64 objc_send_s(u32 obj, const char *sel, u32 a2, u32 a3) { return objc_send(host_sp(), obj, sel_named(sel), a2, a3); }
int objc_responds(u32 obj, u32 sel) { u32 imp; nmeth nat; if (!obj) return 0; lookup(RD32(obj), sel, &imp, &nat); return imp || nat; }
IMPORT(objc_getProperty) { RET(RD32(r0 + r2)); }
IMPORT(objc_setProperty) {   /* (self, _cmd, offset, value, atomic, shouldCopy) */
    SP_HINT(sp);
    u32 old = RD32(r0 + r2);
    if (old != r3) { objc_retain(r3); WR32(r0 + r2, r3); objc_release(old); }
    RET(0);
}
IMPORT(objc_enumerationMutation) { rt_log("[objc] collection mutated during enumeration"); RET(0); }

/* ---- objects: retain count word lives just before isa for heap objects */
u32 objc_new(u32 cls) {
    u32 size = 0;
    for (u32 c = cls; c; c = RD32(c + 4)) {     /* classes without ivars report 0: use the largest in the chain */
        u32 tag = RD32(c + 8), sz;
        if ((tag & 0xffff0000u) == NTAG) sz = ncl[tag & 0xfff]->isize;
        else sz = RD32((RD32(c + 16) & ~3u) + 8);
        if (sz > size) size = sz;
    }
    if (size < 4) size = 4;
    u32 p = gcalloc(size + 4);
    if (!p) rt_fatal("out of guest memory allocating %s", objc_class_name(cls));
    WR32(p, 1); WR32(p + 4, cls);
    return p + 4;
}
u32 objc_new_named(const char *name) { return objc_new(objc_class_named(name)); }
static int refcounted(u32 o) { return o >= heap_lo && o < MEM_SIZE && RD32(o - 4) != 0x7fffffffu; }
u32 objc_retain(u32 o) { if (o && refcounted(o)) WR32(o - 4, RD32(o - 4) + 1); return o; }
void objc_release(u32 o) {
    if (!o || !refcounted(o)) return;
    u32 rc = RD32(o - 4);
    if (rc > 1) { WR32(o - 4, rc - 1); return; }
    WR32(o - 4, 0x7fffffffu);     /* immortal while dealloc runs */
    u32 saved = g_sp;
    objc_send(host_sp(), o, sel_named("dealloc"), 0, 0);
    g_sp = saved;
}
void objc_dealloc_raw(u32 o) { if (o >= heap_lo && o < MEM_SIZE) gfree(o - 4); }
#define POOLMAX 8192
static u32 pool[POOLMAX]; static int npool;
u32 objc_autorelease(u32 o) {
    if (!o) return 0;
    if (npool < POOLMAX) pool[npool++] = o; else rt_log("[objc] autorelease pool overflow");
    return o;
}
void objc_drain_pool(void) { while (npool) objc_release(pool[--npool]); }
int objc_is_kind(u32 o, u32 cls) { for (u32 c = o ? RD32(o) : 0; c; c = RD32(c + 4)) if (c == cls) return 1; return 0; }

/* ---- native classes */
void objc_add_classes(nclass *list) { for (; list->name; list++) if (nncl < MAXNC) { list->idx = nncl; ncl[nncl++] = list; } }
static u32 game_classes[64]; static int ngame;
u32 objc_class_named(const char *name) {
    for (int i = 0; i < nncl; i++) if (!strcmp(ncl[i]->name, name)) return ncl[i]->cls;
    for (int i = 0; i < ngame; i++) if (!strcmp(objc_class_name(game_classes[i]), name)) return game_classes[i];
    return 0;
}
static nclass *ncl_named(const char *name) { for (int i = 0; i < nncl; i++) if (!strcmp(ncl[i]->name, name)) return ncl[i]; return 0; }
static u32 make_class(const char *name, u32 tag, u32 isize, int meta) {
    u32 c = gcalloc(20 + 40);
    u32 ro = c + 20;
    WR32(ro, meta ? 1 : 0); WR32(ro + 8, isize); WR32(ro + 16, gstrdup(name));
    WR32(c + 8, tag); WR32(c + 16, ro);
    return c;
}
void foundation_classes(void); void uikit_classes(void);
void objc_init(void) {
    char nm[96];
    foundation_classes();
    uikit_classes();
    for (int i = 0; i < nncl; i++) {
        nclass *n = ncl[i];
        n->cls = make_class(n->name, NTAG | i, n->isize, 0);
        n->meta = make_class(n->name, NTAG | NMETA | i, 0, 1);
        for (nmdef *m = n->im; m && m->name; m++) m->sel = sel_named(m->name);
        for (nmdef *m = n->cm; m && m->name; m++) m->sel = sel_named(m->name);
    }
    nclass *root = ncl_named("NSObject");
    for (int i = 0; i < nncl; i++) {
        nclass *n = ncl[i], *s = n->super ? ncl_named(n->super) : 0;
        if (n->super && !s) rt_fatal("native class %s: unknown superclass %s", n->name, n->super);
        WR32(n->cls, n->meta); WR32(n->cls + 4, s ? s->cls : 0);
        WR32(n->meta, root->meta); WR32(n->meta + 4, s ? s->meta : root->cls);
        snprintf(nm, sizeof nm, "_OBJC_CLASS_$_%s", n->name); rt_register_data(strdup(nm), n->cls);
        snprintf(nm, sizeof nm, "_OBJC_METACLASS_$_%s", n->name); rt_register_data(strdup(nm), n->meta);
    }
    u32 empty = gcalloc(16);
    rt_register_data("__objc_empty_cache", 0);
    rt_register_data("__objc_empty_vtable", empty);
    rt_register_data("___CFConstantStringClassReference", ncl_named("NSString")->cls);
    extern void uikit_constants(void);
    uikit_constants();
}
static void fix_methods(u32 cls) {
    u32 ro = RD32(cls + 16) & ~3u, ml = ro ? RD32(ro + 20) : 0;
    if (!ml) return;
    u32 es = RD32(ml) & ~3u, n = RD32(ml + 4);
    for (u32 i = 0; i < n; i++) { u32 e = ml + 8 + i * es; WR32(e, sel_lookup(GSTR(RD32(e)), RD32(e))); }
}
void objc_bind_classes(void) {
    heap_lo = 0xe7000;
    const rc_seg_entry *d = &rc_segs[1];
    (void)d;
    /* canonical selectors: selrefs first, then method lists */
    for (u32 i = 0; i < rc_ndatasyms; i++) (void)0;
    extern const u32 rc_selrefs[], rc_nselrefs, rc_classlist[], rc_nclasslist;
    for (u32 i = 0; i < rc_nselrefs; i++) { u32 a = rc_selrefs[i]; WR32(a, sel_lookup(GSTR(RD32(a)), RD32(a))); }
    for (u32 i = 0; i < rc_nclasslist; i++) {
        u32 c = RD32(rc_classlist[i]);
        if (ngame < 64) game_classes[ngame++] = c;
        fix_methods(c); fix_methods(RD32(c));
    }
    for (int i = 0; i < nncl; i++) {
        for (nmdef *m = ncl[i]->im; m && m->name; m++) m->sel = sel_named(m->name);
        for (nmdef *m = ncl[i]->cm; m && m->name; m++) m->sel = sel_named(m->name);
    }
    memset(mc, 0, sizeof mc);
}
