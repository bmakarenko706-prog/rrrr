/* A bounded, startup-only cache for repeated bundle metadata lookups.
   Internal writes invalidate entries. External changes are picked up after
   the first video or on restart. Never caches saves, fonts, or translations. */
#include "rt.h"
#include "bundle_stat.h"
#include <string.h>
#include <errno.h>
#ifdef STARTUP_PROFILE
#include "startup_profile.h"
#endif
#define MAX_STAT_CACHE 256
#define MAX_NAME 96
typedef struct {char name[MAX_NAME];struct stat st;int error;int used;} Entry;
static Entry entries[MAX_STAT_CACHE];static int enabled=1;
static const char *eligible(const char *path) {
 size_t n=strlen(rt_bundle_dir);
 if(strncmp(path,rt_bundle_dir,n) || path[n]!='/')return NULL;
 const char *s=path+n+1;size_t len=strlen(s);
 if(!len || len>=MAX_NAME || strchr(s,'/') || strchr(s,'\\') ||
    !strcmp(s,".") || !strcmp(s,"..") || !strcmp(s,"Res4") ||
    !strcmp(s,"startup_cache.bin") || (len>=4 && !strcmp(s+len-4,".fnt")))return NULL;
 return s;
}
int bundle_stat(const char *path, struct stat *st) {
 const char *name=enabled?eligible(path):NULL; int free_slot=-1;
 if(name) for(int i=0;i<MAX_STAT_CACHE;i++) {
  if(entries[i].used && !strcmp(name,entries[i].name)) {
   if(entries[i].error){errno=entries[i].error;return -1;}
   *st=entries[i].st;return 0;
  }
  if(!entries[i].used && free_slot<0)free_slot=i;
 }
 int r=stat(path,st);int err=errno;
 if(name && free_slot>=0 && (!r || err==ENOENT)) {
  Entry *e=&entries[free_slot];strcpy(e->name,name);e->used=1;e->error=r?err:0;if(!r)e->st=*st;
 }
 errno=err;return r;
}
void bundle_stat_invalidate(const char *path) {
 const char *name=eligible(path);if(!name)return;
 for(int i=0;i<MAX_STAT_CACHE;i++)if(entries[i].used && !strcmp(name,entries[i].name))entries[i].used=0;
}
void bundle_stat_stop(void){enabled=0;}
