/* PSP build: settings and overlay state shared by platform_psp.c and gl_gu.c */
#ifndef PSP_GLUE_H
#define PSP_GLUE_H
extern int psp_stretch;          /* 1: stretch the 480x320 game picture to 480x272, 0: keep aspect (408x272) */
extern int psp_tex_limit;        /* largest paletted (world) texture side kept: 512, or 256 on 32 MB models */
extern int psp_vsync;            /* wait for vertical blank before showing a frame */
extern int psp_language_menu_on, psp_language_save_failed;
extern int psp_cursor_on;        /* draw the pointer (cursor mode) */
extern float psp_cursor_x, psp_cursor_y;   /* pointer in landscape game coordinates (480x320) */
void psp_ui_tick_begin(void);
void psp_ui_tick_note(unsigned int target);
void psp_ui_tick_end(void);
void gl_psp_init(void);
void gl_psp_shutdown(void);
/* game area on the PSP screen (pixels), derived from psp_stretch */
void gl_psp_area(int *x, int *w);
#endif
