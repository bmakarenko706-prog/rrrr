/* libSystem / libgcc imports. Guest strings and buffers live in MEM. */
#include "rt.h"
#include "funcs.h"
#include <string.h>
#include <ctype.h>

const char *objc_nsstring_cstr(u32 obj);   /* hle_objc.c */

void libc_init(void) {}

IMPORT(malloc) { RET(gmalloc(r0)); }
IMPORT(free) { gfree(r0); RET(0); }
IMPORT(realloc) { RET(grealloc(r0, r1)); }
IMPORT(memcpy) { if (r2) memmove(MEM + r0, MEM + r1, r2); RET(r0); }
IMPORT(memmove) { if (r2) memmove(MEM + r0, MEM + r1, r2); RET(r0); }
IMPORT(memset) { if (r2) memset(MEM + r0, (int)r1, r2); RET(r0); }
IMPORT(strlen) { RET(strlen(GSTR(r0))); }
IMPORT(strcmp) { RET((u32)strcmp(GSTR(r0), GSTR(r1))); }
IMPORT(strncmp) { RET((u32)strncmp(GSTR(r0), GSTR(r1), r2)); }
IMPORT(strcpy) { strcpy(GSTR(r0), GSTR(r1)); RET(r0); }
IMPORT(atoi) { RET((u32)atoi(GSTR(r0))); }
IMPORT(wcslen) { u32 n = 0; while (RD32(r0 + 4 * n)) n++; RET(n); }
IMPORT(exit) { rt_log("[libc] exit(%d)", (int)r0); exit((int)r0); }
IMPORT(__assert_rtn) {
    rt_log("[libc] assertion failed: %s (%s:%d in %s)", r3 ? GSTR(r3) : "?", r1 ? GSTR(r1) : "?", (int)r2,
           r0 ? GSTR(r0) : "?");
    RET(0);
}
IMPORT(__cxa_atexit) { RET(0); }

/* libgcc integer division helpers (ARMv6 has no divide instruction) */
IMPORT(__divsi3) { if (!r1) RET(0); if ((s32)r0 == (s32)0x80000000 && (s32)r1 == -1) RET(r0); RET((u32)((s32)r0 / (s32)r1)); }
IMPORT(__modsi3) { if (!r1) RET(0); if ((s32)r1 == -1) RET(0); RET((u32)((s32)r0 % (s32)r1)); }
IMPORT(__udivsi3) { RET(r1 ? r0 / r1 : 0); }
IMPORT(__umodsi3) { RET(r1 ? r0 % r1 : 0); }
IMPORT(_Unwind_SjLj_Register) { RET(0); }
IMPORT(_Unwind_SjLj_Unregister) { RET(0); }
IMPORT(_Unwind_SjLj_Resume) { rt_fatal("C++ exception unwinding is not supported (_Unwind_SjLj_Resume)"); }

/* ---- printf family. iOS ARMv6 varargs: r0-r3 then stack, 64-bit values only 4-byte aligned. */
typedef struct { u32 r[4]; int ri; u32 sp; } gva;
static u32 va32(gva *v) { if (v->ri < 4) return v->r[v->ri++]; u32 x = RD32(v->sp); v->sp += 4; return x; }
static u64 va64(gva *v) { u32 lo = va32(v); u32 hi = va32(v); return lo | ((u64)hi << 32); }

static int gfmt(char *out, int cap, const char *f, gva *v) {
    int n = 0;
#define PUT(s, len) do { int _l = (len); if (n + _l >= cap) _l = cap - 1 - n; if (_l > 0) { memcpy(out + n, (s), _l); n += _l; } } while (0)
    while (*f) {
        if (*f != '%') { const char *e = strchr(f, '%'); int l = e ? (int)(e - f) : (int)strlen(f); PUT(f, l); f += l; continue; }
        char spec[32]; int sl = 0; spec[sl++] = *f++;
        while (*f && strchr("-+ #0", *f) && sl < 20) spec[sl++] = *f++;
        if (*f == '*') { sl += snprintf(spec + sl, 12, "%d", (int)va32(v)); f++; } else while (isdigit((u8)*f) && sl < 24) spec[sl++] = *f++;
        if (*f == '.') { spec[sl++] = *f++; if (*f == '*') { sl += snprintf(spec + sl, 12, "%d", (int)va32(v)); f++; } else while (isdigit((u8)*f) && sl < 28) spec[sl++] = *f++; }
        int lng = 0;   /* 0 int, 1 long, 2 long long, -1 short, -2 char */
        for (;;) {
            if (*f == 'l') { lng++; f++; } else if (*f == 'q' || *f == 'j') { lng = 2; f++; }
            else if (*f == 'h') { lng--; f++; } else if (*f == 'z' || *f == 't' || *f == 'L') { f++; } else break;
        }
        char c = *f ? *f++ : 0; char buf[512]; int bl = 0;
        spec[sl] = 0;
        switch (c) {
        case 'd': case 'i': case 'u': case 'x': case 'X': case 'o': case 'c': {
            char s2[40]; snprintf(s2, sizeof s2, "%s%s%c", spec, lng >= 2 ? "ll" : "", c);
            if (lng >= 2) bl = snprintf(buf, sizeof buf, s2, (long long)va64(v));
            else { u32 x = va32(v); if (lng == -1) x = (c == 'd' || c == 'i') ? (u32)(s32)(s16)x : (u16)x;
                   if (lng <= -2) x = (c == 'd' || c == 'i') ? (u32)(s32)(s8)x : (u8)x;
                   bl = snprintf(buf, sizeof buf, s2, x); }
            break; }
        case 'p': bl = snprintf(buf, sizeof buf, "0x%x", va32(v)); break;
        case 'f': case 'F': case 'e': case 'E': case 'g': case 'G': case 'a': case 'A': {
            char s2[40]; snprintf(s2, sizeof s2, "%s%c", spec, c);
            bl = snprintf(buf, sizeof buf, s2, U2D(va64(v))); break; }
        case 's': { u32 g = va32(v); char s2[40]; snprintf(s2, sizeof s2, "%s%s", spec, "s");
            if (lng >= 1) { char t[256]; int k = 0; if (g) while (k < 255 && RD32(g + 4 * k)) { u32 ch = RD32(g + 4 * k); t[k++] = ch < 128 ? (char)ch : '?'; }
                t[k] = 0; bl = snprintf(buf, sizeof buf, s2, t); }
            else bl = snprintf(buf, sizeof buf, s2, g ? GSTR(g) : "(null)");
            break; }
        case '@': { u32 o = va32(v); const char *s = o ? objc_nsstring_cstr(o) : "(null)"; PUT(s, (int)strlen(s)); break; }
        case '%': buf[0] = '%'; bl = 1; break;
        default: break;
        }
        if (bl > (int)sizeof buf - 1) bl = sizeof buf - 1;
        if (bl > 0) PUT(buf, bl);
    }
    out[n] = 0;
    return n;
#undef PUT
}
int rt_format(char *out, int cap, const char *fmt, u32 r1, u32 r2, u32 r3, u32 sp, int first) {
    gva v = {{0, r1, r2, r3}, first, sp};
    return gfmt(out, cap, fmt, &v);
}
int rt_vformat(char *out, int cap, const char *fmt, u32 va_ptr) {
    gva v = {{0, 0, 0, 0}, 4, va_ptr};
    return gfmt(out, cap, fmt, &v);
}
IMPORT(printf) { char b[2048]; rt_format(b, sizeof b, GSTR(r0), r1, r2, r3, sp, 1); fputs(b, stdout); fflush(stdout); RET(strlen(b)); }
IMPORT(puts) { puts(GSTR(r0)); RET(0); }
IMPORT(sprintf) { char b[4096]; int n = rt_format(b, sizeof b, GSTR(r1), r1, r2, r3, sp, 2); memcpy(MEM + r0, b, n + 1); RET(n); }
IMPORT(vsprintf) { char b[4096]; int n = rt_vformat(b, sizeof b, GSTR(r1), r2); memcpy(MEM + r0, b, n + 1); RET(n); }
