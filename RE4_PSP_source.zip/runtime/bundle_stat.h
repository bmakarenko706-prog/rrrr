#ifndef BUNDLE_STAT_H
#define BUNDLE_STAT_H
#include <sys/stat.h>
/* Memoize bundle metadata only during initial startup, never saves/translations. */
int bundle_stat(const char *path, struct stat *st);
void bundle_stat_invalidate(const char *path);
void bundle_stat_stop(void);
#endif
