#ifndef RE4_PSP_MANUAL_H
#define RE4_PSP_MANUAL_H
#include "recomp.h"
void manual_open(void);
int manual_is_open(void);
void manual_handle(u32 pressed);
void manual_draw(int area_x, int area_w);
#endif
