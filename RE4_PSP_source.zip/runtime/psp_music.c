/* PSP music: AVAudioPlayer streams (the game's MP3s are MPEG-2 layer III, 16 kHz) decoded in software
   with rmp3 (fixed point) and mixed into the 44.1 kHz output by the audio thread. */
#include "rt.h"
#include "platform.h"
#include "third_party/rmp3.h"
#include <pspkernel.h>
#include <pspiofilemgr.h>
#include <string.h>
#include <stdlib.h>

void music_mix(s32 *acc, int n);
void music_init(void);

#define MAXM 16
#define INBUF 6144
typedef struct {
    int playing, loops;                  /* loops: extra plays left, -1 forever */
    int vol;                             /* 0..256 */
    SceUID fd; const u8 *mem; u32 len;   /* source: file (fd >= 0) or memory */
    u32 data_start, pos;
    u8 in[INBUF]; int in_n, in_off, eof;
    rmp3dec dec;
    s16 pcm[RMP3_MAX_SAMPLES_PER_FRAME]; int pcm_n, pcm_i, ch;
    int hz, kbps;
    u32 phase;                           /* 16.16 position between cur and nxt */
    s16 cur[2], nxt[2];
    u64 played;                          /* source frames since the start of the stream */
    double dur;
} music;
static music *M[MAXM];
static SceUID msema = -1;
static void lock(void) { if (msema >= 0) sceKernelWaitSema(msema, 1, 0); }
static void unlock(void) { if (msema >= 0) sceKernelSignalSema(msema, 1); }
/* -1: normal mixing, -2: silent movie, >=0: movie soundtrack only. */
static volatile int movie_exclusive = -1;
int movie_music_active(void) { return movie_exclusive != -1; }
void movie_music_begin(int handle) {
    lock(); movie_exclusive = handle >= 0 ? handle : -2;
    if (handle >= 0 && handle < MAXM && M[handle]) { M[handle]->loops=0; M[handle]->playing=1; }
    unlock();
}
void movie_music_end(int handle) {
    lock(); movie_exclusive = -1;
    if (handle >= 0 && handle < MAXM && M[handle]) M[handle]->playing=0;
    unlock();
    if (handle >= 0) plat_music_close(handle);
}
void music_init(void) { msema = sceKernelCreateSema("re4music", 0, 1, 1, 0); }

static int src_read(music *m, u8 *dst, int n) {
    if (!m->mem) { int r = sceIoRead(m->fd, dst, n); if (r < 0) r = 0; m->pos += r; return r; }
    u32 left = m->len > m->pos ? m->len - m->pos : 0;
    if ((u32)n > left) n = (int)left;
    memcpy(dst, m->mem + m->pos, n); m->pos += n;
    return n;
}
static void src_seek(music *m, u32 off) {
    m->pos = off;
    if (!m->mem) sceIoLseek32(m->fd, off, PSP_SEEK_SET);
    m->in_n = m->in_off = m->eof = 0;
    m->pcm_n = m->pcm_i = 0;
    rmp3dec_init(&m->dec);
}
static int decode_frame(music *m) {
    for (int tries = 0; tries < 64; tries++) {
        if (m->in_n - m->in_off < 2048 && !m->eof) {
            memmove(m->in, m->in + m->in_off, m->in_n - m->in_off);
            m->in_n -= m->in_off; m->in_off = 0;
            int r = src_read(m, m->in + m->in_n, INBUF - m->in_n);
            if (r <= 0) m->eof = 1; else m->in_n += r;
        }
        int avail = m->in_n - m->in_off;
        if (avail <= 0) return 0;
        rmp3dec_frame_info fi;
        int s = rmp3dec_decode_s16(&m->dec, m->in + m->in_off, avail, m->pcm, &fi);
        if (!fi.frame_bytes) { if (m->eof) return 0; m->in_off = m->in_n; continue; }
        m->in_off += fi.frame_bytes;
        if (s > 0) { m->pcm_n = s; m->pcm_i = 0; m->ch = fi.channels; m->hz = fi.hz; m->kbps = fi.bitrate_kbps; return 1; }
    }
    return 0;
}
static int next_frame(music *m, s16 *o) {
    if (m->pcm_i >= m->pcm_n && !decode_frame(m)) {
        if (m->loops == 0) return 0;
        if (m->loops > 0) m->loops--;
        src_seek(m, m->data_start); m->played = 0;
        if (!decode_frame(m)) return 0;
    }
    const s16 *p = m->pcm + m->pcm_i * m->ch;
    o[0] = p[0]; o[1] = m->ch > 1 ? p[1] : p[0];
    m->pcm_i++; m->played++;
    return 1;
}
static void rewind_stream(music *m) {
    src_seek(m, m->data_start);
    m->played = 0; m->phase = 0x10000; m->cur[0] = m->cur[1] = m->nxt[0] = m->nxt[1] = 0;
}

void music_mix(s32 *acc, int n) {
    lock();
    for (int h = 0; h < MAXM; h++) {
        music *m = M[h];
        if (!m || !m->playing || (movie_exclusive != -1 && h != movie_exclusive)) continue;
        u32 step = (u32)(((u64)(m->hz > 0 ? m->hz : 44100) << 16) / 44100);
        int vol = m->vol;
        for (int i = 0; i < n; i++) {
            while (m->phase >= 0x10000) {
                m->phase -= 0x10000;
                m->cur[0] = m->nxt[0]; m->cur[1] = m->nxt[1];
                if (!next_frame(m, m->nxt)) { m->playing = 0; break; }
            }
            if (!m->playing) break;
            s32 f = (s32)(m->phase >> 1);
            s32 l = m->cur[0] + (((m->nxt[0] - m->cur[0]) * f) >> 15);
            s32 r = m->cur[1] + (((m->nxt[1] - m->cur[1]) * f) >> 15);
            acc[2 * i] += (l * vol) >> 8; acc[2 * i + 1] += (r * vol) >> 8;
            m->phase += step;
        }
        if (!m->playing) rewind_stream(m);
    }
    unlock();
}

static void free_music(music *m) { if (m->fd >= 0) sceIoClose(m->fd); free(m); }
/* Call only after the audio thread has stopped and the guest is no longer using music. */
void music_shutdown(void) {
    for (int i = 0; i < MAXM; i++) { if (M[i]) { free_music(M[i]); M[i] = NULL; } }
    if (msema >= 0) { sceKernelDeleteSema(msema); msema = -1; }
}
int plat_music_open(const char *path, const void *data, u32 len) {
    int h;
    for (h = 0; h < MAXM && M[h]; h++) ;
    if (h == MAXM) { rt_log("[music] too many players"); return -1; }
    music *m = calloc(1, sizeof *m);
    if (!m) { rt_log("[music] out of memory"); return -1; }
    m->fd = -1; m->vol = 256;
    if (path) {
        m->fd = sceIoOpen(path, PSP_O_RDONLY, 0);
        if (m->fd < 0) { rt_log("[music] cannot open %s", path); free(m); return -1; }
        m->len = (u32)sceIoLseek32(m->fd, 0, PSP_SEEK_END);
        sceIoLseek32(m->fd, 0, PSP_SEEK_SET);
    } else { m->mem = data; m->len = len; }
    u8 hd[10] = {0};
    src_read(m, hd, 10);
    if (hd[0] == 'I' && hd[1] == 'D' && hd[2] == '3')
        m->data_start = 10 + ((hd[6] & 0x7f) << 21 | (hd[7] & 0x7f) << 14 | (hd[8] & 0x7f) << 7 | (hd[9] & 0x7f)) + (hd[5] & 0x10 ? 10 : 0);
    src_seek(m, m->data_start);
    if (!decode_frame(m)) { rt_log("[music] %s: no MP3 frames", path ? path : "(memory)"); free_music(m); return -1; }
    m->dur = m->kbps > 0 ? (m->len - m->data_start) * 8.0 / (m->kbps * 1000.0) : 0;
    rewind_stream(m);
    lock(); M[h] = m; unlock();
    if (rt_verbose) rt_log("[music] open %s: %d Hz, %d kbit/s, %.1f s", path ? path : "(memory)", m->hz, m->kbps, m->dur);
    return h;
}
static music *get(int h) { return h >= 0 && h < MAXM ? M[h] : 0; }
void plat_music_close(int h) {
    music *m = get(h); if (!m) return;
    lock(); M[h] = 0; unlock();
    free_music(m);
}
void plat_music_play(int h, int loops) { music *m = get(h); if (!m) return; lock(); m->loops = loops; m->playing = 1; unlock(); }
void plat_music_stop(int h) { music *m = get(h); if (!m) return; lock(); m->playing = 0; rewind_stream(m); unlock(); }
void plat_music_pause(int h) { music *m = get(h); if (!m) return; lock(); m->playing = 0; unlock(); }
void plat_music_volume(int h, float v) { music *m = get(h); if (m) m->vol = v <= 0 ? 0 : v >= 1 ? 256 : (int)(v * 256); }
int plat_music_playing(int h) { music *m = get(h); return m && m->playing; }
double plat_music_time(int h) { music *m = get(h); return m && m->hz > 0 ? (double)m->played / m->hz : 0; }
void plat_music_seek(int h, double t) {
    music *m = get(h); if (!m) return;
    lock();
    rewind_stream(m);
    if (t > 0 && m->kbps > 0) {
        u32 off = m->data_start + (u32)(t * m->kbps * 125.0);
        if (off < m->len) { src_seek(m, off); m->played = (u64)(t * m->hz); }
    }
    unlock();
}
double plat_music_duration(int h) { music *m = get(h); return m ? m->dur : 0; }
