/* Optional startup screen. Does not touch game assets or guest state. */
#include "rt.h"
#include "intro.h"
#include "intro_codec.h"
#include <pspgu.h>
#include <pspdisplay.h>
#include <pspkernel.h>
#include <malloc.h>
#include <stdio.h>
#include <string.h>
#define STRIDE 512
#define TEX_H 512
static unsigned int dl[4096] __attribute__((aligned(64)));
typedef struct { float u,v; u32 color; s16 x,y,z,pad; } vertex;
void intro_show(const char *bundle_dir,const volatile int *quit_req) {
    char path[512];snprintf(path,sizeof path,"%s/mis_data_m25.bin",bundle_dir);
    FILE *f=fopen(path,"rb");if(!f){rt_log("[intro] asset missing; skipped");return;}
    u8 nonce[8];u8 *buf=memalign(64,STRIDE*TEX_H*2u);
    if(!buf){fclose(f);rt_log("[intro] not enough memory; skipped");return;}
    size_t nh=fread(nonce,1,8,f),nr=fread(buf,1,INTRO_DATA_BYTES,f);int extra=fgetc(f);fclose(f);
    if(nh!=8 || nr!=INTRO_DATA_BYTES || extra!=EOF || !intro_decode(buf,nr,nonce)) {
        rt_log("[intro] invalid asset; skipped");free(buf);return;
    }
    /* Expand packed rows backwards into a 512-wide GE texture. */
    for(int y=INTRO_H-1;y>=0;y--){memmove(buf+y*STRIDE*2,buf+4+y*INTRO_W*2,INTRO_W*2);memset(buf+y*STRIDE*2+INTRO_W*2,0,(STRIDE-INTRO_W)*2);}
    memset(buf+INTRO_H*STRIDE*2,0,(TEX_H-INTRO_H)*STRIDE*2);
    sceKernelDcacheWritebackRange(buf,STRIDE*TEX_H*2);
    sceKernelDcacheWritebackInvalidateRange(dl,sizeof dl);
    sceGuInit();sceGuStart(GU_DIRECT,dl);
    sceGuDrawBuffer(GU_PSM_5650,(void*)0x00000,STRIDE);
    sceGuDispBuffer(480,272,(void*)0x44000,STRIDE);
    sceGuOffset(2048-240,2048-136);sceGuViewport(2048,2048,480,272);
    sceGuEnable(GU_SCISSOR_TEST);sceGuScissor(0,0,480,272);
    sceGuClearColor(0xff000000);sceGuClear(GU_COLOR_BUFFER_BIT);
    sceGuFinish();sceGuSync(0,0);sceDisplayWaitVblankStart();sceGuDisplay(GU_TRUE);
    u64 start=sceKernelGetSystemTimeWide();
    for(;;){
        u64 elapsed=sceKernelGetSystemTimeWide()-start;
        if((quit_req && *quit_req) || elapsed>=2800000u)break;
        unsigned level=elapsed<800000u ? (unsigned)(elapsed*255u/800000u) :
                       elapsed<2000000u ? 255u : (unsigned)((2800000u-elapsed)*255u/800000u);
        u32 color=0xff000000u | level | level<<8 | level<<16;
        sceGuStart(GU_DIRECT,dl);
        sceGuDisable(GU_DEPTH_TEST);sceGuDisable(GU_ALPHA_TEST);sceGuDisable(GU_BLEND);
        sceGuDisable(GU_FOG);sceGuDisable(GU_LIGHTING);sceGuDisable(GU_CULL_FACE);
        sceGuEnable(GU_TEXTURE_2D);sceGuEnable(GU_SCISSOR_TEST);sceGuScissor(0,0,480,272);
        sceGuClearColor(0xff000000);sceGuClear(GU_COLOR_BUFFER_BIT);
        sceGuTexMode(GU_PSM_5650,0,0,0);sceGuTexImage(0,STRIDE,TEX_H,STRIDE,buf);
        sceGuTexFunc(GU_TFX_MODULATE,GU_TCC_RGB);sceGuTexFilter(GU_LINEAR,GU_LINEAR);
        sceGuTexWrap(GU_CLAMP,GU_CLAMP);sceGuTexScale(1,1);sceGuTexOffset(0,0);
        sceGuTexMapMode(GU_TEXTURE_COORDS,0,0);sceGuTexFlush();
        vertex *v=sceGuGetMemory(2*sizeof *v);
        v[0]=(vertex){0,0,color,0,0,0,0};v[1]=(vertex){480,272,color,480,272,0,0};
        sceGuDrawArray(GU_SPRITES,GU_TEXTURE_32BITF|GU_COLOR_8888|GU_VERTEX_16BIT|GU_TRANSFORM_2D,2,0,v);
        sceGuFinish();sceGuSync(0,0);sceDisplayWaitVblankStart();sceGuSwapBuffers();
    }
    /* Present black before the main renderer is initialized. */
    sceGuStart(GU_DIRECT,dl);sceGuClearColor(0xff000000);sceGuClear(GU_COLOR_BUFFER_BIT);
    sceGuFinish();sceGuSync(0,0);sceDisplayWaitVblankStart();sceGuSwapBuffers();
    sceGuTerm();free(buf);
}
