#ifdef RE4_PSP
#include "psp_glue.h"
#include "startup_pack.h"
#include "bundle_stat.h"
#endif
/* Foundation part 2: bundle & files, dates, timers, notifications, locale, URLs, NSLog */
#include "objc.h"
#include "language.h"
#include "funcs.h"
#include <string.h>
#include <sys/stat.h>
#ifndef RE4_PSP
#define bundle_stat stat
#endif
#ifdef STARTUP_PROFILE
#include "startup_profile.h"
#endif

char rt_bundle_dir[256] = ".";
char rt_docs_dir[256] = "./Documents";
char rt_home_dir[256] = ".";
int rt_format(char *out, int cap, const char *fmt, u32 r1, u32 r2, u32 r3, u32 sp, int first);
u32 nsdict_make(int n, const u32 *keys, const u32 *vals);

static u32 singleton(const char *cls, u32 *slot) {
    if (!*slot) { *slot = objc_new_named(cls); WR32(*slot - 4, 0x7fffffffu); }
    return *slot;
}
NM(o_self2) { UNUSED_ARGS; RET(self); }
NM(o_nop2) { UNUSED_ARGS; RET(0); }

/* ---------- NSBundle */
static u32 g_bundle, g_info;
NM(b_main) { UNUSED_ARGS; RET(singleton("NSBundle", &g_bundle)); }
NM(b_path) { UNUSED_ARGS;
    const char *n = objc_nsstring_cstr(a2), *t = a3 ? objc_nsstring_cstr(a3) : "";
    char p[512]; snprintf(p, sizeof p, "%s/%s%s%s", rt_bundle_dir, n, *t ? "." : "", t);
#ifdef STARTUP_PROFILE
    if (!strncmp(n, "2d_logo", 7)) startup_profile_begin();
#endif
    if (language_use_russian_font() && !strcmp(n, "eu_font_U16le") && !strcmp(t, "fnt")) {
        char candidate[512]; snprintf(candidate, sizeof candidate, "%s/ru_font_U16le.fnt", rt_home_dir);
        FILE *ru = fopen(candidate, "rb");
        if (ru) { fclose(ru); snprintf(p, sizeof p, "%s", candidate); rt_log("[ru] using Russian font %s", p); }
    }
    if (strstr(n, "font_U16le")) rt_log("[font] bundle name=%s type=%s path=%s preload_original=%d",n,t,p,!language_use_russian_font());
#ifdef RE4_PSP
    /* This is an existence lookup, not a read. Avoid opening and closing the
       same asset again before NSFileHandle opens it for the actual load. */
    struct stat st;
    if (bundle_stat(p, &st) != 0 || !S_ISREG(st.st_mode)) { if (rt_verbose) rt_log("[fs] pathForResource: %s not found", p); RET(0); }
#else
    FILE *f = fopen(p, "rb");
    if (!f) { if (rt_verbose) rt_log("[fs] pathForResource: %s not found", p); RET(0); }
    fclose(f);
#endif
    RET(nsstr(p)); }
NM(b_bundlepath) { UNUSED_ARGS; RET(nsstr(rt_bundle_dir)); }
NM(b_info) { UNUSED_ARGS;
    if (!g_info) { u32 k = nsstr_owned("CFBundleVersion"), v = nsstr_owned("1.00.00"); g_info = nsdict_make(1, &k, &v); WR32(g_info - 4, 0x7fffffffu); }
    RET(g_info); }
static nmdef bundle_im[] = {{"pathForResource:ofType:", b_path}, {"bundlePath", b_bundlepath}, {"resourcePath", b_bundlepath},
    {"infoDictionary", b_info}, {0}};
static nmdef bundle_cm[] = {{"mainBundle", b_main}, {0}};

#ifdef RE4_PSP
/* Only the immutable bundle index is cached; saves and all other files keep
   normal I/O. The cache lives in the guest heap, not the smaller PSP heap. */
static u32 common_cache, common_cache_size;
static int common_cache_attempted, common_cache_valid;
static int common_path(const char *path) {
    char expected[512]; snprintf(expected, sizeof expected, "%s/common.h2z", rt_bundle_dir);
    return strcmp(path, expected) == 0;
}
static void common_invalidate(const char *path) {
    if (common_path(path)) { common_cache_valid = 0; common_cache_attempted = 1; }
}
void re4_file_cache_invalidate(const char *path) {
    common_invalidate(path); startup_pack_invalidate(path); bundle_stat_invalidate(path);
}
#endif

/* ---------- NSFileManager */
static u32 g_fm;
NM(fm_default) { UNUSED_ARGS; RET(singleton("NSFileManager", &g_fm)); }
NM(fm_exists) { UNUSED_ARGS; struct stat st; int ok = bundle_stat(objc_nsstring_cstr(a2), &st) == 0;
    if (rt_verbose > 2) rt_log("[fs] exists %s -> %d", objc_nsstring_cstr(a2), ok);
    if (a3) WR8(a3, ok && S_ISDIR(st.st_mode)); RET(ok); }
NM(fm_exists1) { UNUSED_ARGS; struct stat st; if (rt_verbose > 2) rt_log("[fs] exists1 %s", objc_nsstring_cstr(a2)); RET(bundle_stat(objc_nsstring_cstr(a2), &st) == 0); }
NM(fm_create) { UNUSED_ARGS;
#ifdef RE4_PSP
    re4_file_cache_invalidate(objc_nsstring_cstr(a2));
#endif
    FILE *f = fopen(objc_nsstring_cstr(a2), "wb"); if (!f) RET(0);
    if (a3) fwrite(MEM + RD32(a3 + 4), 1, RD32(a3 + 8), f); fclose(f); RET(1); }
NM(fm_remove) { UNUSED_ARGS;
#ifdef RE4_PSP
    re4_file_cache_invalidate(objc_nsstring_cstr(a2));
#endif
    RET(remove(objc_nsstring_cstr(a2)) == 0); }
static nmdef fm_im[] = {{"fileExistsAtPath:isDirectory:", fm_exists}, {"fileExistsAtPath:", fm_exists1},
    {"createFileAtPath:contents:attributes:", fm_create}, {"removeItemAtPath:error:", fm_remove}, {0}};
static nmdef fm_cm[] = {{"defaultManager", fm_default}, {0}};

/* ---------- NSFileHandle: [isa][slot] ; host FILE* table */
static FILE *fh_files[16];
#ifdef RE4_PSP
static unsigned char fh_cached[16];
static u32 fh_cache_pos[16];
static int fh_pack_entry[16];
/* One attempt per launch. On any error, keep the ordinary FILE path. */
static void common_try_cache(FILE *f) {
    common_cache_attempted = 1;
    if (fseek(f, 0, SEEK_END) != 0) { rewind(f); return; }
    long len = ftell(f); rewind(f);
    if (len <= 0 || len > 256 * 1024 || heap_free_bytes() < (u32)len + 2u*1024*1024) return;
    u32 mem = gmalloc((u32)len);
    if (!mem) return;
    if (fread(MEM + mem, 1, (size_t)len, f) != (size_t)len) { gfree(mem); rewind(f); return; }
    common_cache = mem; common_cache_size = (u32)len; common_cache_valid = 1;
    rt_log("[fs] common.h2z cached in guest memory (%u bytes)", common_cache_size);
}
#endif
static u32 fh_open(u32 cls, const char *path, const char *mode) {
    int s = 1;
#ifdef RE4_PSP
    while (s < 16 && (fh_files[s] || fh_cached[s])) s++;
#else
    while (s < 16 && fh_files[s]) s++;
#endif
    if (s == 16) return 0;
    char ru_path[512];
    const char *base = strrchr(path, '/');
    base = base ? base + 1 : path;
    if (language_use_russian_font() && !strcmp(base, "eu_font_U16le.fnt") && !strcmp(mode, "rb")) {
        snprintf(ru_path, sizeof ru_path, "%s/ru_font_U16le.fnt", rt_home_dir);
        FILE *ru = fopen(ru_path, "rb");
        if (ru) { fclose(ru); path = ru_path; rt_log("[ru] using Russian font %s", path); }
    }
    if (strstr(base, "font_U16le")) rt_log("[font] open requested=%s actual=%s preload_original=%d",base,path,!language_use_russian_font());
#ifdef RE4_PSP
    int is_common = common_path(path);
    if (strcmp(mode, "rb")) re4_file_cache_invalidate(path);
    int pack_entry = !is_common && !strcmp(mode, "rb") ? startup_pack_find(path) : -1;
    FILE *f = NULL;
    if (!(is_common && common_cache_valid) && pack_entry < 0) {
        f = fopen(path, mode);
        if (!f) return 0;
        if (is_common && !strcmp(mode, "rb") && !common_cache_attempted) common_try_cache(f);
    }
    if (is_common && common_cache_valid && !strcmp(mode, "rb")) {
        if (f) fclose(f);
        fh_cached[s] = 1; fh_cache_pos[s] = 0;
    } else if (pack_entry >= 0) {
        fh_cached[s] = 2; fh_cache_pos[s] = 0; fh_pack_entry[s] = pack_entry;
    } else fh_files[s] = f;
#else
    FILE *f = fopen(path, mode);
    if (!f) return 0;
    fh_files[s] = f;
#endif
    if (rt_verbose) rt_log("[fs] open %s (%s) slot %d", path, mode, s);
    u32 o = objc_new(cls); WR32(o + 4, s);
    return objc_autorelease(o);
}
NM(fh_read) { UNUSED_ARGS; RET(fh_open(self, objc_nsstring_cstr(a2), "rb")); }
NM(fh_write) { UNUSED_ARGS; RET(fh_open(self, objc_nsstring_cstr(a2), "r+b")); }
static FILE *fh_of(u32 o) { u32 s = RD32(o + 4); return s < 16 ? fh_files[s] : 0; }
NM(fh_readlen) { UNUSED_ARGS;
#ifdef RE4_PSP
    u32 slot = RD32(self + 4);
    if (slot < 16 && fh_cached[slot]) {
        u32 b = gmalloc(a2 ? a2 : 1), pos = fh_cache_pos[slot];
        if (!b) RET(0);
        u32 size = fh_cached[slot] == 1 ? common_cache_size : startup_pack_size(fh_pack_entry[slot]);
        u32 n = pos < size ? size - pos : 0;
        if (n > a2) n = a2;
        if (fh_cached[slot] == 1) {
            if (n) memcpy(MEM + b, MEM + common_cache + pos, n);
        } else if (startup_pack_read(fh_pack_entry[slot], pos, MEM + b, n) < 0) {
            /* I/O error: abandon this packed handle and resume at the same
               position in the untouched original file. */
            const char *path = startup_pack_path(fh_pack_entry[slot]);
            FILE *f = path ? fopen(path, "rb") : NULL;
            if (!f || fseek(f, (long)pos, SEEK_SET)) { if(f) fclose(f); gfree(b); RET(0); }
            fh_cached[slot] = 0; fh_files[slot] = f;
            n = fread(MEM + b, 1, a2, f);
            RET(objc_autorelease(nsdata_new(b, n, 1)));
        }
        fh_cache_pos[slot] = pos + n;
        RET(objc_autorelease(nsdata_new(b, n, 1)));
    }
#endif
    FILE *f = fh_of(self); if (!f) RET(0);
    u32 b = gmalloc(a2 ? a2 : 1); u32 n = fread(MEM + b, 1, a2, f);
    if (rt_verbose && a2 >= 4096) rt_log("[fs] read %u bytes from slot %d -> %x", n, RD32(self + 4), b);
    RET(objc_autorelease(nsdata_new(b, n, 1))); }
NM(fh_writedata) { UNUSED_ARGS; FILE *f = fh_of(self); if (f && a2) fwrite(MEM + RD32(a2 + 4), 1, RD32(a2 + 8), f); RET(0); }
NM(fh_seek) { UNUSED_ARGS;
#ifdef RE4_PSP
    u32 slot = RD32(self + 4);
    if (slot < 16 && fh_cached[slot]) { if (a2 <= 0x7fffffffu) fh_cache_pos[slot] = a2; RET(0); }
#endif
    FILE *f = fh_of(self); if (f) fseek(f, (long)a2, SEEK_SET); RET(0); }
NM(fh_seekend) { UNUSED_ARGS;
#ifdef RE4_PSP
    u32 slot = RD32(self + 4);
    if (slot < 16 && fh_cached[slot]) { u32 size = fh_cached[slot] == 1 ? common_cache_size : startup_pack_size(fh_pack_entry[slot]); fh_cache_pos[slot] = size; return (u64)size; }
#endif
    FILE *f = fh_of(self); if (!f) RET(0); fseek(f, 0, SEEK_END); return (u64)ftell(f); }
NM(fh_offset) { UNUSED_ARGS;
#ifdef RE4_PSP
    u32 slot = RD32(self + 4); if (slot < 16 && fh_cached[slot]) return fh_cache_pos[slot];
#endif
    FILE *f = fh_of(self); return f ? (u64)ftell(f) : 0; }
NM(fh_close) { UNUSED_ARGS;
#ifdef RE4_PSP
    u32 slot = RD32(self + 4);
    if (slot < 16 && fh_cached[slot]) { fh_cached[slot] = 0; fh_cache_pos[slot] = 0; RET(0); }
#endif
    FILE *f = fh_of(self); if (f) { fclose(f); fh_files[RD32(self + 4)] = 0; } RET(0); }
NM(fh_dealloc) { UNUSED_ARGS; fh_close(self, 0, 0, 0, sp); objc_dealloc_raw(self); RET(0); }
static nmdef fh_im[] = {{"readDataOfLength:", fh_readlen}, {"writeData:", fh_writedata}, {"seekToFileOffset:", fh_seek},
    {"seekToEndOfFile", fh_seekend}, {"offsetInFile", fh_offset}, {"closeFile", fh_close}, {"dealloc", fh_dealloc}, {0}};
static nmdef fh_cm[] = {{"fileHandleForReadingAtPath:", fh_read}, {"fileHandleForWritingAtPath:", fh_write},
    {"fileHandleForUpdatingAtPath:", fh_write}, {0}};

/* ---------- NSDate: [isa][seconds as double] */
static double now_s(void) { return plat_time_us() / 1e6; }
NM(date_now) { UNUSED_ARGS; u32 o = objc_new(self); WRD(o + 4, now_s()); RET(objc_autorelease(o)); }
NM(date_since) { UNUSED_ARGS; RETD(RDD(self + 4) - (a2 ? RDD(a2 + 4) : 0)); }
NM(date_sincenow) { UNUSED_ARGS; RETD(RDD(self + 4) - now_s()); }
static nmdef date_im[] = {{"timeIntervalSinceDate:", date_since}, {"timeIntervalSinceNow", date_sincenow}, {0}};
static nmdef date_cm[] = {{"date", date_now}, {0}};

/* ---------- NSTimer: [isa][interval d][target][sel][userinfo][repeats][next d][valid] */
#define MAXT 16
static u32 timers[MAXT];
NM(t_sched) { UNUSED_ARGS;
    u32 t = objc_new(self); double iv = U2D(((u64)a3 << 32) | a2);
    if (iv < 0.001) iv = 0.001;
    /* Force the game timer to 23 Hz on PSP. This does not
       compensate frame-based game logic and may make the game run faster. */
    if (strcmp(sel_name(SARG(1)), "onTick") == 0) {
#ifdef RE4_PSP
        iv = 1.0 / 23.0;
#else
        if (iv > 0.049 && iv < 0.051) iv = 1.0 / rt_target_fps;
#endif
    }
    WRD(t + 4, iv); WR32(t + 12, objc_retain(SARG(0))); WR32(t + 16, SARG(1)); WR32(t + 20, objc_retain(SARG(2)));
    WR32(t + 24, SARG(3) & 0xff); WRD(t + 28, now_s() + iv); WR32(t + 36, 1);
    for (int i = 0; i < MAXT; i++) if (!timers[i]) { timers[i] = objc_retain(t); break; }
    rt_log("[timer] scheduled %s every %.4fs on %s", sel_name(SARG(1)), iv, objc_class_name(objc_isa(SARG(0))));
    RET(objc_autorelease(t)); }
NM(t_invalidate) { UNUSED_ARGS; WR32(self + 36, 0); RET(0); }
NM(t_valid) { UNUSED_ARGS; RET(RD32(self + 36)); }
NM(t_userinfo) { UNUSED_ARGS; RET(RD32(self + 20)); }
static nmdef timer_im[] = {{"invalidate", t_invalidate}, {"isValid", t_valid}, {"userInfo", t_userinfo}, {0}};
static nmdef timer_cm[] = {{"scheduledTimerWithTimeInterval:target:selector:userInfo:repeats:", t_sched}, {0}};
/* fire due timers; returns seconds until the next one */
double timers_run(u32 sp) {
    double now = now_s(), next = 1.0;
    for (int i = 0; i < MAXT; i++) {
        u32 t = timers[i];
        if (!t) continue;
        if (!RD32(t + 36)) { timers[i] = 0; objc_release(t); continue; }
        double due = RDD(t + 28);
        if (now >= due) {
            double iv = RDD(t + 4);
            due += iv; if (due < now) due = now + iv;   /* drop missed ticks */
            WRD(t + 28, due);
#ifdef RE4_PSP
            int is_game_tick = strcmp(sel_name(RD32(t + 16)), "onTick") == 0;
            if (is_game_tick) psp_ui_tick_begin();
#endif
            objc_send(sp, RD32(t + 12), RD32(t + 16), t, 0);
#ifdef RE4_PSP
            if (is_game_tick) psp_ui_tick_end();
#endif
            if (!RD32(t + 24)) WR32(t + 36, 0);
        }
        /* A callback may spend time rendering or waiting for vblank. */
        now = now_s();
    }
    /* Compute sleep from the actual time after all callbacks, not a stale
       timestamp from before presentation. */
    now = now_s();
    for (int i = 0; i < MAXT; i++) {
        u32 t = timers[i];
        if (t && RD32(t + 36) && RDD(t + 28) - now < next)
            next = RDD(t + 28) - now;
    }
    return next;
}

/* ---------- NSNotificationCenter (observers kept in host memory) */
typedef struct { u32 obs, sel, object; char name[96]; } observer;
static observer obsv[32]; static int nobs; static u32 g_nc;
NM(nc_default) { UNUSED_ARGS; RET(singleton("NSNotificationCenter", &g_nc)); }
NM(nc_add) { UNUSED_ARGS; if (nobs < 32) { observer *o = &obsv[nobs++]; o->obs = a2; o->sel = a3; o->object = SARG(1);
    snprintf(o->name, sizeof o->name, "%s", SARG(0) ? objc_nsstring_cstr(SARG(0)) : ""); } RET(0); }
NM(nc_remove) { UNUSED_ARGS; const char *n = a3 ? objc_nsstring_cstr(a3) : 0;
    for (int i = 0; i < nobs; i++) if (obsv[i].obs == a2 && (!n || !strcmp(n, obsv[i].name))) { obsv[i] = obsv[--nobs]; i--; }
    RET(0); }
void post_notification(u32 sp, const char *name, u32 object) {
    u32 note = 0;
    for (int i = 0; i < nobs; i++) if (!obsv[i].name[0] || !strcmp(obsv[i].name, name)) {
        if (!note) { note = objc_new_named("NSNotification"); WR32(note + 4, nsstr_owned(name)); WR32(note + 8, object); objc_autorelease(note); }
        objc_send(sp, obsv[i].obs, obsv[i].sel, note, 0);
    }
}
NM(nc_post) { UNUSED_ARGS; post_notification(sp, objc_nsstring_cstr(a2), a3); RET(0); }
NM(note_name) { UNUSED_ARGS; RET(RD32(self + 4)); }
NM(note_object) { UNUSED_ARGS; RET(RD32(self + 8)); }
static nmdef nc_im[] = {{"addObserver:selector:name:object:", nc_add}, {"removeObserver:name:object:", nc_remove},
    {"removeObserver:", nc_remove}, {"postNotificationName:object:", nc_post}, {0}};
static nmdef nc_cm[] = {{"defaultCenter", nc_default}, {0}};
static nmdef note_im[] = {{"name", note_name}, {"object", note_object}, {0}};

/* ---------- NSLocale, NSURL & networking */
NM(loc_langs) { UNUSED_ARGS; u32 a = nsarray_new(); nsarray_add(a, nsstr("en")); RET(objc_autorelease(a)); }
static nmdef loc_cm[] = {{"preferredLanguages", loc_langs}, {0}};
NM(url_with) { UNUSED_ARGS; u32 u = objc_new(self); WR32(u + 4, objc_retain(a2)); RET(objc_autorelease(u)); }
NM(url_path) { UNUSED_ARGS; RET(RD32(self + 4)); }
static nmdef url_im[] = {{"path", url_path}, {"absoluteString", url_path}, {0}};
static nmdef url_cm[] = {{"URLWithString:", url_with}, {"fileURLWithPath:", url_with}, {0}};
static nmdef req_cm[] = {{"requestWithURL:", url_with}, {0}};
static nmdef conn_cm[] = {{"sendSynchronousRequest:returningResponse:error:", o_nop2}, {0}};

static nclass f2_classes[] = {
    {"NSBundle", "NSObject", bundle_im, bundle_cm, 4},
    {"NSFileManager", "NSObject", fm_im, fm_cm, 4},
    {"NSFileHandle", "NSObject", fh_im, fh_cm, 8},
    {"NSDate", "NSObject", date_im, date_cm, 12},
    {"NSTimer", "NSObject", timer_im, timer_cm, 40},
    {"NSNotificationCenter", "NSObject", nc_im, nc_cm, 4},
    {"NSNotification", "NSObject", note_im, 0, 12},
    {"NSLocale", "NSObject", 0, loc_cm, 4},
    {"NSURL", "NSObject", url_im, url_cm, 8},
    {"NSURLRequest", "NSObject", url_im, req_cm, 8},
    {"NSURLConnection", "NSObject", 0, conn_cm, 4},
    {0}};
void foundation2_classes(void) { objc_add_classes(f2_classes); }

IMPORT(NSLog) { char b[2048]; rt_format(b, sizeof b, objc_nsstring_cstr(r0), r1, r2, r3, sp, 1); rt_log("[NSLog] %s", b); RET(0); }
IMPORT(NSHomeDirectory) { RET(nsstr(rt_home_dir)); }
