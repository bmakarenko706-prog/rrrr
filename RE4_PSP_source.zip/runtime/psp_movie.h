#ifndef RE4_PSP_MOVIE_H
#define RE4_PSP_MOVIE_H
/* Blocking playback on the UI thread; missing / invalid files return safely. */
int psp_movie_play(const char *original_path);
void psp_movie_input_begin(void);
int psp_movie_input_cancel(void);
void psp_movie_input_end(void);
void movie_music_begin(int handle);
void movie_music_end(int handle);
int movie_music_active(void);
void gl_movie_frame(const unsigned short *pixels);
#endif
