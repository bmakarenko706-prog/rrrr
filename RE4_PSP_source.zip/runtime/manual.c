/* Standalone PSP document-style controls window. Original game layouts are
   not modified. Text files are editable UTF-8 and loaded each time it opens. */
#include "rt.h"
#include "manual.h"
#include "language.h"
#include <pspctrl.h>
#include <pspkernel.h>
#include <pspgu.h>
#include <stdio.h>
#include <string.h>
#include "manual_text.h"
#include "manual_font.h"
extern char rt_home_dir[256];
#define PAGE_MAX 32
#define MANUAL_LINE_MAX 8
#define MANUAL_CHAR_MAX 80
#define TW 512
#define TH 256
#define PANEL_W 352
#define PANEL_H 220
static u16 lines[PAGE_MAX][MANUAL_LINE_MAX][MANUAL_CHAR_MAX];
static int pages, page, active, dirty;
static u16 pixels[TW*TH] __attribute__((aligned(64)));
static const struct manual_glyph *glyph(unsigned c) {
    int a=0,b=(int)(sizeof manual_glyphs/sizeof manual_glyphs[0])-1;
    while(a<=b) {int m=(a+b)/2; if(manual_glyphs[m].cp==c)return &manual_glyphs[m];
        if(manual_glyphs[m].cp<c)a=m+1;else b=m-1;}
    if(c!='?') return glyph('?'); return 0;
}
static unsigned next_cp(const char **p) {
    const unsigned char *s=(const unsigned char *)*p; unsigned c=*s++;
    if(c>=0xc2 && c<=0xdf && (s[0]&0xc0)==0x80) {c=((c&31)<<6)|(s[0]&63);s++;}
    else if(c>=0xe0 && c<=0xef && s[0] && s[1] && (s[0]&0xc0)==0x80 && (s[1]&0xc0)==0x80) { c=((c&15)<<12)|((s[0]&63)<<6)|(s[1]&63);s+=2; }
    else if(c>=0x80) c='?';
    *p=(const char *)s; return c;
}
static void parse_text(const char *text) {
    memset(lines,0,sizeof lines); pages=1; int pg=0,ln=0,n=0,width=0;
    if(strncmp(text,"\xef\xbb\xbf",3)==0)text+=3;
    while(*text && pg<PAGE_MAX) {
        if(n==0 && strncmp(text,"---",3)==0 && (text[3]=='\n'||text[3]=='\r'||text[3]==0)) {
            text+=3; if(*text=='\r')text++;if(*text=='\n')text++;
            if(pg<PAGE_MAX-1 && (ln>0 || lines[pg][0][0])) {pg++;ln=0;pages=pg+1;}
            n=width=0;continue;
        }
        if(*text=='\r'){text++;continue;}
        if(*text=='\n') {text++;ln++;n=width=0;if(ln>=MANUAL_LINE_MAX){if(pg>=PAGE_MAX-1)break;pg++;pages=pg+1;ln=0;}continue;}
        unsigned cp=next_cp(&text); const struct manual_glyph *g=glyph(cp);
        int adv=g?g->advance:8;
        if(width+adv>298 || n>=MANUAL_CHAR_MAX-1) {ln++;n=width=0;if(ln>=MANUAL_LINE_MAX){if(pg>=PAGE_MAX-1)break;pg++;pages=pg+1;ln=0;}}
        lines[pg][ln][n++]=(u16)cp; width+=adv;
    }
    /* A trailing newline after the final line should not add a blank page. */
    while(pages>1) {int any=0; for(int i=0;i<MANUAL_LINE_MAX;i++)if(lines[pages-1][i][0])any=1;if(any)break;pages--;}
}
static const char *fallback(int l) {
    switch(l) {case 0:return manual_ru;case 2:return manual_fr;case 3:return manual_de;case 4:return manual_it;case 5:return manual_es;default:return manual_en;}
}
void manual_open(void) {
    int l=language_manual_id();const char *names[]={"ru","en","fr","de","it","es"};
    if(l<0||l>5)l=1;
    char path[512],buf[8192];snprintf(path,sizeof path,"%s/localization/manual/%s.txt",rt_home_dir,names[l]);
    FILE *f=fopen(path,"rb");int ok=0;
    if(f){size_t n=fread(buf,1,sizeof buf-1,f);int extra=fgetc(f);fclose(f);if(n && extra==EOF && !memchr(buf,0,n)){buf[n]=0;parse_text(buf);ok=1;}}
    if(!ok)parse_text(fallback(l)); page=0;active=1;dirty=1;
}
int manual_is_open(void){return active;}
void manual_handle(u32 pressed) {
    if(!active)return;
    if(pressed & PSP_CTRL_CIRCLE){active=0;return;}
    int old=page;
    if(pressed & (PSP_CTRL_RIGHT|PSP_CTRL_DOWN|PSP_CTRL_CROSS|PSP_CTRL_RTRIGGER)) {if(page<pages-1)page++;}
    else if(pressed & (PSP_CTRL_LEFT|PSP_CTRL_UP|PSP_CTRL_LTRIGGER)) {if(page>0)page--;}
    if(page!=old)dirty=1;
}
static u16 rgb(int r,int g,int b) {return (u16)(((b>>3)<<11)|((g>>2)<<5)|(r>>3));}
static void rect(int x,int y,int w,int h,u16 c) {for(int j=y;j<y+h;j++)for(int i=x;i<x+w;i++)if(i>=0&&i<PANEL_W&&j>=0&&j<PANEL_H)pixels[j*TW+i]=c;}
static void write_line(int x,int y,const u16 *s,u16 color) {
    while(*s && x<322) {const struct manual_glyph *g=glyph(*s++);if(!g)continue;
        for(int gy=0;gy<20;gy++)for(int gx=0;gx<16;gx++)
            if((g->bits[gy*2+gx/8] & (128>>(gx%8))) && x+gx>=0 && x+gx<PANEL_W && y+gy>=0 && y+gy<PANEL_H)
                pixels[(y+gy)*TW+x+gx]=color;
        x+=g->advance;
    }
}
static void rasterize(void) {
    memset(pixels,0,sizeof pixels);
    for(int y=0;y<PANEL_H;y++)for(int x=0;x<PANEL_W;x++) {
        int edge=x<13||x>=PANEL_W-13||y<13||y>=PANEL_H-13;
        if(edge){unsigned grain=(unsigned)(x*19+y*47+(x*y)%13)%13; pixels[y*TW+x]=rgb(38+grain*2,23+grain,14+grain/2);}
        else pixels[y*TW+x]=rgb(5,4,3);
    }
    rect(0,0,PANEL_W,1,rgb(148,106,66));rect(0,PANEL_H-1,PANEL_W,1,rgb(148,106,66));
    rect(0,0,1,PANEL_H,rgb(148,106,66));rect(PANEL_W-1,0,1,PANEL_H,rgb(148,106,66));
    rect(13,13,PANEL_W-26,1,rgb(76,47,27));rect(13,PANEL_H-14,PANEL_W-26,1,rgb(76,47,27));
    for(int i=0;i<MANUAL_LINE_MAX;i++) write_line(26,22+i*20,lines[page][i],i==0?rgb(236,211,155):rgb(238,236,230));
    char number[16]; snprintf(number,sizeof number,"%d / %d",page+1,pages);u16 nums[16];int j=0;while(number[j]&&j<15){nums[j]=(u8)number[j];j++;}nums[j]=0;write_line(285,190,nums,rgb(174,153,117));
    sceKernelDcacheWritebackRange(pixels,sizeof pixels);dirty=0;
}
void manual_draw(int area_x,int area_w) {
    if(!active)return;if(dirty)rasterize();
    typedef struct {u32 color; s16 x,y,z,pad;} Col;
    typedef struct {float u,v; s16 x,y,z,pad;} Tex;
    sceGuDisable(GU_TEXTURE_2D);sceGuDisable(GU_DEPTH_TEST);sceGuDisable(GU_ALPHA_TEST);sceGuDisable(GU_FOG);sceGuDisable(GU_LIGHTING);sceGuDisable(GU_CULL_FACE);sceGuEnable(GU_BLEND);sceGuBlendFunc(GU_ADD,GU_SRC_ALPHA,GU_ONE_MINUS_SRC_ALPHA,0,0);sceGuPixelMask(0);sceGuDepthMask(1);sceGuEnable(GU_SCISSOR_TEST);sceGuScissor(0,0,480,272);
    Col *c=sceGuGetMemory(2*sizeof *c);c[0]=(Col){0x99000000u,(s16)area_x,0,0,0};c[1]=(Col){0x99000000u,(s16)(area_x+area_w),272,0,0};sceGuDrawArray(GU_SPRITES,GU_COLOR_8888|GU_VERTEX_16BIT|GU_TRANSFORM_2D,2,0,c);
    sceGuDisable(GU_BLEND);sceGuEnable(GU_TEXTURE_2D);sceGuTexMode(GU_PSM_5650,0,0,0);sceGuTexImage(0,TW,TH,TW,pixels);sceGuTexFunc(GU_TFX_REPLACE,GU_TCC_RGB);sceGuTexFilter(GU_LINEAR,GU_LINEAR);sceGuTexWrap(GU_CLAMP,GU_CLAMP);sceGuTexScale(1,1);sceGuTexOffset(0,0);sceGuTexMapMode(GU_TEXTURE_COORDS,0,0);
    int w=area_w*74/100,h=220;int x=area_x+(area_w-w)/2,y=(272-h)/2;
    Tex *v=sceGuGetMemory(2*sizeof *v);v[0]=(Tex){0,0,(s16)x,(s16)y,0,0};v[1]=(Tex){PANEL_W,PANEL_H,(s16)(x+w),(s16)(y+h),0,0};sceGuDrawArray(GU_SPRITES,GU_TEXTURE_32BITF|GU_VERTEX_16BIT|GU_TRANSFORM_2D,2,0,v);
}
