#ifndef RE4_INTRO_CODEC_H
#define RE4_INTRO_CODEC_H
#include <stddef.h>
#include <stdint.h>
#define INTRO_W 480
#define INTRO_H 272
#define INTRO_PIXELS_BYTES (INTRO_W * INTRO_H * 2u)
#define INTRO_DATA_BYTES (INTRO_PIXELS_BYTES + 4u)
#define INTRO_FILE_BYTES (INTRO_DATA_BYTES + 8u)
void intro_crypt(uint8_t *data, size_t n, const uint8_t nonce[8]);
int intro_decode(uint8_t *data, size_t n, const uint8_t nonce[8]);
#endif
