/* Classifies virtual Frame calls for known interactive menu tasks in the
   exact guest binary used by this recompiler. Not a generic game-state API. */
#ifndef RE4_UI_CURSOR_H
#define RE4_UI_CURSOR_H
static int ui_cursor_is_menu_task(unsigned int target) {
    switch (target) {
    case 0x950a0: /* Status */
    case 0x95bc4: /* StatusFile */
    case 0x96f70: /* StatusMap */
    case 0x97c4c: /* StatusOption */
    case 0x99bc4: /* TitleOption */
    case 0x9bfc4: /* StatusItem */
    case 0xa5f34: /* GameCSOption */
    case 0x85794: /* ControllerSetting */
    case 0x87fdc: /* LanguageSetting */
    case 0x947b4: /* SoundSetting */
    case 0xa6b6c: /* ControllerPreview */
    case 0x866f4: /* DataLoad */
    case 0x869cc: /* DataReset */
    case 0x88698: /* MissionSelect */
    case 0x894d8: /* MissionSelectMercenary */
    case 0x8ad9c: /* MissionSelectStory */
    case 0x8b8bc: /* NewRoundConfirm */
    case 0x8c0dc: /* QuitConfirm */
    case 0x8c5fc: /* RetireConfirm */
    case 0x8cc60: /* RetryConfirm */
    case 0x8d308: /* Shop */
    case 0x8dcb0: /* ShopBuy */
    case 0x8ec7c: /* ShopBuyConf */
    case 0x8f724: /* ShopCust */
    case 0x90604: /* ShopCustSel */
    case 0x917c0: /* ShopCustSelConf */
    case 0x92380: /* ShopSell */
    case 0x93808: /* ShopSellConf */
    case 0x94228: /* ShopTop */
        return 1;
    default: return 0;
    }
}
/* Title task owns both the splash (steps 0-2) and the button menu
   (step 4). Step 3 is the transition into the menu; step 5 exits it. */
static int ui_cursor_is_title_menu(unsigned int target, unsigned int stage) {
    return target == 0x98bf0 && stage == 4;
}
#endif
