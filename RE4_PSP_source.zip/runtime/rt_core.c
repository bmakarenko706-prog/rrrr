/* Core runtime: guest memory, loading the user's Res4 binary, import binding, indirect calls. */
#include "rt.h"
#include "funcs.h"
#ifdef RE4_PSP
#include "psp_glue.h"
#include "ui_cursor.h"
#endif
#include <string.h>

u8 *MEM;
u32 MEM_SIZE;
u32 rt_cb_sp;
int rt_verbose = 0;
int rt_target_fps = 30; /* Host debugging only; PSP timer is fixed at 23 Hz. */
static u32 imp_addr[RC_NUM_IMPORTS];

int rt_log_enabled = 1;   /* host defaults to on; PSP log=0 disables nonfatal logging */
int rt_log_time;          /* prefix log lines with the time in seconds */
void rt_log(const char *fmt, ...) {
    if (!rt_log_enabled) return;
    if (rt_log_time) fprintf(stderr, "%8.3f ", plat_time_us() / 1e6);
    va_list ap; va_start(ap, fmt); vfprintf(stderr, fmt, ap); va_end(ap); fputc('\n', stderr);
#if defined(RE4_PSP) && !defined(RE4_PSPLINK)
    /* The regular log uses a buffered stderr (configured after freopen).
       Avoid a Memory Stick write for every fragment of every resource log.
       Flush at most once per two seconds when messages are being emitted;
       fatal errors and normal shutdown flush explicitly. */
    static u64 last_flush_us;
    u64 now = plat_time_us();
    if (now - last_flush_us >= 2000000u) { fflush(stderr); last_flush_us = now; }
#else
    /* Keep host and PSPLINK diagnostics immediate for crash debugging. */
    fflush(stderr);
#endif
}
void plat_fatal(const char *msg) __attribute__((weak));
void rt_fatal(const char *fmt, ...) {
    char msg[512];
    va_list ap; va_start(ap, fmt); vsnprintf(msg, sizeof msg, fmt, ap); va_end(ap);
    fprintf(stderr, "FATAL: %s\n", msg); fflush(stderr);
    if (plat_fatal) plat_fatal(msg);     /* PSP: show the message on screen */
    exit(1);
}

/* ---- function lookup: open-addressing hash of guest address -> host function */
#define FH_BITS 14
static u32 fh_key[1 << FH_BITS];
static rc_fn fh_val[1 << FH_BITS];
static inline u32 fh_hash(u32 a) { return ((a >> 2) * 2654435761u) >> (32 - FH_BITS); }
static void fh_build(void) {
    for (u32 i = 0; i < rc_nfuncs; i++) {
        u32 h = fh_hash(rc_funcs[i].addr);
        while (fh_key[h]) h = (h + 1) & ((1 << FH_BITS) - 1);
        fh_key[h] = rc_funcs[i].addr; fh_val[h] = rc_funcs[i].fn;
    }
}
static inline rc_fn fh_find(u32 a) {
    u32 h = fh_hash(a);
    while (fh_key[h]) { if (fh_key[h] == a) return fh_val[h]; h = (h + 1) & ((1 << FH_BITS) - 1); }
    return 0;
}

u64 rc_icall(u32 t, u32 r0, u32 r1, u32 r2, u32 r3, u32 sp) {
#ifdef RE4_PSP
    /* These task Frame methods are dispatched virtually by the guest. */
    if (ui_cursor_is_menu_task(t)) psp_ui_tick_note(t);
#endif
    rc_fn f = fh_find(t);
    if (f) {
#ifdef RE4_PSP
        /* Read the title stage after Frame: the task shares its state machine
           between the splash and the Start/Settings menu. */
        if (t == 0x98bf0) {
            u64 result = f(r0, r1, r2, r3, sp);
            if (MEM_SIZE >= 12 && r0 >= 0x1000 && r0 <= MEM_SIZE - 12 &&
                ui_cursor_is_title_menu(t, RD32(r0 + 8))) psp_ui_tick_note(t);
            return result;
        }
#endif
        return f(r0, r1, r2, r3, sp);
    }
    if (t >= RC_IMP_BASE && t < RC_IMP_BASE + 4 * RC_NUM_IMPORTS && !(t & 3))
        return rc_imports[(t - RC_IMP_BASE) >> 2].fn(r0, r1, r2, r3, sp);
    if (t == LR_MAGIC) return RV(r0, r1);
    rt_fatal("bad indirect call to 0x%08x (r0=%08x r1=%08x)", t, r0, r1);
}
u64 rc_call(u32 fn, u32 r0, u32 r1, u32 r2, u32 r3, u32 sp) { return rc_icall(fn, r0, r1, r2, r3, sp); }
u64 rc_unimpl(u32 addr) { rt_fatal("unimplemented ARM code reached at 0x%x", addr); }
u64 rc_missing_import(u32 idx, u32 r0, u32 r1, u32 r2, u32 r3, u32 sp) {
    static u8 warned[RC_NUM_IMPORTS];
    if (!warned[idx]++) rt_log("[hle] missing import %s (r0=%x r1=%x r2=%x)", rc_imports[idx].name, r0, r1, r2);
    (void)r3; (void)sp;
    return 0;
}
#ifdef RC_TRACE
void rc_trace_enter(u32 a) { if (rt_verbose > 2) rt_log("-> %x", a); }
#endif

/* ---- data imports registered by HLE modules (Obj-C classes, constant NSStrings, typeinfo vtables) */
#define MAXDATA 256
static const char *dnames[MAXDATA]; static u32 daddrs[MAXDATA]; static int ndata;
void rt_register_data(const char *name, u32 g) { if (ndata < MAXDATA) { dnames[ndata] = name; daddrs[ndata++] = g; } }
u32 rt_import_addr(const char *name) {
    for (u32 i = 0; i < rc_nimports; i++) if (!strcmp(rc_imports[i].name, name)) return imp_addr[i];
    return 0;
}
u32 rt_find_func(const char *sym) { (void)sym; return 0; }

static void bind_imports(void) {
    for (u32 i = 0; i < rc_nimports; i++) {
        imp_addr[i] = RC_IMP_BASE + 4 * i;
        for (int j = 0; j < ndata; j++) if (!strcmp(dnames[j], rc_imports[i].name)) imp_addr[i] = daddrs[j];
    }
    for (u32 i = 0; i < rc_nbinds; i++) {
        const rc_bind_entry *b = &rc_binds[i];
        if (b->kind == 0) WR32(b->addr, imp_addr[b->imp]);
        else WR32(b->addr, RD32(b->addr) + imp_addr[b->imp]);
    }
}

static void load_image(const char *path) {
    FILE *f = fopen(path, "rb");
    if (!f) rt_fatal("cannot open game binary %s (copy Res4 from your IPA next to the EBOOT)", path);
    for (u32 i = 0; i < rc_nsegs; i++) {
        const rc_seg_entry *s = &rc_segs[i];
        if (s->addr + s->size > MEM_SIZE) rt_fatal("segment beyond guest memory");
        fseek(f, s->off, SEEK_SET);
        if (fread(MEM + s->addr, 1, s->fsize, f) != s->fsize) rt_fatal("short read in %s", path);
    }
    fclose(f);
    /* sanity check: the binary must be the exact build this EBOOT was generated from */
    if (RD32(rc_main_addr) == 0) rt_fatal("Res4 does not match this build");
}

u32 gstrdup(const char *s) { u32 n = strlen(s) + 1, g = gmalloc(n); memcpy(MEM + g, s, n); return g; }
u32 gmemdup(const void *p, u32 n) { u32 g = gmalloc(n ? n : 1); memcpy(MEM + g, p, n); return g; }

int rt_main(int argc, char **argv, u32 mem_size) {
    MEM_SIZE = mem_size;
    if (!MEM) MEM = calloc(1, MEM_SIZE);    /* the PSP layer passes a preallocated, zeroed block */
    if (!MEM) rt_fatal("cannot allocate %u bytes of guest memory", MEM_SIZE);
    plat_init(argc, argv);
    char path[300];
    snprintf(path, sizeof path, "%s/Res4", rt_bundle_dir);
    load_image(path);
    u32 image_end = 0;
    for (u32 i = 0; i < rc_nsegs; i++) if (rc_segs[i].addr + rc_segs[i].size > image_end) image_end = rc_segs[i].addr + rc_segs[i].size;
    u32 stack_size = 512 * 1024;
    heap_init((image_end + 0xfff) & ~0xfff, MEM_SIZE - stack_size);
    /* the original ARM code is only needed for the sanity check above: its memory becomes heap
       (RE4_TEXT=keep leaves it alone, RE4_TEXT=poison fills it with garbage to catch data reads) */
    const char *tm = getenv("RE4_TEXT");
    if (tm && !strcmp(tm, "poison")) memset(MEM + rc_text_lo, 0xe7, rc_text_hi - rc_text_lo);
    else if (!tm || strcmp(tm, "keep")) { memset(MEM + rc_text_lo, 0, rc_text_hi - rc_text_lo); heap_add((rc_text_lo + 15) & ~15u, rc_text_hi & ~15u); }
    fh_build();
    libc_init();
    cxx_init();
    objc_init();          /* creates native classes and registers data imports */
    bind_imports();
    objc_bind_classes();  /* fix up game classes now that superclasses are bound */
    u32 sp = MEM_SIZE - 64;
    rt_cb_sp = sp - 0x10000;   /* callbacks from the run loop use a region below main's frames */
    rt_log("[rt] guest memory %u KB, heap free %u KB, %u functions, %u imports", MEM_SIZE >> 10,
           heap_free_bytes() >> 10, rc_nfuncs, rc_nimports);
    for (u32 i = 0; i < rc_nmod_init; i++) rc_call(rc_mod_init[i], 0, 0, 0, 0, sp);
    rt_log("[rt] %u static constructors done, heap free %u KB", rc_nmod_init, heap_free_bytes() >> 10);
    /* argv for the guest */
    u32 gargv = gmalloc(8);
    WR32(gargv, gstrdup(path)); WR32(gargv + 4, 0);
    u64 r = rc_call(rc_main_addr, 1, gargv, 0, 0, sp);
    rt_log("[rt] main returned %d", (int)(u32)r);
    return (int)(u32)r;
}
