#ifndef STARTUP_PROFILE_H
#define STARTUP_PROFILE_H
#ifdef STARTUP_PROFILE
#include <stdio.h>
#include <sys/stat.h>
#include <stddef.h>
void startup_profile_begin(void);
void startup_profile_show(void);
int profile_stat(const char *, struct stat *);
FILE *profile_fopen(const char *, const char *);
int profile_fclose(FILE *);
int profile_fseek(FILE *,long,int);
long profile_ftell(FILE *);
size_t profile_fread(void *,size_t,size_t,FILE *);
#ifndef STARTUP_PROFILE_IMPL
#define stat(p,s) profile_stat((p),(s))
#define fopen profile_fopen
#define fclose profile_fclose
#define fseek profile_fseek
#define ftell profile_ftell
#define fread profile_fread
#endif
#endif
#endif
