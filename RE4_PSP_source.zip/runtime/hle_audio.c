/* AudioToolbox (RemoteIO render callback) and AVAudioPlayer (music) */
#include "objc.h"
#include "funcs.h"
#include "platform.h"
#include <string.h>

/* ---------- AudioSession */
IMPORT(AudioSessionInitialize) { (void)r0; (void)r1; (void)r2; (void)r3; (void)sp; RET(0); }
IMPORT(AudioSessionSetActive) { (void)r0; (void)r1; (void)r2; (void)r3; (void)sp; RET(0); }
IMPORT(AudioSessionSetProperty) { (void)r1; (void)r2; (void)r3; (void)sp;
    if (rt_verbose) rt_log("[audio] AudioSessionSetProperty '%c%c%c%c'", r0 >> 24, r0 >> 16, r0 >> 8, r0); RET(0); }
IMPORT(AudioSessionGetProperty) {   /* (id, UInt32 *ioSize, void *out) */
    (void)r3; (void)sp;
    u32 size = r1 ? RD32(r1) : 0;
    if (r2 && size) memset(MEM + r2, 0, size);
    switch (r0) {
    case 0x63687372: if (r2 && size >= 8) WRD(r2, 44100.0); break;     /* 'chsr' hardware sample rate */
    case 0x63686f63: if (r2 && size >= 4) WR32(r2, 2); break;          /* 'choc' output channels */
    case 0x6f746872: if (r2 && size >= 4) WR32(r2, 0); break;          /* 'othr' other audio playing */
    default: if (rt_verbose) rt_log("[audio] AudioSessionGetProperty '%c%c%c%c'", r0 >> 24, r0 >> 16, r0 >> 8, r0);
    }
    RET(0);
}

/* ---------- RemoteIO output unit: one instance; render callback pulled from the main loop */
typedef struct { u32 proc, refcon; double rate; u32 flags, bpf, ch, bits; int running; u32 abl, bufs[2], ts, aflags; } audio_unit;
static audio_unit au;
#define AU_HANDLE 0x41550001u
#define AU_MAXFR 512
IMPORT(AudioComponentFindNext) { (void)r0; (void)r1; (void)r2; (void)r3; (void)sp; RET(0x41430001u); }
IMPORT(AudioComponentInstanceNew) { (void)r0; (void)r2; (void)r3; (void)sp; if (r1) WR32(r1, AU_HANDLE); RET(0); }
IMPORT(AudioComponentInstanceDispose) { (void)r0; (void)r1; (void)r2; (void)r3; (void)sp; au.running = 0; au.proc = 0; RET(0); }
IMPORT(AudioUnitInitialize) { (void)r0; (void)r1; (void)r2; (void)r3; (void)sp; RET(0); }
IMPORT(AudioUnitSetProperty) {   /* (unit, id, scope, element, data, size) */
    (void)r0; (void)r2; (void)r3;
    u32 data = SARG(0);
    if (r1 == 0x17 && data) { au.proc = RD32(data); au.refcon = RD32(data + 4); rt_log("[audio] render callback %x", au.proc); }
    else if (r1 == 8 && data) {
        au.rate = RDD(data); au.flags = RD32(data + 12); au.bpf = RD32(data + 24); au.ch = RD32(data + 28); au.bits = RD32(data + 32);
        rt_log("[audio] stream format %.0f Hz, %u ch, %u bits, flags %x", au.rate, au.ch, au.bits, au.flags);
    }
    RET(0);
}
IMPORT(AudioUnitGetProperty) {   /* (unit, id, scope, element, data, UInt32 *size) */
    (void)r0; (void)r2; (void)r3;
    u32 data = SARG(0);
    if (r1 == 8 && data) {
        memset(MEM + data, 0, 40);
        WRD(data, au.rate); WR32(data + 8, 0x6c70636d); WR32(data + 12, au.flags); WR32(data + 16, au.bpf);
        WR32(data + 20, 1); WR32(data + 24, au.bpf); WR32(data + 28, au.ch); WR32(data + 32, au.bits);
    }
    RET(0);
}
IMPORT(AudioOutputUnitStart) { (void)r0; (void)r1; (void)r2; (void)r3; (void)sp;
    if (!au.abl) {
        au.abl = gcalloc(4 + 2 * 12); au.ts = gcalloc(64); au.aflags = gcalloc(4);
        for (int i = 0; i < 2; i++) au.bufs[i] = gcalloc(AU_MAXFR * 4);
    }
    if (au.rate < 1000) au.rate = 11025;
    plat_audio_open((int)au.rate);
    au.running = 1;
    RET(0); }
IMPORT(AudioOutputUnitStop) { (void)r0; (void)r1; (void)r2; (void)r3; (void)sp; au.running = 0; RET(0); }

static void render(u32 sp, int n) {
    static s16 out[AU_MAXFR * 2];
    WR32(au.abl, 2);
    for (int i = 0; i < 2; i++) { WR32(au.abl + 4 + 12 * i, 1); WR32(au.abl + 8 + 12 * i, n * 4); WR32(au.abl + 12 + 12 * i, au.bufs[i]); }
    WR32(au.aflags, 0);
    u32 csp = sp - 64;
    WR32(csp, n); WR32(csp + 4, au.abl);
    rc_call(au.proc, au.refcon, au.aflags, au.ts, 0, csp);
    WRD(au.ts + 0, RDD(au.ts) + n);   /* mSampleTime */
    for (int c = 0; c < 2; c++) {
        u32 b = au.bufs[c];
        for (int i = 0; i < n; i++) {
            s32 v = (s32)RD32(b + 4 * i) >> 9;          /* 8.24 fixed point -> s16 */
            out[2 * i + c] = v > 32767 ? 32767 : v < -32768 ? -32768 : (s16)v;
        }
    }
    plat_audio_write(out, n);
}

/* ---------- AVAudioPlayer: [isa][delegate][data][loops][volume f][playing][handle][url] */
#define MAXP 32
static u32 players[MAXP];
static void track(u32 p) { for (int i = 0; i < MAXP; i++) if (!players[i]) { players[i] = p; return; } rt_log("[audio] too many players"); }
static void untrack(u32 p) { for (int i = 0; i < MAXP; i++) if (players[i] == p) players[i] = 0; }
static u32 init_player(u32 self, int h) {
    if (h < 0) { objc_release(self); return 0; }
    WR32(self + 24, (u32)h); WRF(self + 16, 1.0f); track(self);
    return self;
}
NM(av_initurl) { UNUSED_ARGS;
    const char *path = a2 ? objc_nsstring_cstr(RD32(a2 + 4)) : "";
    if (a3) WR32(a3, 0);
    WR32(self + 28, objc_retain(a2));
    RET(init_player(self, plat_music_open(path, 0, 0))); }
NM(av_initdata) { UNUSED_ARGS;
    if (a3) WR32(a3, 0);
    if (!a2) { objc_release(self); RET(0); }
    WR32(self + 8, objc_retain(a2));
    RET(init_player(self, plat_music_open(0, MEM + RD32(a2 + 4), RD32(a2 + 8)))); }
static int ph(u32 self) { return (int)RD32(self + 24); }
NM(av_play) { UNUSED_ARGS; plat_music_play(ph(self), (s32)RD32(self + 12)); WR32(self + 20, 1); RET(1); }
NM(av_pause) { UNUSED_ARGS; plat_music_pause(ph(self)); WR32(self + 20, 0); RET(0); }
NM(av_stop) { UNUSED_ARGS; plat_music_stop(ph(self)); WR32(self + 20, 0); RET(0); }
NM(av_playing) { UNUSED_ARGS; RET(RD32(self + 20) && plat_music_playing(ph(self))); }
NM(av_setloops) { UNUSED_ARGS; WR32(self + 12, a2); RET(0); }
NM(av_loops) { UNUSED_ARGS; RET(RD32(self + 12)); }
NM(av_setvol) { UNUSED_ARGS; WR32(self + 16, a2); plat_music_volume(ph(self), U2F(a2)); RET(0); }
NM(av_vol) { UNUSED_ARGS; RET(RD32(self + 16)); }
NM(av_settime) { UNUSED_ARGS; plat_music_seek(ph(self), U2D(((u64)a3 << 32) | a2)); RET(0); }
NM(av_time) { UNUSED_ARGS; RETD(plat_music_time(ph(self))); }
NM(av_duration) { UNUSED_ARGS; RETD(plat_music_duration(ph(self))); }
NM(av_setdelegate) { UNUSED_ARGS; WR32(self + 4, a2); RET(0); }
NM(av_delegate) { UNUSED_ARGS; RET(RD32(self + 4)); }
NM(av_yes) { UNUSED_ARGS; RET(1); }
NM(av_dealloc) { UNUSED_ARGS;
    untrack(self); plat_music_close(ph(self));
    objc_release(RD32(self + 8)); objc_release(RD32(self + 28));
    objc_dealloc_raw(self); RET(0); }
static nmdef av_im[] = {{"initWithContentsOfURL:error:", av_initurl}, {"initWithData:error:", av_initdata},
    {"play", av_play}, {"pause", av_pause}, {"stop", av_stop}, {"isPlaying", av_playing}, {"prepareToPlay", av_yes},
    {"setNumberOfLoops:", av_setloops}, {"numberOfLoops", av_loops}, {"setVolume:", av_setvol}, {"volume", av_vol},
    {"setCurrentTime:", av_settime}, {"currentTime", av_time}, {"duration", av_duration}, {"setDelegate:", av_setdelegate},
    {"delegate", av_delegate}, {"dealloc", av_dealloc}, {0}};
static nclass av_cls[] = {{"AVAudioPlayer", "NSObject", av_im, 0, 32}, {0}};
void avaudio_classes(void) { objc_add_classes(av_cls); }

void audio_pump(u32 sp) {
    if (au.running && au.proc) {
        int space = plat_audio_space();
        while (space >= 64) { int n = space > 256 ? 256 : space; render(sp, n); space -= n; }
    }
    for (int i = 0; i < MAXP; i++) {
        u32 p = players[i];
        if (!p || !RD32(p + 20) || plat_music_playing(ph(p))) continue;
        WR32(p + 20, 0);
        u32 d = RD32(p + 4);
        if (d) objc_send(sp, d, sel_named("audioPlayerDidFinishPlaying:successfully:"), p, 1);
    }
}
