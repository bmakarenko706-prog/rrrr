/* Foundation part 1: NSObject, NSString, NSData, NSNumber, NSArray/NSSet, NSDictionary, NSAutoreleasePool */
#include "objc.h"
#include "funcs.h"
#include <string.h>
#ifdef STARTUP_PROFILE
#include "startup_profile.h"
#endif

/* ---------- NSObject */
NM(o_alloc) { UNUSED_ARGS; RET(objc_new(self)); }
NM(o_new) { UNUSED_ARGS; u32 o = objc_new(self); return objc_send(sp, o, sel_named("init"), 0, 0); }
NM(o_self) { UNUSED_ARGS; RET(self); }
NM(o_class) { UNUSED_ARGS; RET(RD32(self)); }
NM(c_class) { UNUSED_ARGS; RET(self); }
NM(o_retain) { UNUSED_ARGS; RET(objc_retain(self)); }
NM(o_release) { UNUSED_ARGS; objc_release(self); RET(0); }
NM(o_autorelease) { UNUSED_ARGS; RET(objc_autorelease(self)); }
NM(o_retaincount) { UNUSED_ARGS; RET(self >= 0xe7000 ? RD32(self - 4) : 0x7fffffff); }
NM(o_dealloc) { UNUSED_ARGS; objc_dealloc_raw(self); RET(0); }
NM(o_iskind) { UNUSED_ARGS; RET(objc_is_kind(self, a2)); }
NM(o_responds) { UNUSED_ARGS; RET(objc_responds(self, a2)); }
NM(o_isequal) { UNUSED_ARGS; RET(self == a2); }
NM(o_hash) { UNUSED_ARGS; RET(self >> 2); }
NM(o_perform) { UNUSED_ARGS; return objc_send(sp, self, a2, 0, 0); }
NM(o_perform1) { UNUSED_ARGS; return objc_send(sp, self, a2, a3, 0); }
NM(o_ignore) { UNUSED_ARGS; RET(0); }
static nmdef obj_im[] = {{"init", o_self}, {"retain", o_retain}, {"release", o_release}, {"autorelease", o_autorelease},
    {"retainCount", o_retaincount}, {"dealloc", o_dealloc}, {"class", o_class}, {"isKindOfClass:", o_iskind},
    {"respondsToSelector:", o_responds}, {"isEqual:", o_isequal}, {"hash", o_hash}, {"self", o_self},
    {"performSelector:", o_perform}, {"performSelector:withObject:", o_perform1}, {"awakeFromNib", o_ignore}, {0}};
static nmdef obj_cm[] = {{"alloc", o_alloc}, {"allocWithZone:", o_alloc}, {"new", o_new}, {"class", c_class},
    {"retain", o_self}, {"release", o_ignore}, {"autorelease", o_self}, {"respondsToSelector:", o_responds},
    {"initialize", o_ignore}, {0}};

/* ---------- NSString: [isa][flags][cstr][len]; flags bit 31 = owns cstr */
#define STR_OWNED 0x80000000u
u32 nsstr_owned(const char *s) {
    u32 o = objc_new_named("NSString"), n = strlen(s);
    WR32(o + 4, 0x7c8 | STR_OWNED); WR32(o + 8, gmemdup(s, n + 1)); WR32(o + 12, n);
    return o;
}
u32 nsstr(const char *s) { return objc_autorelease(nsstr_owned(s)); }
const char *objc_nsstring_cstr(u32 o) {
    if (!o) return "";
    u32 p = RD32(o + 8);
    return p ? GSTR(p) : "";
}
NM(s_withcstr) { UNUSED_ARGS; RET(nsstr(a2 ? GSTR(a2) : "")); }
NM(s_initcstr) { UNUSED_ARGS; const char *s = a2 ? GSTR(a2) : ""; u32 n = strlen(s);
    WR32(self + 4, 0x7c8 | STR_OWNED); WR32(self + 8, gmemdup(s, n + 1)); WR32(self + 12, n); RET(self); }
NM(s_cstr) { UNUSED_ARGS; RET(RD32(self + 8)); }
NM(s_length) { UNUSED_ARGS; RET(RD32(self + 12)); }
NM(s_append_path) { UNUSED_ARGS;
    const char *a = objc_nsstring_cstr(self), *b = objc_nsstring_cstr(a2);
    char buf[512]; size_t la = strlen(a);
    snprintf(buf, sizeof buf, "%s%s%s", a, (la && a[la - 1] == '/') || !*b ? "" : "/", b);
    RET(nsstr(buf)); }
NM(s_append) { UNUSED_ARGS; char buf[1024]; snprintf(buf, sizeof buf, "%s%s", objc_nsstring_cstr(self), objc_nsstring_cstr(a2)); RET(nsstr(buf)); }
NM(s_isequal) { UNUSED_ARGS; if (!a2) RET(0); RET(!strcmp(objc_nsstring_cstr(self), objc_nsstring_cstr(a2))); }
NM(s_compare) { UNUSED_ARGS; int c = strcmp(objc_nsstring_cstr(self), objc_nsstring_cstr(a2)); RET(c < 0 ? (u32)-1 : c > 0); }
NM(s_hash) { UNUSED_ARGS; u32 h = 5381; for (const char *s = objc_nsstring_cstr(self); *s; s++) h = h * 33 + (u8)*s; RET(h); }
NM(s_dealloc) { UNUSED_ARGS; if (RD32(self + 4) & STR_OWNED) gfree(RD32(self + 8)); objc_dealloc_raw(self); RET(0); }
NM(s_intvalue) { UNUSED_ARGS; RET((u32)atoi(objc_nsstring_cstr(self))); }
NM(s_copy) { UNUSED_ARGS; RET(objc_retain(self)); }
NM(s_lastpath) { UNUSED_ARGS; const char *s = objc_nsstring_cstr(self), *p = strrchr(s, '/'); RET(nsstr(p ? p + 1 : s)); }
static nmdef str_im[] = {{"cStringUsingEncoding:", s_cstr}, {"UTF8String", s_cstr}, {"cString", s_cstr},
    {"fileSystemRepresentation", s_cstr}, {"length", s_length}, {"stringByAppendingPathComponent:", s_append_path},
    {"stringByAppendingString:", s_append}, {"isEqualToString:", s_isequal}, {"isEqual:", s_isequal},
    {"compare:", s_compare}, {"hash", s_hash}, {"dealloc", s_dealloc}, {"intValue", s_intvalue},
    {"copy", s_copy}, {"lastPathComponent", s_lastpath}, {"initWithCString:", s_initcstr},
    {"initWithUTF8String:", s_initcstr}, {"initWithCString:encoding:", s_initcstr}, {0}};
static nmdef str_cm[] = {{"stringWithCString:", s_withcstr}, {"stringWithUTF8String:", s_withcstr},
    {"stringWithCString:encoding:", s_withcstr}, {0}};

/* ---------- NSData: [isa][bytes][len][owned] */
u32 nsdata_new(u32 bytes, u32 len, int owned) {
    u32 o = objc_new_named("NSData");
    WR32(o + 4, bytes); WR32(o + 8, len); WR32(o + 12, owned);
    return o;
}
static int read_file(const char *path, u32 *out, u32 *len) {
    FILE *f = fopen(path, "rb");
    if (!f) { if (rt_verbose) rt_log("[fs] missing %s", path); return 0; }
    fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET);
    u32 g = gmalloc(n ? (u32)n : 1);
    if (!g) { fclose(f); rt_log("[fs] no memory for %s (%ld bytes)", path, n); return 0; }
    size_t got = fread(MEM + g, 1, n, f); fclose(f);
    *out = g; *len = (u32)got;
    if (rt_verbose) rt_log("[fs] loaded %s (%ld bytes)", path, n);
    return 1;
}
NM(d_initfile) { UNUSED_ARGS; u32 b, n;
    if (!read_file(objc_nsstring_cstr(a2), &b, &n)) { objc_release(self); RET(0); }
    WR32(self + 4, b); WR32(self + 8, n); WR32(self + 12, 1); RET(self); }
NM(d_initbytes) { UNUSED_ARGS; WR32(self + 4, gmemdup(MEM + a2, a3)); WR32(self + 8, a3); WR32(self + 12, 1); RET(self); }
NM(d_bytes) { UNUSED_ARGS; RET(RD32(self + 4)); }
NM(d_length) { UNUSED_ARGS; RET(RD32(self + 8)); }
NM(d_getbytes) { UNUSED_ARGS; u32 n = a3 < RD32(self + 8) ? a3 : RD32(self + 8); memmove(MEM + a2, MEM + RD32(self + 4), n); RET(0); }
NM(d_write) { UNUSED_ARGS;
#ifdef RE4_PSP
    extern void re4_file_cache_invalidate(const char *path);
    re4_file_cache_invalidate(objc_nsstring_cstr(a2));
#endif
    FILE *f = fopen(objc_nsstring_cstr(a2), "wb"); if (!f) RET(0);
    fwrite(MEM + RD32(self + 4), 1, RD32(self + 8), f); fclose(f); RET(1); }
NM(d_dealloc) { UNUSED_ARGS; if (RD32(self + 12)) gfree(RD32(self + 4)); objc_dealloc_raw(self); RET(0); }
NM(dc_withfile) { UNUSED_ARGS; u32 o = objc_new(self); return objc_autorelease((u32)d_initfile(o, 0, a2, 0, sp)); }
NM(dc_withbytes) { UNUSED_ARGS; u32 o = objc_new(self); RET(objc_autorelease((u32)d_initbytes(o, 0, a2, a3, sp))); }
static nmdef data_im[] = {{"initWithContentsOfFile:", d_initfile}, {"initWithContentsOfMappedFile:", d_initfile},
    {"initWithBytes:length:", d_initbytes}, {"bytes", d_bytes}, {"length", d_length}, {"getBytes:length:", d_getbytes},
    {"writeToFile:atomically:", d_write}, {"dealloc", d_dealloc}, {0}};
static nmdef data_cm[] = {{"dataWithContentsOfFile:", dc_withfile}, {"dataWithBytes:length:", dc_withbytes}, {0}};

/* ---------- NSNumber: [isa][value] */
u32 nsnumber_bool(int b) { u32 o = objc_new_named("NSNumber"); WR32(o + 4, b != 0); return objc_autorelease(o); }
NM(n_withbool) { UNUSED_ARGS; RET(nsnumber_bool(a2 & 0xff)); }
NM(n_withint) { UNUSED_ARGS; u32 o = objc_new(self); WR32(o + 4, a2); RET(objc_autorelease(o)); }
NM(n_value) { UNUSED_ARGS; RET(RD32(self + 4)); }
static nmdef num_im[] = {{"boolValue", n_value}, {"intValue", n_value}, {"integerValue", n_value}, {0}};
static nmdef num_cm[] = {{"numberWithBool:", n_withbool}, {"numberWithInt:", n_withint}, {0}};

/* ---------- NSArray / NSSet: [isa][count][cap][items] */
u32 nsarray_new(void) { return objc_new_named("NSArray"); }
void nsarray_add(u32 a, u32 obj) {
    u32 n = RD32(a + 4), cap = RD32(a + 8);
    if (n == cap) { cap = cap ? cap * 2 : 4; WR32(a + 12, grealloc(RD32(a + 12), cap * 4)); WR32(a + 8, cap); }
    WR32(RD32(a + 12) + 4 * n, objc_retain(obj)); WR32(a + 4, n + 1);
}
NM(a_count) { UNUSED_ARGS; RET(RD32(self + 4)); }
NM(a_at) { UNUSED_ARGS; if (a2 >= RD32(self + 4)) { rt_log("[objc] array index %u out of range", a2); RET(0); } RET(RD32(RD32(self + 12) + 4 * a2)); }
NM(a_any) { UNUSED_ARGS; RET(RD32(self + 4) ? RD32(RD32(self + 12)) : 0); }
NM(a_last) { UNUSED_ARGS; u32 n = RD32(self + 4); RET(n ? RD32(RD32(self + 12) + 4 * (n - 1)) : 0); }
NM(a_enum) {   /* countByEnumeratingWithState:(a2) objects:(a3) count:(SARG0) */
    UNUSED_ARGS;
    static u32 mut;
    if (!mut) mut = gcalloc(4);
    if (RD32(a2)) RET(0);
    WR32(a2, 1); WR32(a2 + 4, RD32(self + 12)); WR32(a2 + 8, mut);
    RET(RD32(self + 4));
}
NM(a_contains) { UNUSED_ARGS; for (u32 i = 0; i < RD32(self + 4); i++) if (RD32(RD32(self + 12) + 4 * i) == a2) RET(1); RET(0); }
NM(a_dealloc) { UNUSED_ARGS; for (u32 i = 0; i < RD32(self + 4); i++) objc_release(RD32(RD32(self + 12) + 4 * i));
    gfree(RD32(self + 12)); objc_dealloc_raw(self); RET(0); }
NM(a_add) { UNUSED_ARGS; nsarray_add(self, a2); RET(0); }
NM(ac_array) { UNUSED_ARGS; RET(objc_autorelease(objc_new(self))); }
static nmdef arr_im[] = {{"count", a_count}, {"objectAtIndex:", a_at}, {"anyObject", a_any}, {"lastObject", a_last},
    {"countByEnumeratingWithState:objects:count:", a_enum}, {"containsObject:", a_contains}, {"dealloc", a_dealloc},
    {"addObject:", a_add}, {"allObjects", o_self}, {"allTouches", o_self}, {0}};
static nmdef arr_cm[] = {{"array", ac_array}, {"set", ac_array}, {0}};

/* ---------- NSDictionary: [isa][count][keys][values] */
NM(dict_with) {   /* dictionaryWithObjectsAndKeys: obj, key, ..., nil */
    UNUSED_ARGS;
    u32 d = objc_new(self), args[64]; int n = 0;
    for (int i = 0; n < 62; i++) {
        u32 v = i == 0 ? a2 : i == 1 ? a3 : SARG(i - 2);
        if ((i % 2) == 0 && !v) break;
        args[n++] = v;
    }
    int pairs = n / 2;
    u32 k = gmalloc(4 * pairs + 4), v = gmalloc(4 * pairs + 4);
    for (int i = 0; i < pairs; i++) { WR32(v + 4 * i, objc_retain(args[2 * i])); WR32(k + 4 * i, objc_retain(args[2 * i + 1])); }
    WR32(d + 4, pairs); WR32(d + 8, k); WR32(d + 12, v);
    RET(objc_autorelease(d));
}
NM(dict_get) { UNUSED_ARGS;
    const char *ks = objc_nsstring_cstr(a2);
    for (u32 i = 0; i < RD32(self + 4); i++) { u32 k = RD32(RD32(self + 8) + 4 * i);
        if (k == a2 || !strcmp(objc_nsstring_cstr(k), ks)) RET(RD32(RD32(self + 12) + 4 * i)); }
    RET(0); }
NM(dict_count) { UNUSED_ARGS; RET(RD32(self + 4)); }
static nmdef dict_im[] = {{"objectForKey:", dict_get}, {"valueForKey:", dict_get}, {"count", dict_count}, {0}};
static nmdef dict_cm[] = {{"dictionaryWithObjectsAndKeys:", dict_with}, {0}};
u32 nsdict_make(int n, const u32 *keys, const u32 *vals) {
    u32 d = objc_new_named("NSDictionary"), k = gmalloc(4 * n + 4), v = gmalloc(4 * n + 4);
    for (int i = 0; i < n; i++) { WR32(k + 4 * i, keys[i]); WR32(v + 4 * i, vals[i]); }
    WR32(d + 4, n); WR32(d + 8, k); WR32(d + 12, v);
    return d;
}

/* ---------- NSAutoreleasePool */
NM(pool_release) { UNUSED_ARGS; objc_drain_pool(); RET(0); }
static nmdef pool_im[] = {{"release", pool_release}, {"drain", pool_release}, {0}};

static nclass f1_classes[] = {
    {"NSObject", 0, obj_im, obj_cm, 4},
    {"NSString", "NSObject", str_im, str_cm, 16},
    {"NSData", "NSObject", data_im, data_cm, 16},
    {"NSNumber", "NSObject", num_im, num_cm, 8},
    {"NSArray", "NSObject", arr_im, arr_cm, 16},
    {"NSDictionary", "NSObject", dict_im, dict_cm, 16},
    {"NSAutoreleasePool", "NSObject", pool_im, 0, 4},
    {0}};
void foundation2_classes(void);
void foundation_classes(void) { objc_add_classes(f1_classes); foundation2_classes(); }
