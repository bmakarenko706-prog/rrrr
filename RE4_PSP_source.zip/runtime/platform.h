/* Platform layer interface (implemented by platform_host.c and platform_psp.c) */
#ifndef PLATFORM_H
#define PLATFORM_H
#include "recomp.h"
#define PLAT_MAX_TOUCH 4
typedef struct { int down; float x, y; } plat_touch;          /* 320x480 portrait window coordinates */
typedef struct { plat_touch touch[PLAT_MAX_TOUCH]; } plat_input;
enum { PLAT_RUN = 1, PLAT_QUIT = 0, PLAT_SUSPEND = 2, PLAT_RESUME = 3 };
int plat_poll(plat_input *in);
#ifdef RE4_PSP
void plat_exit_trace(const char *step);
#endif

/* PCM output: interleaved s16 stereo at the given rate */
void plat_audio_open(int rate);
int plat_audio_space(void);                       /* frames that can be written without blocking */
void plat_audio_write(const s16 *frames, int n);

/* compressed music streams (AVAudioPlayer): file-backed or memory-backed */
int plat_music_open(const char *path, const void *data, u32 len);   /* returns handle >= 0 or -1 */
void plat_music_close(int h);
void plat_music_play(int h, int loops);           /* loops: -1 forever, 0 once, n extra times */
void plat_music_stop(int h);
void plat_music_pause(int h);
void plat_music_volume(int h, float v);
int plat_music_playing(int h);                    /* 0 once playback finished or stopped */
double plat_music_time(int h);
void plat_music_seek(int h, double t);
double plat_music_duration(int h);
#endif
