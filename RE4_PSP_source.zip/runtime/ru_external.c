/* Optional editable JSON translations, loaded once from localization/ next to EBOOT.
   Missing, invalid or unsupported entries fall back to the compiled translations. */
#include "rt.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>

extern char rt_home_dir[256];
extern int ru_story_index(const u16 *s);
#define FILE_LIMIT (256u * 1024u)
#define TOKEN_LIMIT 8192
#define TEXT_LIMIT 4096
#define SYS_LIMIT 2048
#define STORY_LIMIT 1024

typedef struct { int start, end, next, type; } token;
typedef struct { char *data; size_t len, pos; token *t; int nt, error; } json;
enum { J_OBJ=1, J_ARR, J_STR, J_NUM, J_ATOM };
static u16 *sys[SYS_LIMIT], *mission[2][36], *extra[4][130], *story[STORY_LIMIT];
static u32 sys_cache[SYS_LIMIT], mission_cache[2][36], extra_cache[4][130], story_cache[STORY_LIMIT];
static int loaded[5];
static u16 *language_name, *language_name_en;
static u32 language_name_cache, language_name_en_cache;

static void ws(json *j) { while(j->pos<j->len && (j->data[j->pos]==' ' || j->data[j->pos]=='\n' || j->data[j->pos]=='\r' || j->data[j->pos]=='\t')) j->pos++; }
static int hex(int c) { if(c>='0'&&c<='9')return c-'0'; if(c>='a'&&c<='f')return c-'a'+10; if(c>='A'&&c<='F')return c-'A'+10; return -1; }
static int string_token(json *j) {
    if(j->pos>=j->len || j->data[j->pos++]!='"') return 0;
    while(j->pos<j->len) {
        unsigned char c=(unsigned char)j->data[j->pos++];
        if(c=='"') return 1;
        if(c<0x20) return 0;
        if(c=='\\') {
            if(j->pos>=j->len) return 0;
            c=(unsigned char)j->data[j->pos++];
            if(c=='u') { for(int k=0;k<4;k++) if(j->pos>=j->len || hex(j->data[j->pos++])<0) return 0; }
            else if(!strchr("\"\\/bfnrt",c)) return 0;
        }
    }
    return 0;
}
static int parse_value(json *j, int depth) {
    ws(j); if(depth>24 || j->pos>=j->len || j->nt>=TOKEN_LIMIT) {j->error=1;return -1;}
    int n=j->nt++; token *t=&j->t[n]; t->start=(int)j->pos; char c=j->data[j->pos];
    if(c=='{' || c=='[') {
        t->type=c=='{'?J_OBJ:J_ARR; char end=c=='{'?'}':']'; j->pos++; ws(j);
        if(j->pos<j->len && j->data[j->pos]==end) j->pos++;
        else for(;;) {
            if(c=='{') { ws(j); if(j->pos>=j->len || j->data[j->pos]!='"' || parse_value(j,depth+1)<0) {j->error=1;return -1;}
                ws(j); if(j->pos>=j->len || j->data[j->pos++]!=':') {j->error=1;return -1;} }
            if(parse_value(j,depth+1)<0) return -1;
            ws(j); if(j->pos>=j->len) {j->error=1;return -1;}
            char d=j->data[j->pos++]; if(d==end) break; if(d!=',') {j->error=1;return -1;}
        }
    } else if(c=='"') { t->type=J_STR; if(!string_token(j)) {j->error=1;return -1;} }
    else if(c=='-' || (c>='0'&&c<='9')) {
        t->type=J_NUM; if(c=='-') j->pos++;
        if(j->pos>=j->len || !isdigit((unsigned char)j->data[j->pos])) {j->error=1;return -1;}
        if(j->data[j->pos]=='0') j->pos++; else while(j->pos<j->len && isdigit((unsigned char)j->data[j->pos])) j->pos++;
        if(j->pos<j->len && j->data[j->pos]=='.') { j->pos++; if(j->pos>=j->len || !isdigit((unsigned char)j->data[j->pos])){j->error=1;return -1;} while(j->pos<j->len && isdigit((unsigned char)j->data[j->pos]))j->pos++; }
        if(j->pos<j->len && (j->data[j->pos]=='e'||j->data[j->pos]=='E')) {j->pos++;if(j->pos<j->len&&(j->data[j->pos]=='+'||j->data[j->pos]=='-'))j->pos++; if(j->pos>=j->len||!isdigit((unsigned char)j->data[j->pos])){j->error=1;return -1;} while(j->pos<j->len&&isdigit((unsigned char)j->data[j->pos]))j->pos++;}
    } else {
        const char *v=c=='t'?"true":c=='f'?"false":c=='n'?"null":NULL;
        size_t z=v?strlen(v):0; if(!v || j->pos+z>j->len || memcmp(j->data+j->pos,v,z)){j->error=1;return -1;} t->type=J_ATOM; j->pos+=z;
    }
    t->end=(int)j->pos; t->next=j->nt; return n;
}
static int keyeq(json *j,int n,const char *s) {
    token *t=&j->t[n]; size_t len=strlen(s);
    return t->type==J_STR && (size_t)(t->end-t->start)==len+2 && !memcmp(j->data+t->start+1,s,len);
}
static int member(json *j,int obj,const char *key) {
    if(obj<0 || j->t[obj].type!=J_OBJ) return -1;
    for(int k=obj+1;k<j->t[obj].next;) { int v=k+1; if(v>=j->t[obj].next)return -1; if(keyeq(j,k,key))return v; k=j->t[v].next; }
    return -1;
}
static int number(json *j,int n) {
    if(n<0 || (j->t[n].type!=J_NUM && j->t[n].type!=J_STR)) return -1;
    token *t=&j->t[n]; int a=t->start+(t->type==J_STR), b=t->end-(t->type==J_STR); unsigned v=0;
    if(a>=b) return -1;
    for(int k=a;k<b;k++){int c=j->data[k]; if(c<'0'||c>'9'||v>100000) return -1; v=v*10+(unsigned)(c-'0');}
    return v<=100000 ? (int)v : -1;
}
/* Decode JSON UTF-8 and escapes to UTF-16; reject malformed data/NUL. */
static u16 *text(json *j,int n) {
    if(n<0 || j->t[n].type!=J_STR) return NULL;
    token *t=&j->t[n]; size_t a=(size_t)t->start+1,b=(size_t)t->end-1, cap=b-a+1;
    if(cap>TEXT_LIMIT*4u+1) return NULL;
    u16 *out=malloc((cap+1)*sizeof(*out)); if(!out)return NULL; size_t k=0;
    while(a<b) {
        unsigned c=(unsigned char)j->data[a++], cp=c;
        if(c=='\\') {
            if(a>=b) goto bad; c=(unsigned char)j->data[a++];
            if(c=='u') { cp=0; for(int z=0;z<4;z++) {if(a>=b||hex(j->data[a])<0)goto bad;cp=(cp<<4)|(unsigned)hex(j->data[a++]);}
                if(cp>=0xd800 && cp<=0xdbff) { if(a+6>b || j->data[a]!='\\'||j->data[a+1]!='u') goto bad; a+=2;unsigned low=0;for(int z=0;z<4;z++){if(hex(j->data[a])<0)goto bad;low=(low<<4)|(unsigned)hex(j->data[a++]);}if(low<0xdc00||low>0xdfff)goto bad;cp=0x10000+((cp-0xd800)<<10)+(low-0xdc00); }
                else if(cp>=0xdc00&&cp<=0xdfff)goto bad;
            } else { switch(c) {case 'n':cp='\n';break;case 'r':cp='\r';break;case 't':cp='\t';break;case 'b':cp='\b';break;case 'f':cp='\f';break;case '"':case '\\':case '/':cp=c;break;default:goto bad;} }
        } else if(c>=0x80) {
            int more; unsigned min;
            if(c>=0xc2&&c<=0xdf){cp=c&31;more=1;min=0x80;}
            else if(c>=0xe0&&c<=0xef){cp=c&15;more=2;min=0x800;}
            else if(c>=0xf0&&c<=0xf4){cp=c&7;more=3;min=0x10000;}
            else goto bad;
            for(int z=0;z<more;z++){if(a>=b)goto bad;unsigned q=(unsigned char)j->data[a++];if((q&0xc0)!=0x80)goto bad;cp=(cp<<6)|(q&63);}
            if(cp<min || cp>0x10ffff || (cp>=0xd800&&cp<=0xdfff))goto bad;
        }
        if(!cp || k+2>TEXT_LIMIT)goto bad;
        if(cp>0xffff){cp-=0x10000;out[k++]=(u16)(0xd800+(cp>>10));out[k++]=(u16)(0xdc00+(cp&1023));}else out[k++]=(u16)cp;
    }
    out[k]=0; return out;
bad: free(out);return NULL;
}
static void put(u16 **slot,u16 *s) { if(s){free(*slot);*slot=s;} }
static void parse_menu(json *j) {
    int list=member(j,0,"entries"); if(list<0 || j->t[list].type!=J_ARR)return;
    for(int e=list+1;e<j->t[list].next;e=j->t[e].next){int id=number(j,member(j,e,"id"));if(id>=0&&id<SYS_LIMIT)put(&sys[id],text(j,member(j,e,"russian_draft")));}
}
static void parse_missions(json *j) {
    const char *names[]={"names","descriptions"};
    for(int kind=0;kind<2;kind++){int a=member(j,0,names[kind]); if(a<0||j->t[a].type!=J_ARR)continue;int i=0;for(int e=a+1;e<j->t[a].next&&i<36;e=j->t[e].next,i++)put(&mission[kind][i],text(j,e));}
}
static void parse_extra(json *j) {
    const char *names[]={"stage","item_name","item_info","file"};
    for(int kind=0;kind<4;kind++){int o=member(j,0,names[kind]);if(o<0||j->t[o].type!=J_OBJ)continue;for(int k=o+1;k<j->t[o].next;){int v=k+1,id=number(j,k);if(id>=0&&id<130)put(&extra[kind][id],text(j,v));k=j->t[v].next;}}
}
static void parse_story(json *j) {
    if(j->t[0].type!=J_OBJ)return;
    for(int k=1;k<j->t[0].next;){int v=k+1;u16 *en=text(j,k);if(en){int id=ru_story_index(en);if(id>=0&&id<STORY_LIMIT)put(&story[id],text(j,v));free(en);}k=j->t[v].next;}
}
static void load(int type) {
    if(loaded[type])return;loaded[type]=1;
    const char *names[]={"ru_menu_draft.json","ru_missions.json","ru_extra.json","ru_story.json","language.json"};
    char path[512]; snprintf(path,sizeof path,"%s/localization/%s",rt_home_dir,names[type]);
    FILE *f=fopen(path,"rb"); if(!f)return;
    if(fseek(f,0,SEEK_END)!=0){fclose(f);return;}long len=ftell(f);if(len<0||(unsigned long)len>FILE_LIMIT||fseek(f,0,SEEK_SET)!=0){fclose(f);return;}
    json j={0};j.len=(size_t)len;j.data=malloc(j.len+1);j.t=malloc(TOKEN_LIMIT*sizeof(*j.t));
    if(!j.data||!j.t||fread(j.data,1,j.len,f)!=j.len){fclose(f);free(j.data);free(j.t);return;}fclose(f);j.data[j.len]=0;
    if(j.len>=3 && (unsigned char)j.data[0]==0xef && (unsigned char)j.data[1]==0xbb && (unsigned char)j.data[2]==0xbf)j.pos=3;
    int root=parse_value(&j,0);ws(&j);
    if(root==0&&!j.error&&j.pos==j.len&&j.t[0].type==J_OBJ){
        if(type==0)parse_menu(&j);else if(type==1)parse_missions(&j);else if(type==2)parse_extra(&j);else if(type==3)parse_story(&j);else {put(&language_name,text(&j,member(&j,0,"name")));put(&language_name_en,text(&j,member(&j,0,"name_en")));}
        rt_log("[ru] external translations loaded: %s",names[type]);
    } else rt_log("[ru] invalid translation file: %s (using built-in)",names[type]);
    free(j.data);free(j.t);
}
static u32 guest(u16 *s,u32 *cache) {
    if(!s)return 0;if(*cache)return *cache;unsigned n=0;while(s[n])n++;
    u32 p=gmalloc((n+2)*2);if(!p)return 0;for(unsigned i=0;i<=n;i++)WR16(p+2*i,s[i]);WR16(p+2*(n+1),0);return *cache=p;
}
u32 ru_external_sys(u32 id){if(id>=SYS_LIMIT)return 0;load(0);return guest(sys[id],&sys_cache[id]);}
u32 ru_external_mission(u32 kind,u32 id){if(kind>1||id>=36)return 0;load(1);return guest(mission[kind][id],&mission_cache[kind][id]);}
u32 ru_external_extra(u32 kind,u32 id){if(kind>3||id>=130)return 0;load(2);return guest(extra[kind][id],&extra_cache[kind][id]);}
u32 ru_external_story(u32 id){if(id>=STORY_LIMIT)return 0;load(3);return guest(story[id],&story_cache[id]);}

u32 ru_external_language_name(void){load(4);return guest(language_name,&language_name_cache);}

u32 ru_external_language_name_en(void){load(4);return guest(language_name_en,&language_name_en_cache);}
