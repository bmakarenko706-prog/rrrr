#ifndef RC_TABLES_H
#define RC_TABLES_H
#include "recomp.h"
typedef struct { u32 addr; rc_fn fn; } rc_func_entry;
typedef struct { const char *name; rc_fn fn; } rc_import_entry;
typedef struct { u32 addr; u16 imp; u16 kind; } rc_bind_entry;
typedef struct { const char *name; u32 addr, size, off, fsize; } rc_seg_entry;
typedef struct { const char *name; u32 addr; } rc_sym_entry;
extern const rc_func_entry rc_funcs[]; extern const u32 rc_nfuncs;
extern const rc_import_entry rc_imports[]; extern const u32 rc_nimports;
extern const rc_bind_entry rc_binds[]; extern const u32 rc_nbinds;
extern const u32 rc_mod_init[]; extern const u32 rc_nmod_init;
extern const rc_seg_entry rc_segs[]; extern const u32 rc_nsegs;
extern const rc_sym_entry rc_datasyms[]; extern const u32 rc_ndatasyms;
extern const u32 rc_main_addr;
extern const u32 rc_text_lo, rc_text_hi;
#endif
