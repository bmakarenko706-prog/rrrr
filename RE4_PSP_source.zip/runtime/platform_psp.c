/* PSP platform layer: module setup, guest memory, buttons -> virtual touches, audio output, timing, settings.
   Files next to EBOOT.PBP:  Res4.app/ (the contents of the user's IPA, including the Res4 binary),
   Documents/ (saves, created on first run), config.txt (optional settings and button mapping), re4log.txt. */
#include "rt.h"
#include "platform.h"
#include "psp_glue.h"
#include "weapon_hold.h"
#include "stick_movement.h"
#include "language.h"
#include "manual.h"
#include "intro.h"
#include "psp_movie.h"
#include <pspkernel.h>
#include <pspiofilemgr.h>
#include <pspctrl.h>
#include <pspaudio.h>
#include <psppower.h>
#include <pspdisplay.h>
#include <pspdebug.h>
#include <pspgu.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

PSP_MODULE_INFO("Resident Evil 4", PSP_MODULE_USER, 1, 0);
PSP_MAIN_THREAD_ATTR(PSP_THREAD_ATTR_USER | PSP_THREAD_ATTR_VFPU);
PSP_MAIN_THREAD_STACK_SIZE_KB(256);  /* the game runs here; PPSSPP measured < 16 KB used */
PSP_HEAP_SIZE_KB(1024);          /* host-side heap (~320 KB used); the game's own memory is one separate kernel block */

int rt_main(int argc, char **argv, u32 mem_size);
void music_mix(s32 *acc, int n);
void music_init(void);
void music_shutdown(void);
extern char rt_home_dir[256];
extern int gl_log;
extern u32 heap_log_min;

int psp_stretch = 0, psp_tex_limit = 512, psp_vsync = 1, psp_cursor_on;
static int tex_limit_set, tex_limit_pal_set, tex_limit_pal_value;
int psp_tex_limit_pal = 512;   /* paletted textures (UI, fonts) are 8 bits per texel: they keep 512 on the PSP-1000 */
float psp_cursor_x = 240, psp_cursor_y = 160;

#ifdef RE4_PSPLINK
static char base_dir[256] = "ms0:/PSP/GAME/RE4ME";
#else
static char base_dir[256] = "ms0:/PSP/GAME/RE4_RU";
#endif
static volatile int quit_req;
static volatile int home_exit_requested;
static SceUID audio_th = -1;
#ifdef RE4_PSPLINK
/* Leave space for PSPLINK/USB/GDB allocations on real hardware. */
static int cpu_mhz = 333, log_to_file = 0, mem_reserve_kb = 2048;
#else
static int cpu_mhz = 333, log_to_file = 0, mem_reserve_kb = 128;
#endif

/* ---------- settings: config.txt, "key = value" lines, '#' comments */
enum { B_CROSS, B_CIRCLE, B_SQUARE, B_TRIANGLE, B_START, B_SELECT, B_L, B_R, B_UP, B_DOWN, B_LEFT, B_RIGHT, NB };
static const char *bname[NB] = {"cross", "circle", "square", "triangle", "start", "select", "l", "r", "up", "down", "left", "right"};
static const u32 bmask[NB] = {PSP_CTRL_CROSS, PSP_CTRL_CIRCLE, PSP_CTRL_SQUARE, PSP_CTRL_TRIANGLE, PSP_CTRL_START, PSP_CTRL_SELECT,
    PSP_CTRL_LTRIGGER, PSP_CTRL_RTRIGGER, PSP_CTRL_UP, PSP_CTRL_DOWN, PSP_CTRL_LEFT, PSP_CTRL_RIGHT};
enum { A_NONE, A_TAP, A_STICK, A_SWIPE, A_CURSOR, A_GUN, A_KNIFE, A_MAIN, A_ASH };
typedef struct { int act; float x, y; } bind;
/* defaults: touch points of the game's on-screen controls in landscape coordinates (480x320) */
static bind binds[NB] = {
    {A_MAIN, 0, 0},      /* cross: fire / knife attack when a weapon is out, otherwise action, pick up, QTE, "next" */
    {A_ASH, 373, 209},   /* circle: Ashley command when available, otherwise action */
    {A_TAP, 411, 283},   /* square: knife */
    {A_TAP, 40, 29},     /* triangle: status screen */
    {A_TAP, 40, 285},    /* start: skip / menu */
    {A_NONE, 0, 0},      /* cursor follows menu tasks; SELECT does not toggle it */
    {A_KNIFE, 445, 285}, /* l: hold knife; outside gameplay taps here ("next") */
    {A_GUN, 0, 0},       /* r: hold gun; outside gameplay r + stick drags */
    {A_STICK, 0, -1}, {A_STICK, 0, 1}, {A_STICK, -1, 0}, {A_STICK, 1, 0}};
/* pointer mode (menus): buttons with a menu binding tap there instead; cross taps at the cursor */
static bind binds_menu[NB] = {
    [B_CIRCLE] = {A_TAP, 40, 240},   /* the back arrow of the menus (left edge) */
};
static float joy_x = 76, joy_y = 249, joy_r = 40, swipe_speed = 420, cursor_speed = 300;
/* scripted touches for testing: taps = t:x,y[:dur];...  (landscape coordinates, seconds since start) */
typedef struct { float t, dur, x, y; } tap;
static tap taps[64]; static int ntaps;
static void parse_taps(const char *s) {
    ntaps = 0;
    while (s && *s && ntaps < 64) {
        tap *t = &taps[ntaps];
        t->dur = 0.15f;
        int n = 0;
        if (sscanf(s, "%f:%f,%f%n", &t->t, &t->x, &t->y, &n) < 3) break;
        s += n;
        if (*s == ':') { s++; n = 0; sscanf(s, "%f%n", &t->dur, &n); s += n; }
        ntaps++;
        while (*s == ';' || *s == ' ') s++;
    }
}
static int deadzone = 32;

static char *trim(char *s) {
    while (isspace((unsigned char)*s)) s++;
    char *e = s + strlen(s);
    while (e > s && isspace((unsigned char)e[-1])) *--e = 0;
    return s;
}
static void load_config(void) {
    char path[300];
    snprintf(path, sizeof path, "%s/config.txt", base_dir);
    FILE *f = fopen(path, "r");
    if (!f) return;
    static char line[1024];
    while (fgets(line, sizeof line, f)) {
        char *h = strchr(line, '#'); if (h) *h = 0;
        char *eq = strchr(line, '='); if (!eq) continue;
        *eq = 0;
        char *k = trim(line), *v = trim(eq + 1);
        for (char *p = k; *p; p++) *p = (char)tolower((unsigned char)*p);
        if (!strcmp(k, "stretch")) psp_stretch = atoi(v);
        else if (!strcmp(k, "vsync")) psp_vsync = atoi(v);
        else if (!strcmp(k, "cpu")) cpu_mhz = atoi(v);
        else if (!strcmp(k, "log")) log_to_file = atoi(v);
        else if (!strcmp(k, "verbose")) rt_verbose = atoi(v);
        else if (!strcmp(k, "logtime")) { extern int rt_log_time; rt_log_time = atoi(v); }
        else if (!strcmp(k, "gllog")) gl_log = atoi(v);
        else if (!strcmp(k, "gldbg")) { extern int gl_dbg; gl_dbg = atoi(v); }
        else if (!strcmp(k, "gllog_at")) { extern int gl_log_at, gl_log_n; if (sscanf(v, "%d , %d", &gl_log_at, &gl_log_n) < 2) gl_log_n = 1; }
        else if (!strcmp(k, "texture_limit")) { psp_tex_limit = atoi(v); tex_limit_set = 1; }
        else if (!strcmp(k, "texture_limit_pal")) { tex_limit_pal_value = atoi(v); tex_limit_pal_set = 1; }
        else if (!strcmp(k, "memory_reserve_kb")) mem_reserve_kb = atoi(v);
        else if (!strcmp(k, "alloclog")) heap_log_min = (u32)atoi(v);
        else if (!strcmp(k, "deadzone")) deadzone = atoi(v);
        else if (!strcmp(k, "taps")) parse_taps(v);
        else if (!strcmp(k, "joystick")) sscanf(v, "%f , %f , %f", &joy_x, &joy_y, &joy_r);
        else if (!strcmp(k, "swipe_speed")) swipe_speed = (float)atof(v);
        else if (!strcmp(k, "cursor_speed")) cursor_speed = (float)atof(v);
        else for (int b = 0; b < NB; b++) if (!strcmp(k, bname[b]) || (!strncmp(k, "menu_", 5) && !strcmp(k + 5, bname[b]))) {
            bind *d = k[0] == 'm' && k[1] == 'e' ? &binds_menu[b] : &binds[b];
            if (!strncmp(v, "none", 4)) d->act = A_NONE;
            else if (!strncmp(v, "swipe", 5)) d->act = A_SWIPE;
            else if (!strncmp(v, "cursor", 6)) d->act = A_CURSOR;
            else if (!strncmp(v, "gun", 3)) d->act = A_GUN;
            else if (!strncmp(v, "knife", 5)) { d->act = A_KNIFE; if (sscanf(v + 5, " , %f , %f", &d->x, &d->y) != 2) d->x = d->y = 0; }
            else if (!strncmp(v, "main", 4)) d->act = A_MAIN;
            else if (!strncmp(v, "ash", 3)) { d->act = A_ASH; if (sscanf(v + 3, " , %f , %f", &d->x, &d->y) != 2) { d->x = 373; d->y = 209; } }
            else if (!strncmp(v, "stick", 5)) d->act = A_STICK;    /* keeps the default direction */
            else if (sscanf(v, "%f , %f", &d->x, &d->y) == 2) d->act = A_TAP;
        }
    }
    fclose(f);
}

/* ---------- exit / power callbacks */
/* Best-effort, bounded diagnostics on the main thread; independent of stdio
   redirection and the user's ordinary log setting. Never use in the callback. */
static void exit_trace_init(void) {
    char path[300]; snprintf(path, sizeof path, "%s/re4_exit_debug.log", base_dir);
    SceUID fd = sceIoOpen(path, PSP_O_WRONLY | PSP_O_CREAT | PSP_O_TRUNC, 0777);
    if (fd >= 0) { const char msg[] = "RE4 exit diagnostics: started\n";
        sceIoWrite(fd, msg, sizeof msg - 1); sceIoClose(fd); }
}
void plat_exit_trace(const char *step) {
    char path[300]; snprintf(path, sizeof path, "%s/re4_exit_debug.log", base_dir);
    SceUID fd = sceIoOpen(path, PSP_O_WRONLY | PSP_O_CREAT | PSP_O_APPEND, 0777);
    if (fd >= 0) { sceIoWrite(fd, step, strlen(step)); sceIoWrite(fd, "\n", 1); sceIoClose(fd); }
}
static int exit_cb(int a, int b, void *c) {
    (void)a; (void)b; (void)c;
    home_exit_requested = 1;
    quit_req = 1;
    /* Give the game a bounded opportunity to stop and save; this callback is
       the sole normal exit owner for HOME. If cleanup stalls, force exit. */
    for (int i = 0; i < 500 && quit_req != 2; i++) sceKernelDelayThread(10000);
    sceKernelExitGame();
    return 0;
}
static void finish_platform_exit(void) {
    plat_exit_trace("platform: ready to exit");
    if (home_exit_requested) {
        quit_req = 2; /* hand control to the callback, rather than race it */
        sceKernelDelayThread(1000000); /* fallback only if callback didn't exit */
    } else quit_req = 2;
    sceKernelExitGame();
}
static int cb_thread(SceSize args, void *argp) {
    (void)args; (void)argp;
    int cb = sceKernelCreateCallback("re4 exit", exit_cb, NULL);
    sceKernelRegisterExitCallback(cb);
    sceKernelSleepThreadCB();
    return 0;
}

/* ---------- timing */
static u64 t0;
u64 plat_time_us(void) { return sceKernelGetSystemTimeWide() - t0; }
void plat_sleep_us(u32 us) { sceKernelDelayThread(us ? us : 1); }

/* ---------- fatal errors: show the message instead of returning to the menu silently */
void plat_fatal(const char *msg) {
    sceGuDisplay(GU_FALSE);
    pspDebugScreenInit();
    pspDebugScreenSetXY(0, 2);
    pspDebugScreenPrintf("  Resident Evil 4 - error\n\n  %s\n\n  Press X to exit.", msg);
    SceCtrlData pad;
    for (int i = 0; i < 6000; i++) {      /* up to 60 seconds */
        sceCtrlReadBufferPositive(&pad, 1);
        if (pad.Buttons & PSP_CTRL_CROSS) break;
        sceKernelDelayThread(10000);
    }
    sceKernelExitGame();
}

/* ---------- audio: the game renders at 11025 Hz into a ring; the audio thread resamples to 44.1 kHz and adds music */
#define RING 8192
#define OUT_N 2048
static s16 ring[RING * 2];
static volatile u32 r_head, r_tail;      /* written by the main thread / by the audio thread */
static int a_rate = 11025, a_ch = -1;
static int audio_src;                    /* SRC output reserved with explicit 44100 Hz */
static volatile int a_open;
/* Only the audio thread moves the consumer pointer. A new RemoteIO start
   asks the consumer to discard old samples; it must not race r_tail. */
static volatile u32 a_reset;
static volatile u32 audio_output_errors;
volatile u32 audio_busy_us;    /* audio thread time spent mixing (verbose stats) */
static int audio_thread(SceSize args, void *argp) {
    (void)args; (void)argp;
    static s16 out[2][OUT_N * 2] __attribute__((aligned(64)));
    static s32 acc[OUT_N * 2];
    s16 prev[2] = {0, 0}, cur[2] = {0, 0};
    u32 phase = 0x10000;
    int bi = 0, primed = 0;
    u32 seen_reset = 0;
    while (!quit_req) {
        u64 ta = plat_time_us();
        memset(acc, 0, sizeof acc);
        if (a_open && !movie_music_active()) {
            u32 reset = a_reset;
            if (reset != seen_reset) {
                r_tail = r_head;
                seen_reset = reset; primed = 0; phase = 0x10000;
                prev[0] = prev[1] = cur[0] = cur[1] = 0;
            }
            /* Build a small cushion after a start or underrun instead of
               alternately emitting a few samples and decaying to silence. */
            if (!primed && r_head - r_tail >= (u32)(a_rate / 8)) primed = 1;
            u32 step = (u32)(((u64)a_rate << 16) / 44100);
            for (int i = 0; i < OUT_N && primed; i++) {
                while (phase >= 0x10000) {
                    phase -= 0x10000;
                    prev[0] = cur[0]; prev[1] = cur[1];
                    u32 t = r_tail;
                    if (t != r_head) { cur[0] = ring[2 * (t % RING)]; cur[1] = ring[2 * (t % RING) + 1]; r_tail = t + 1; }
                    else { cur[0] = (s16)(cur[0] * 7 / 8); cur[1] = (s16)(cur[1] * 7 / 8);
                           /* Let the producer refill before consuming again. */
                           if (cur[0] == 0 && cur[1] == 0) primed = 0; }
                }
                s32 f = (s32)(phase >> 1);
                acc[2 * i] = prev[0] + (((cur[0] - prev[0]) * f) >> 15);
                acc[2 * i + 1] = prev[1] + (((cur[1] - prev[1]) * f) >> 15);
                phase += step;
            }
        }
        music_mix(acc, OUT_N);
        s16 *o = out[bi]; bi ^= 1;
        for (int i = 0; i < OUT_N * 2; i++) {
            /* Headroom for overlapping effects and music. */
            s32 v = acc[i] * 3 / 4;
            o[i] = (s16)(v > 32767 ? 32767 : v < -32768 ? -32768 : v);
        }
        audio_busy_us += (u32)(plat_time_us() - ta);
        /* Hand off a coherent, 64-byte-aligned buffer; it isn't reused until
           the blocking call has accepted the alternating buffer. */
        sceKernelDcacheWritebackRange(o, OUT_N * 2 * sizeof(*o));
        int r = audio_src ? sceAudioSRCOutputBlocking(PSP_AUDIO_VOLUME_MAX, o)
                          : sceAudioOutputPannedBlocking(a_ch, PSP_AUDIO_VOLUME_MAX, PSP_AUDIO_VOLUME_MAX, o);
        if (r < 0) {
            audio_output_errors++;
            if (audio_output_errors == 1 || (audio_output_errors & 255) == 0)
                rt_log("[psp] audio output error %08x (count %u)", (u32)r, audio_output_errors);
            /* Never let a failed high-priority output spin and starve the game. */
            sceKernelDelayThread(OUT_N * 1000000u / 44100u);
        }
    }
    return 0;
}
void plat_audio_open(int rate) {
    a_rate = rate > 0 ? rate : 11025;
    a_reset++;
    a_open = 1;
    rt_log("[psp] game audio %d Hz", a_rate);
}
int plat_audio_space(void) {
    if (!a_open) return 0;
    u32 queued = r_head - r_tail;
    int target = a_rate * 3 / 10;                 /* keep ~300 ms queued */
    int space = target - (int)queued;
    if (space > (int)(RING - queued - 1)) space = (int)(RING - queued - 1);
    return space > 0 ? space : 0;
}
void plat_audio_write(const s16 *frames, int n) {
    u32 h = r_head;
    for (int i = 0; i < n; i++, h++) { ring[2 * (h % RING)] = frames[2 * i]; ring[2 * (h % RING) + 1] = frames[2 * i + 1]; }
    r_head = h;
}

/* ---------- input: analog stick = movement pad, buttons = taps on the game's on-screen controls.
   The game follows at most three fingers: finger 0 is the movement pad, fingers 1-2 go to the other touch sources
   (held buttons, the drag, pointer taps, scripted taps) in the order they start. */
static void land2port(float X, float Y, plat_touch *t) { t->down = 1; t->x = 320 - Y; t->y = X; }
#define SRC_SWIPE NB
#define SRC_CURSOR (NB + 1)
#define SRC_SCRIPT (NB + 2)
#define SRC_WEAPON (NB + 3)
#define NSRC (NB + 4)
/* Classification is scoped to a single onTick, so disappearing tasks cannot
   leave the pointer enabled in the title, loading or gameplay states. */
static int ui_tick_open, ui_tick_menu, ui_tick_language;
int psp_language_menu_on, psp_language_save_failed;
void psp_ui_tick_begin(void) { ui_tick_open = 1; ui_tick_menu = 0; ui_tick_language = 0; }
void psp_ui_tick_note(unsigned int target) {
    if (ui_tick_open) { ui_tick_menu = 1; if (target == 0x87fdc) ui_tick_language = 1; }
}
void psp_ui_tick_end(void) {
    if (ui_tick_open) { psp_cursor_on = ui_tick_menu; psp_language_menu_on = ui_tick_language; }
    ui_tick_open = 0;
}
static int joy_down, swipe_down, finger_src[3] = {-1, -1, -1};
static float swipe_x, swipe_y;
static u32 prev_buttons;
static u32 transition_blocked;
static u64 last_poll;
/* ---------- game UI state, read from guest memory: the in-game touch buttons (GM_CtrlLyt_Input) and the
   message / item windows. A button's touch point is the centre of its layout rectangle. */
static int gok(u32 a) { return a >= 0x1000 && a < MEM_SIZE - 256; }
enum { W_IN, W_ITEM, W_NORM, W_EVT, NW };
static const u32 win_ptr[NW] = {0xdd750u, 0xddd98u, 0xddd9cu, 0xddd90u};   /* non-lazy pointers to the instances */
static const u8 win_on[NW] = {60, 32, 24, 28};                              /* "active" flag of each layout */
/* GM_CtrlLyt_Input components */
enum { IN_POST = 8, IN_EVE = 12, IN_ASH = 16, IN_WEP = 20, IN_KNIFE = 24 };
/* window components */
enum { WI_NEXT = 8, WI_USE = 12, WI_GET = 16, WI_CANCEL = 20, WN_NEXT = 8, WE_NEXT = 8 };
/* a component is on screen when it and every ancestor are enabled for drawing (flag +81, as LYT_CmpProduct::Draw
   checks); children: pointer array at +12, count at +24. Roots: GM_CtrlLyt_Input +0, the windows +4. */
static int ui_drawn(u32 node, u32 target, int depth) {
    if (!gok(node) || !RD8(node + 81)) return 0;
    if (node == target) return 1;
    if (depth > 8) return 0;
    u32 arr = RD32(node + 12), n = RD32(node + 24);
    if (!gok(arr) || n > 64) return 0;
    for (u32 i = 0; i < n; i++) if (ui_drawn(RD32(arr + 4 * i), target, depth + 1)) return 1;
    return 0;
}
#define UI_LAYOUT_PTR 0xdd740u   /* GM_CtrlLayout: +76 is the window on screen (1 message, 2 item, 3 event) */
static u32 ui_comp(int w, int off) {
    static const u8 mode[NW] = {0, 2, 1, 3};
    u32 inst = RD32(win_ptr[w]), lay = RD32(UI_LAYOUT_PTR);
    if (!gok(inst) || !RD8(inst + win_on[w])) return 0;
    if (w != W_IN && (!gok(lay) || RD32(lay + 76) != mode[w])) return 0;
    u32 c = RD32(inst + off);
    if (!gok(c) || !gok(RD32(c + 8)) || !RD8(c + 80)) return 0;
    return ui_drawn(RD32(inst + (w == W_IN ? 0 : 4)), c, 0) ? c : 0;
}
static int ui_active(u32 c) { u32 h = RD32(c + 144); return gok(h) && RD8(h + 81); }   /* action button highlighted */
static int ui_point(u32 c, float *x, float *y) {
    u32 nd = RD32(c + 8);
    s16 w = (s16)RD16(nd + 20), h = (s16)RD16(nd + 22);
    if (w <= 0 || h <= 0) return 0;
    *x = (s16)RD16(nd + 16) + w * 0.5f; *y = (s16)RD16(nd + 18) + h * 0.5f;
    return 1;
}
typedef struct { u32 post, eve, ash, wep, knife, next, get, use, cancel; int gun_out, knife_out, next_w; } ui_state;
static void ui_read(ui_state *u) {
    memset(u, 0, sizeof *u);
    u->post = ui_comp(W_IN, IN_POST); u->eve = ui_comp(W_IN, IN_EVE); u->ash = ui_comp(W_IN, IN_ASH);
    u->wep = ui_comp(W_IN, IN_WEP); u->knife = ui_comp(W_IN, IN_KNIFE);
    u->gun_out = u->wep && ui_active(u->wep);
    u->knife_out = u->knife && ui_active(u->knife);
    u->get = ui_comp(W_ITEM, WI_GET);
    u->use = ui_comp(W_ITEM, WI_USE);
    u->cancel = ui_comp(W_ITEM, WI_CANCEL);
    u->next = ui_comp(W_ITEM, WI_NEXT); u->next_w = W_ITEM;
    if (!u->next) { u->next = ui_comp(W_NORM, WN_NEXT); u->next_w = W_NORM; }
    if (!u->next) { u->next = ui_comp(W_EVT, WE_NEXT); u->next_w = W_EVT; }
}
static void ui_debug(const ui_state *u) {
    static char last[64];
    char cur[64];
    snprintf(cur, sizeof cur, "post=%d eve=%d ash=%d gun=%d%d knife=%d%d next=%d get=%d", !!u->post, !!u->eve, !!u->ash, !!u->wep, u->gun_out,
             !!u->knife, u->knife_out, u->next ? u->next_w : 0, !!u->get);
    if (strcmp(cur, last)) {
        strcpy(last, cur); rt_log("[ui] %s", cur);
    }
}
/* what L (knife), R (gun) and X (main) touch right now; 0 = nothing in the game UI (use the fallback) */
static u32 ui_target(int act, const ui_state *u) {
    switch (act) {
    case A_ASH: return u->ash;                                               /* command Ashley when button is visible */
    case A_GUN: return !u->wep ? 0 : u->gun_out ? u->post : u->wep;          /* ready, or lower when already out */
    case A_KNIFE:
        if (u->next) return u->next;                                         /* a message is waiting: "next" */
        return !u->knife ? 0 : u->knife_out ? u->post : u->knife;
    case A_MAIN:
        if (u->get) return u->get;                                           /* item window: pick up */
        if (u->next) return u->next;                                         /* message: "next" */
        if (u->gun_out) return u->wep;                                       /* fire */
        if (u->knife_out) return u->knife;                                   /* knife attack */
        return u->eve;                                                       /* action / QTE */
    }
    return 0;
}

static float clampf(float v, float lo, float hi) { return v < lo ? lo : v > hi ? hi : v; }
int plat_poll(plat_input *in) {
    memset(in, 0, sizeof *in);
    if (quit_req) return PLAT_QUIT;
    SceCtrlData pad;
    sceCtrlPeekBufferPositive(&pad, 1);
    u64 now = plat_time_us();
    float dt = last_poll ? (now - last_poll) / 1e6f : 0;
    if (dt > 0.1f) dt = 0.1f;
    last_poll = now;
    /* The manual consumes pad events; release the button that opened it. */
    static int manual_was_open;
    static u32 manual_blocked, manual_previous;
    if (manual_is_open()) {
        if (!manual_was_open) {
            manual_was_open = 1;
            manual_blocked = pad.Buttons;
            manual_previous = 0;
            joy_down = swipe_down = 0;
            finger_src[1] = finger_src[2] = -1;
        }
        manual_blocked &= pad.Buttons;
        u32 buttons = pad.Buttons & ~manual_blocked;
        manual_handle(buttons & ~manual_previous);
        manual_previous = buttons;
        prev_buttons = pad.Buttons;
        return PLAT_RUN;
    }
    /* Held controls must be released before being reused in a new mode. */
    static int last_cursor_mode;
    int manual_closed = manual_was_open;
    if (manual_closed) {
        transition_blocked |= pad.Buttons;
        manual_was_open = 0;
        joy_down = swipe_down = 0;
        finger_src[1] = finger_src[2] = -1;
    }
    if (last_cursor_mode != psp_cursor_on) {
        transition_blocked |= pad.Buttons;
        last_cursor_mode = psp_cursor_on;
    }
    transition_blocked &= pad.Buttons;
    /* Opening or closing the pickup choices also requires release.  A held
       X/O/square must never leak into a different screen or action. */
    ui_state u;
    ui_read(&u);
    int pickup_choices = !psp_cursor_on && (u.get || u.use || u.cancel);
    static int last_pickup_choices;
    if (last_pickup_choices != pickup_choices) {
        transition_blocked |= pad.Buttons & (PSP_CTRL_CROSS | PSP_CTRL_CIRCLE | PSP_CTRL_SQUARE);
        last_pickup_choices = pickup_choices;
    }
    u32 b = pad.Buttons & ~transition_blocked, pressed = b & ~prev_buttons;
    prev_buttons = b;
    /* stick (and d-pad bindings) as a direction in [-1, 1] */
    float sx = 0, sy = 0;
    int ax = pad.Lx - 128, ay = pad.Ly - 128;
    if (ax * ax + ay * ay > deadzone * deadzone) { sx = clampf(ax / 127.f, -1, 1); sy = clampf(ay / 127.f, -1, 1); }
    for (int i = 0; i < NB; i++) if (!(pickup_choices && (i == B_CIRCLE || i == B_SQUARE)) && (b & bmask[i]) && binds[i].act == A_STICK) { sx = clampf(sx + binds[i].x, -1, 1); sy = clampf(sy + binds[i].y, -1, 1); }
    int moving = sx != 0 || sy != 0, swiping = 0;
    if (rt_verbose > 1) ui_debug(&u);
    /* Hold-to-ready for weapon bindings. Game UI itself is tap/toggle based, so
       use short touch pulses and follow the actual highlighted weapon state. */
    static float hold_x[NB], hold_y[NB], weapon_x, weapon_y;
    static u64 pulse_end[NB];
    static u8 holding[NB], r_swipe[NB], weapon_mode[NB];
    static int preferred = -1;
    static weapon_hold weapon;
    static int prev_weapon_cursor;
    if (prev_weapon_cursor != psp_cursor_on || manual_closed) {
        memset(holding, 0, sizeof holding);
        memset(r_swipe, 0, sizeof r_swipe);
        memset(weapon_mode, 0, sizeof weapon_mode);
        memset(&weapon, 0, sizeof weapon);
        preferred = -1;
        prev_weapon_cursor = psp_cursor_on;
        swipe_down = joy_down = 0;
    }
    for (int i = 0; i < NB; i++) {
        int a = binds[i].act;
        if (pickup_choices && (i == B_CIRCLE || i == B_SQUARE)) {
            holding[i] = r_swipe[i] = weapon_mode[i] = 0;
            continue;
        }
        if (a != A_GUN && a != A_KNIFE && a != A_MAIN && a != A_ASH) continue;
        if (pressed & bmask[i]) {
            holding[i] = r_swipe[i] = weapon_mode[i] = 0;
            if ((a == A_GUN || a == A_KNIFE) && !psp_cursor_on && !u.next &&
                (a == A_GUN ? u.wep : u.knife)) {
                weapon_mode[i] = 1; preferred = i; weapon.owned = 1;
            } else {
                u32 c = psp_cursor_on ? 0 : ui_target(a, &u);
                if (c && ui_point(c, &hold_x[i], &hold_y[i])) holding[i] = 1;
                else if ((a == A_KNIFE || (a == A_ASH && !psp_cursor_on)) && (binds[i].x || binds[i].y)) { hold_x[i] = binds[i].x; hold_y[i] = binds[i].y; holding[i] = 1; }
                else if (a == A_GUN) r_swipe[i] = 1;
                if (holding[i] && a != A_MAIN && a != A_ASH) pulse_end[i] = now + 120000;
            }
            if (rt_verbose > 1) rt_log("[pad] %s -> %s %.0f,%.0f", bname[i], weapon_mode[i] ? "hold weapon" : holding[i] ? "tap" : r_swipe[i] ? "swipe" : "none", hold_x[i], hold_y[i]);
        }
        if (!(b & bmask[i])) { r_swipe[i] = 0; weapon_mode[i] = 0; }
        if (a != A_MAIN && a != A_ASH && holding[i] && now >= pulse_end[i]) holding[i] = 0;
        if ((a == A_MAIN || a == A_ASH) && !(b & bmask[i])) holding[i] = 0;
        if (r_swipe[i]) swiping = 1;
    }
    if (preferred < 0 || !weapon_mode[preferred]) {
        preferred = -1;
        for (int i = 0; i < NB; i++) if (weapon_mode[i]) { preferred = i; break; }
    }
    int desired = preferred < 0 ? WH_NONE : binds[preferred].act == A_GUN ? WH_GUN : WH_KNIFE;
    int step = wh_decide(&weapon, now, !psp_cursor_on && !pickup_choices && !u.next, desired,
                         !!u.wep, !!u.knife, !!u.post, u.gun_out, u.knife_out);
    u32 target = step == WH_GUN ? u.wep : step == WH_KNIFE ? u.knife : step == WH_LOWER ? u.post : 0;
    if (target && ui_point(target, &weapon_x, &weapon_y)) {
        wh_begin(&weapon, now);
        if (rt_verbose > 1) rt_log("[pad] weapon %s %.0f,%.0f", step == WH_GUN ? "gun" : step == WH_KNIFE ? "knife" : "lower", weapon_x, weapon_y);
    }
    for (int i = 0; i < NB; i++) {
        if (!(pickup_choices && (i == B_CIRCLE || i == B_SQUARE)) && binds[i].act == A_SWIPE && (b & bmask[i])) swiping = 1;
    }
    /* active touch sources and their points */
    static float sxp[NSRC], syp[NSRC];
    int act[NSRC] = {0};
    if (!psp_cursor_on && !pickup_choices && now < weapon.pulse_end) { act[SRC_WEAPON] = 1; sxp[SRC_WEAPON] = weapon_x; syp[SRC_WEAPON] = weapon_y; }
    if (psp_cursor_on) {
        psp_cursor_x = clampf(psp_cursor_x + sx * cursor_speed * dt, 0, 479);
        psp_cursor_y = clampf(psp_cursor_y + sy * cursor_speed * dt, 0, 319);
        if (b & PSP_CTRL_CROSS) { act[SRC_CURSOR] = 1; sxp[SRC_CURSOR] = psp_cursor_x; syp[SRC_CURSOR] = psp_cursor_y; }
        moving = 0;
    } else if (swiping) {
        if (!swipe_down) { swipe_x = 240; swipe_y = 160; swipe_down = 1; }
        else { swipe_x = clampf(swipe_x + sx * swipe_speed * dt, 0, 479); swipe_y = clampf(swipe_y + sy * swipe_speed * dt, 0, 319); }
        act[SRC_SWIPE] = 1; sxp[SRC_SWIPE] = swipe_x; syp[SRC_SWIPE] = swipe_y;
        moving = 0;
    } else swipe_down = 0;
    for (int i = 0; i < NB; i++) {
        if (pickup_choices && (i == B_CIRCLE || i == B_SQUARE)) {
            /* Route only to an actually visible, enabled item-window control.
               With no Use button square must do nothing, not swing the knife. */
            u32 c = i == B_CIRCLE ? u.cancel : u.use;
            if ((b & bmask[i]) && c && ui_point(c, &sxp[i], &syp[i])) act[i] = 1;
            continue;
        }
        const bind *d = psp_cursor_on ? &binds_menu[i] : &binds[i];
        if (d->act == A_TAP && (b & bmask[i]) && !(psp_cursor_on && i == B_CROSS)) { act[i] = 1; sxp[i] = d->x; syp[i] = d->y; }
        else if (d == &binds[i] && holding[i]) { act[i] = 1; sxp[i] = hold_x[i]; syp[i] = hold_y[i]; }
    }
    if (ntaps) {
        float t = now / 1e6f;
        for (int i = 0; i < ntaps; i++)
            if (t >= taps[i].t && t < taps[i].t + taps[i].dur) { act[SRC_SCRIPT] = 1; sxp[SRC_SCRIPT] = taps[i].x; syp[SRC_SCRIPT] = taps[i].y; }
    }
    /* finger 0: movement pad; the finger lands on its centre first, then slides */
    if (moving) {
        if (!joy_down) { land2port(joy_x, joy_y, &in->touch[0]); joy_down = 1; }
        else { float dx, dy; stick_movement_offset(sx, sy, joy_r, &dx, &dy);
            land2port(joy_x + dx, joy_y + dy, &in->touch[0]); }
    } else joy_down = 0;
    /* fingers 1-2: keep sources that are still active, then give free fingers to new ones */
    for (int f = 1; f <= 2; f++) if (finger_src[f] >= 0 && !act[finger_src[f]]) finger_src[f] = -1;
    for (int src = 0; src < NSRC; src++) {
        if (!act[src] || finger_src[1] == src || finger_src[2] == src) continue;
        if (finger_src[1] < 0) finger_src[1] = src; else if (finger_src[2] < 0) finger_src[2] = src;
    }
    for (int f = 1; f <= 2; f++) if (finger_src[f] >= 0) land2port(sxp[finger_src[f]], syp[finger_src[f]], &in->touch[f]);
    return PLAT_RUN;
}

/* START skips only after it has been released on entering the movie. */
static int movie_skip_ready;
void psp_movie_input_begin(void) {
    SceCtrlData pad;sceCtrlPeekBufferPositive(&pad,1);
    movie_skip_ready = !(pad.Buttons & PSP_CTRL_START);
}
int psp_movie_input_cancel(void) {
    if (quit_req) return 1;
    SceCtrlData pad;sceCtrlPeekBufferPositive(&pad,1);
    if (!(pad.Buttons & PSP_CTRL_START)) movie_skip_ready=1;
    return movie_skip_ready && !!(pad.Buttons & PSP_CTRL_START);
}
void psp_movie_input_end(void) {
    SceCtrlData pad;sceCtrlPeekBufferPositive(&pad,1);
    transition_blocked |= pad.Buttons;prev_buttons=pad.Buttons;
    a_reset++; /* discard stale pre-movie gameplay audio */
}

/* Called after the guest has stopped using audio and music. */
static void shutdown_audio(void) {
    plat_exit_trace("audio: shutdown begin");
    quit_req = 1;
#ifdef RE4_PSPLINK
    rt_log("[debug-exit] audio shutdown: begin, thread=%08x", (u32)audio_th);
#endif
    int audio_stopped = 1;
    if (audio_th >= 0) {
        SceUInt timeout = 1000000;
        int waited = sceKernelWaitThreadEnd(audio_th, &timeout);
#ifdef RE4_PSPLINK
        rt_log("[debug-exit] audio wait result=%08x", (u32)waited);
#endif
        if (waited >= 0) { plat_exit_trace("audio: thread stopped"); sceKernelDeleteThread(audio_th); }
        else { plat_exit_trace("audio: thread wait timed out or failed; resources retained"); audio_stopped = 0; rt_log("[psp] audio thread did not stop: %08x", (u32)waited); }
    }
    /* Do not free resources underneath a still-running thread. */
    if (audio_stopped) {
#ifdef RE4_PSPLINK
        rt_log("[debug-exit] before audio channel release");
#endif
        plat_exit_trace("audio: before channel release");
        if (audio_src) sceAudioSRCChRelease();
        else if (a_ch >= 0) sceAudioChRelease(a_ch);
#ifdef RE4_PSPLINK
        rt_log("[debug-exit] after audio channel release; before music_shutdown");
#endif
        plat_exit_trace("audio: before music shutdown");
        music_shutdown();
        plat_exit_trace("audio: music shutdown complete");
#ifdef RE4_PSPLINK
        rt_log("[debug-exit] after music_shutdown");
#endif
    }
    plat_exit_trace("audio: shutdown end");
    rt_log("[psp] shutdown (audio stopped: %d)", audio_stopped);
}

/* ---------- start-up */
static void set_dirs(int argc, char **argv) {
#ifndef RE4_PSPLINK
    if (argc > 0 && argv[0] && strchr(argv[0], '/')) {
        snprintf(base_dir, sizeof base_dir, "%s", argv[0]);
        *strrchr(base_dir, '/') = 0;
    }
#else
    /* PSPLINK launches the PRX from host0:, but assets and saves remain on Memory Stick. */
    (void)argc; (void)argv;
#endif
    snprintf(rt_bundle_dir, sizeof rt_bundle_dir, "%s/Res4.app", base_dir);
    snprintf(rt_docs_dir, sizeof rt_docs_dir, "%s/Documents", base_dir);
    snprintf(rt_home_dir, sizeof rt_home_dir, "%s", base_dir);
    sceIoMkdir(rt_docs_dir, 0777);
}
void plat_init(int argc, char **argv) {
    (void)argc; (void)argv;
    gl_psp_init();
}
int main(int argc, char **argv) {
    t0 = sceKernelGetSystemTimeWide();
    set_dirs(argc, argv);
    exit_trace_init();
    language_init(base_dir);
    load_config();
#ifdef RE4_PSPLINK
    /* Keep this separate from the player's normal log. Flush each line in rt_log. */
    rt_log_enabled = 1;
    char debug_log_path[300];
    snprintf(debug_log_path, sizeof debug_log_path, "%s/re4_psplink.log", base_dir);
    freopen(debug_log_path, "w", stderr);
    rt_log("[debug] PSPLINK build, resources and saves: %s", base_dir);
#else
    rt_log_enabled = !!log_to_file;
    if (log_to_file) {
        char path[300];
        snprintf(path, sizeof path, "%s/re4log.txt", base_dir);
        if (freopen(path, "w", stderr)) {
            /* stderr is normally unbuffered: resource logging otherwise causes
               multiple expensive writes per line. Static lifetime is required. */
            static char log_buffer[8192];
            setvbuf(stderr, log_buffer, _IOFBF, sizeof log_buffer);
        }
    }
#endif
    int th = sceKernelCreateThread("re4 callbacks", cb_thread, 0x11, 0x1000, PSP_THREAD_ATTR_USER, 0);
    if (th >= 0) sceKernelStartThread(th, 0, 0);
    if (cpu_mhz >= 222) scePowerSetClockFrequency(cpu_mhz, cpu_mhz, cpu_mhz / 2);
    sceCtrlSetSamplingCycle(0);
    sceCtrlSetSamplingMode(PSP_CTRL_MODE_ANALOG);
    /* Show and release the optional intro before allocating guest memory. */
    intro_show(rt_bundle_dir, &quit_req);
    if (quit_req) { plat_exit_trace("intro: exit requested"); finish_platform_exit(); return 0; }
    music_init();
    int src_status = sceAudioSRCChReserve(OUT_N, 44100, 2);
    if (src_status >= 0) {
        audio_src = 1;
        rt_log("[psp] audio output SRC 44100 Hz stereo");
    } else {
        rt_log("[psp] SRC 44100 Hz reserve failed %08x; using normal channel", (u32)src_status);
        a_ch = sceAudioChReserve(PSP_AUDIO_NEXT_CHANNEL, OUT_N, PSP_AUDIO_FORMAT_STEREO);
    }
    if (audio_src || a_ch >= 0) {
        audio_th = sceKernelCreateThread("re4 audio", audio_thread, 0x12, 0x8000, PSP_THREAD_ATTR_USER, 0);
        if (audio_th >= 0) {
            int started = sceKernelStartThread(audio_th, 0, 0);
            if (started < 0) { rt_log("[psp] audio thread start failed %08x", (u32)started); sceKernelDeleteThread(audio_th); audio_th = -1; }
        } else rt_log("[psp] audio thread creation failed %08x", (u32)audio_th);
    } else rt_log("[psp] no audio channel (%x)", a_ch);
    /* guest memory: the largest free block minus a reserve for the system */
    u32 maxfree = sceKernelMaxFreeMemSize(), reserve = (u32)mem_reserve_kb << 10;
    u32 size = maxfree > reserve + (8u << 20) ? (maxfree - reserve) & ~0xffffu : 0;
    SceUID blk = size ? sceKernelAllocPartitionMemory(2, "re4 guest", PSP_SMEM_Low, size, NULL) : -1;
    if (blk < 0) { char m[128]; snprintf(m, sizeof m, "not enough memory (%u KB free)", maxfree >> 10); plat_fatal(m); }
    MEM = sceKernelGetBlockHeadAddr(blk);
    memset(MEM, 0, size);
    if (tex_limit_pal_set) psp_tex_limit_pal = tex_limit_pal_value;
    else if (tex_limit_set) psp_tex_limit_pal = psp_tex_limit;
    else if (psp_tex_limit > 256 && size < (30u << 20)) psp_tex_limit = 256;
    rt_log("[psp] %s, guest memory %u KB (%u KB were free), texture limit %d, cpu %d MHz", base_dir, size >> 10,
           maxfree >> 10, psp_tex_limit, scePowerGetCpuClockFrequency());
#ifdef RE4_PSPLINK
    rt_log("[debug] entering guest main");
#endif
    int r = rt_main(argc, argv, size);
    plat_exit_trace("guest: main returned");
#ifdef RE4_PSPLINK
    rt_log("[debug-exit] guest main returned %d, quit=%d", r, quit_req);
#endif
    shutdown_audio();
#ifdef RE4_PSPLINK
    rt_log("[debug-exit] before gl_psp_shutdown");
#endif
    plat_exit_trace("graphics: before shutdown");
    gl_psp_shutdown(); /* finish and release the active GU list */
    plat_exit_trace("graphics: shutdown complete");
#ifdef RE4_PSPLINK
    rt_log("[debug-exit] after gl_psp_shutdown; calling sceKernelExitGame");
#endif
    if (log_to_file) fflush(stderr);
    finish_platform_exit();
    return r;
}
