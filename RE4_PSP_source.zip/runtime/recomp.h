/* Helpers for C generated from ARMv6 code (RE4 Mobile Edition recompiler). */
#ifndef RECOMP_H
#define RECOMP_H
#include <stdint.h>
#include <string.h>
#include <math.h>
typedef uint8_t u8; typedef uint16_t u16; typedef uint32_t u32; typedef uint64_t u64;
typedef int8_t s8; typedef int16_t s16; typedef int32_t s32; typedef int64_t s64;
typedef u64 (*rc_fn)(u32, u32, u32, u32, u32);

#ifdef RC_RUNTIME
extern u8 *MEM;            /* guest address 0 in host memory */
#else
extern u8 *const MEM;      /* constant for generated code: lets the compiler keep it in a register */
#endif

#define LR_MAGIC 0xfffffff0u   /* "return to caller" pseudo-address held in lr */
#define RV(a, b) (((u64)(u32)(b) << 32) | (u32)(a))
#define INL static inline __attribute__((always_inline))

#ifdef RC_TRACE
void rc_trace_enter(u32 addr);
#define RC_ENTER(a) rc_trace_enter(a)
#else
#define RC_ENTER(a) ((void)0)
#endif

/* memory: unaligned-safe by default; "A" variants are for sp-relative and LDM/STM (word aligned) */
INL u32 RD32(u32 a) { u32 v; memcpy(&v, MEM + a, 4); return v; }
INL u32 RD32A(u32 a) { return *(u32 *)(MEM + a); }
#ifdef RC_ALIGNED16
INL u32 RD16(u32 a) { return *(u16 *)(MEM + a); }
INL u32 RDS16(u32 a) { return (u32)(s32)*(s16 *)(MEM + a); }
INL void WR16(u32 a, u32 v) { *(u16 *)(MEM + a) = (u16)v; }
#else
INL u32 RD16(u32 a) { u16 v; memcpy(&v, MEM + a, 2); return v; }
INL u32 RDS16(u32 a) { s16 v; memcpy(&v, MEM + a, 2); return (u32)(s32)v; }
INL void WR16(u32 a, u32 v) { u16 x = (u16)v; memcpy(MEM + a, &x, 2); }
#endif
INL u32 RD8(u32 a) { return MEM[a]; }
INL u32 RDS8(u32 a) { return (u32)(s32)(s8)MEM[a]; }
INL void WR32(u32 a, u32 v) { memcpy(MEM + a, &v, 4); }
INL void WR32A(u32 a, u32 v) { *(u32 *)(MEM + a) = v; }
INL void WR8(u32 a, u32 v) { MEM[a] = (u8)v; }
INL float RDF(u32 a) { float f; memcpy(&f, MEM + a, 4); return f; }
INL void WRF(u32 a, float f) { memcpy(MEM + a, &f, 4); }
INL double RDD(u32 a) { double f; memcpy(&f, MEM + a, 8); return f; }
INL void WRD(u32 a, double f) { memcpy(MEM + a, &f, 8); }

/* bit casts */
INL float U2F(u32 u) { float f; memcpy(&f, &u, 4); return f; }
INL u32 F2U(float f) { u32 u; memcpy(&u, &f, 4); return u; }
INL double U2D(u64 u) { double f; memcpy(&f, &u, 8); return f; }
INL u64 D2U(double f) { u64 u; memcpy(&u, &f, 8); return u; }
INL u32 DLO(double f) { return (u32)D2U(f); }
INL u32 DHI(double f) { return (u32)(D2U(f) >> 32); }
INL double DSETLO(double f, u32 v) { return U2D((D2U(f) & 0xffffffff00000000ull) | v); }
INL double DSETHI(double f, u32 v) { return U2D((D2U(f) & 0xffffffffull) | ((u64)v << 32)); }

/* shifts (immediate ror: n in 1..31) and register-specified shifts with carry-out */
INL u32 ROR(u32 x, u32 n) { return (x >> n) | (x << ((32 - n) & 31)); }
INL u32 LSL_R(u32 x, u32 s) { s &= 0xff; return s >= 32 ? 0 : x << s; }
INL u32 LSR_R(u32 x, u32 s) { s &= 0xff; return s >= 32 ? 0 : x >> s; }
INL u32 ASR_R(u32 x, u32 s) { s &= 0xff; return (u32)((s32)x >> (s >= 32 ? 31 : s)); }
INL u32 ROR_R(u32 x, u32 s) { s &= 31; return s ? (x >> s) | (x << (32 - s)) : x; }
INL u32 LSL_C(u32 x, u32 s, u32 c) { s &= 0xff; return s == 0 ? c : s < 32 ? (x >> (32 - s)) & 1 : s == 32 ? (x & 1) : 0; }
INL u32 LSR_C(u32 x, u32 s, u32 c) { s &= 0xff; return s == 0 ? c : s < 32 ? (x >> (s - 1)) & 1 : s == 32 ? (x >> 31) : 0; }
INL u32 ASR_C(u32 x, u32 s, u32 c) { s &= 0xff; return s == 0 ? c : s < 32 ? (x >> (s - 1)) & 1 : (x >> 31); }
INL u32 ROR_C(u32 x, u32 s, u32 c) { if ((s & 0xff) == 0) return c; s &= 31; return s == 0 ? (x >> 31) : (x >> (s - 1)) & 1; }
#define SUB_V(a, b) ((((a) ^ (b)) & ((a) ^ (u32)((a) - (b)))) >> 31)
#define ADD_V(a, b) ((~((a) ^ (b)) & ((a) ^ (u32)((a) + (b)))) >> 31)
#define UNORD(x, y) ((x) != (x) || (y) != (y))
INL u32 BSWAP32(u32 x) { return (x >> 24) | ((x >> 8) & 0xff00) | ((x << 8) & 0xff0000) | (x << 24); }
INL u32 CLZ32(u32 x) { return x ? (u32)__builtin_clz(x) : 32; }

/* VFP float->int conversions with ARM saturation semantics */
INL s32 F2S32(float f) { if (f != f) return 0; if (f >= 2147483648.0f) return 0x7fffffff; if (f <= -2147483648.0f) return (s32)0x80000000; return (s32)f; }
INL u32 F2U32(float f) { if (!(f > 0.0f)) return 0; if (f >= 4294967296.0f) return 0xffffffffu; return (u32)f; }
INL s32 D2S32(double f) { if (f != f) return 0; if (f >= 2147483648.0) return 0x7fffffff; if (f <= -2147483648.0) return (s32)0x80000000; return (s32)f; }
INL u32 D2U32(double f) { if (!(f > 0.0)) return 0; if (f >= 4294967296.0) return 0xffffffffu; return (u32)f; }
INL s32 F2S32_RN(float f) { return F2S32(rintf(f)); }
INL u32 F2U32_RN(float f) { return F2U32(rintf(f)); }
INL s32 D2S32_RN(double f) { return D2S32(rint(f)); }
INL u32 D2U32_RN(double f) { return D2U32(rint(f)); }

/* runtime entry points */
u64 rc_icall(u32 target, u32 r0, u32 r1, u32 r2, u32 r3, u32 sp);
u64 rc_unimpl(u32 addr);
void rc_textboard_grow(u32 tb);   /* rt_heap.c: grows an rcx::font::TextBoard (see gen.py PATCHES) */
#define RC_ICALL rc_icall
#endif
