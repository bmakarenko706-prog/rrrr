#ifndef RE4_PSP_INTRO_H
#define RE4_PSP_INTRO_H
void intro_show(const char *bundle_dir, const volatile int *quit_req);
#endif
