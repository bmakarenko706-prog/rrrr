#!/usr/bin/env python3
"""Add eight Ukrainian glyphs to an existing IFNT v2 font without changing other glyphs."""
import math, struct, sys
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

if len(sys.argv) != 4:
    sys.exit('usage: add_ukrainian_to_font.py input.fnt LiberationSans-Bold.ttf output.fnt')
src, ttf, output = map(Path, sys.argv[1:])
if src.resolve() == output.resolve():
    sys.exit('Input and output must be different files')
d = src.read_bytes()
if len(d) < 0x488 or d[:4] != b'IFNT' or struct.unpack_from('<I', d, 4)[0] != 2:
    sys.exit('Not an IFNT v2 font')
n = struct.unpack_from('<I', d, 0x474)[0]
p = 0x478 + 8*n
if n > 65535 or p+16 > len(d):
    sys.exit('Invalid glyph table')
records = [struct.unpack_from('<HBBHH', d, 0x478+8*i) for i in range(n)]
w, h = struct.unpack_from('<II', d, p+8)
if w != 512 or h % 25 or h > 512 or p+16+w*h != len(d):
    sys.exit('Unexpected atlas dimensions or font length')
if len({r[0] for r in records}) != n:
    sys.exit('Duplicate codepoints in input font')
chars = [c for c in 'ЄєІіЇїҐґ' if ord(c) not in {r[0] for r in records}]
img = Image.frombytes('L', (w,h), d[p+16:])
occupied = {(r[3],r[4]) for r in records}
free = []
# Use empty cells only in Cyrillic/ASCII rows, preserving the original atlas.
for row in range(9,h//25):
    for col in range(19):
        if (col,row) not in occupied and not img.crop((col*26,row*25,col*26+26,row*25+25)).getbbox():
            free.append((col,row))
if len(free) < len(chars):
    sys.exit('Not enough empty atlas cells; original font was not changed')
font = ImageFont.truetype(str(ttf),19)
added = []
for c,(col,row) in zip(chars,free):
    bbox = font.getbbox(c); left = min(0,bbox[0])
    glyphw = max(1, math.ceil(font.getlength(c)), bbox[2]-left)
    if glyphw>24 or bbox[1]+2<0 or bbox[3]+2>25:
        sys.exit(f'Glyph does not fit a cell: {c} {bbox}')
    glyph = Image.new('L',(glyphw,25))
    ImageDraw.Draw(glyph).text((-left,2),c,fill=255,font=font)
    target = max(1,round(glyphw*0.84))
    glyph = glyph.resize((target,25),Image.Resampling.LANCZOS)
    xoff = (26-target)//2
    img.paste(glyph,(col*26+xoff,row*25))
    records.append((ord(c),xoff,target,col,row)); added.append(c)
records.sort(key=lambda r:r[0])
out = d[:0x474]+struct.pack('<I',len(records))+b''.join(struct.pack('<HBBHH',*r) for r in records)+d[p:p+16]+img.tobytes()
output.write_bytes(out)
print('Added:', ''.join(added) or '(already present)', '| glyphs:',len(records),'| atlas:',w,'x',h)
