#!/usr/bin/env python3
"""Replace ASCII and add Cyrillic in an IFNT font for PSP. Requires Pillow."""
import math, struct, sys
from PIL import Image, ImageDraw, ImageFont
if len(sys.argv)!=4: sys.exit('usage: make_ru_font.py eu_font_U16le.fnt cyrillic.ttf ru_font_U16le.fnt')
d=open(sys.argv[1],'rb').read(); assert d[:4]==b'IFNT' and struct.unpack_from('<I',d,4)[0]==2
n=struct.unpack_from('<I',d,0x474)[0]; start=0x478
records=[struct.unpack_from('<HBBHH',d,start+8*i) for i in range(n)]
p=start+8*n; alt=d[p:p+8]; w,h=struct.unpack_from('<II',d,p+8)
assert (w,h)==(512,225) and max(r[4] for r in records)==8
font=ImageFont.truetype(sys.argv[2],19)
chars='Ёё«»—'+''.join(chr(i) for i in range(0x410,0x450))+''.join(chr(i) for i in range(0x21,0x7f))+'ЄєІіЇїҐґ'
assert len(chars)==len(set(chars))
newh=(9+math.ceil(len(chars)/19))*25
img=Image.frombytes('L',(w,h),d[p+16:]); atlas=Image.new('L',(w,newh));atlas.paste(img,(0,0)); draw=ImageDraw.Draw(atlas)
records=[r for r in records if r[0] not in set(map(ord,chars))]
for i,c in enumerate(chars):
    col=i%19; row=9+i//19
    bbox=font.getbbox(c); left=min(0,bbox[0]); glyphw=max(1, math.ceil(font.getlength(c)), bbox[2]-left)
    assert glyphw<=24 and bbox[1]+2>=0 and bbox[3]+2<=25,(c,bbox,glyphw)
    # Condense glyphs horizontally while keeping their 19px height and bold strokes.
    # This fits longer Russian words without reducing vertical legibility on PSP.
    glyph=Image.new('L',(glyphw,25)); ImageDraw.Draw(glyph).text((-left,2),c,fill=255,font=font)
    target=max(1,round(glyphw*0.84))
    glyph=glyph.resize((target,25),Image.Resampling.LANCZOS)
    xoff=(26-target)//2
    atlas.paste(glyph,(col*26+xoff,row*25))
    records.append((ord(c),xoff,target,col,row))
records.sort(key=lambda x:x[0])
out=d[:0x474]+struct.pack('<I',len(records))+b''.join(struct.pack('<HBBHH',*r) for r in records)+alt+struct.pack('<II',w,newh)+atlas.tobytes()
open(sys.argv[3],'wb').write(out);print('wrote',sys.argv[3],len(records),'glyphs, atlas',w,'x',newh)
