from PIL import Image,ImageDraw,ImageFont
from pathlib import Path
from fontTools.ttLib import TTFont
path='/usr/share/fonts/liberation-sans/LiberationSans-Bold.ttf'
font=ImageFont.truetype(path,15,layout_engine=ImageFont.Layout.BASIC)
cmap=TTFont(path).getBestCmap()
cps=list(range(32,592))+list(range(1024,1328))+[0x2013,0x2014,0x2018,0x2019,0x201c,0x201d,0x2026,0x2116]
with open('runtime/manual_font.h','w') as out:
 out.write('/* Bitmap glyphs, generated from Liberation Sans Bold 15. */\n')
 out.write('static const struct manual_glyph { unsigned short cp; unsigned char advance; unsigned char bits[40]; } manual_glyphs[] = {\n')
 for cp in cps:
  if cp not in cmap or (127 <= cp < 160): continue
  c=chr(cp); image=Image.new('1',(16,20));d=ImageDraw.Draw(image);d.text((0,0),c,font=font,fill=1,stroke_width=0)
  pixels=image.load();b=[]
  for y in range(20):
   for x0 in (0,8):
    v=sum((128>>k) for k in range(8) if pixels[x0+k,y]);b.append(v)
  adv=max(3,min(16,round(font.getlength(c))))
  out.write('{%d,%d,{%s}},\n'%(cp,adv,','.join(map(str,b))))
 out.write('};\n')
