#!/usr/bin/env python3
"""Regenerate compiled fallback text from editable files without changing them."""
from pathlib import Path
root = Path(__file__).resolve().parents[2]
langs = ('ru', 'en', 'fr', 'de', 'it', 'es')
with (root / 'runtime/manual_text.h').open('w') as o:
    o.write('/* Generated from localization/manual text files; fallback when external file is absent. */\n')
    for lang in langs:
        b = (root / 'localization/manual' / (lang + '.txt')).read_bytes()
        o.write(f'static const char manual_{lang}[] =\n')
        for start in range(0, len(b), 24):
            o.write('"' + ''.join('\\%03o' % v for v in b[start:start+24]) + '"\n')
        o.write(';\n')
