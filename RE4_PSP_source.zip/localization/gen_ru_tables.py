#!/usr/bin/env python3
"""Generate the UTF-16 C headers after editing the JSON translation files."""
import json,struct
from pathlib import Path
here=Path(__file__).resolve().parent; out=here.parent/'runtime'
def units(text):
 b=text.encode('utf-16le'); return ','.join('0x%04x'%x for x in struct.unpack('<'+'H'*(len(b)//2),b))
entries=json.loads((here/'ru_menu_draft.json').read_text(encoding='utf-8'))['entries']
h=['/* Russian menu translation, UTF-16LE code units. */']
for e in entries: h.append('static const u16 ru_%d[] = {%s,0};'%(e['id'],units(e['russian_draft'])))
h.append('static const struct { u16 id; const u16 *text; } ru_table[] = {')
h.extend('    {%d, ru_%d},'%(e['id'],e['id']) for e in entries); h.append('};')
(out/'ru_strings.h').write_text('\n'.join(h)+'\n',encoding='utf-8')
m=json.loads((here/'ru_missions.json').read_text(encoding='utf-8'))
h=['/* Russian mission names and descriptions, UTF-16. */']
for kind,vals in [('name',m['names']),('info',m['descriptions'])]:
 assert len(vals)==36
 for i,s in enumerate(vals): h.append('static const u16 ru_%s_%d[] = {%s,0};'%(kind,i,units(s)))
 h.append('static const u16 *const ru_%s_table[] = {%s};'%(kind,','.join('ru_%s_%d'%(kind,i) for i in range(36))))
(out/'ru_missions.h').write_text('\n'.join(h)+'\n',encoding='utf-8')

x=json.loads((here/'ru_extra.json').read_text(encoding='utf-8'))
h=['/* Russian item, location, and document strings. */']
for kind in ['stage','item_name','item_info','file']:
 vals=x[kind]
 for key,text in vals.items(): h.append('static const u16 ru_extra_%s_%s[] = {%s,0};'%(kind,key,units(text)))
 h.append('static const struct { u16 id; const u16 *text; } ru_extra_%s[] = {'%kind)
 for key in sorted(vals,key=int): h.append('    {%s, ru_extra_%s_%s},'%(key,kind,key))
 h.append('};')
(out/'ru_extra.h').write_text('\n'.join(h)+'\n',encoding='utf-8')

story=json.loads((here/'ru_story.json').read_text(encoding='utf-8'))
def h32(text):
 h=2166136261
 for c in text: h=((h^ord(c))*16777619)&0xffffffff
 return h
items=sorted(story.items(),key=lambda x:h32(x[0]))
h=['/* Exact UTF-16 English -> Russian story strings, sorted by FNV-1a. */']
for i,(en,ru) in enumerate(items):
 h.append('static const u16 ru_story_en_%d[] = {%s,0};'%(i,units(en)))
 h.append('static const u16 ru_story_ru_%d[] = {%s,0};'%(i,units(ru)))
h.append('static const struct { u32 hash; const u16 *en; const u16 *ru; } ru_story[] = {')
for i,(en,_) in enumerate(items): h.append('    {0x%08xu,ru_story_en_%d,ru_story_ru_%d},'%(h32(en),i,i))
h.append('};')
(out/'ru_story.h').write_text('\n'.join(h)+'\n',encoding='utf-8')
