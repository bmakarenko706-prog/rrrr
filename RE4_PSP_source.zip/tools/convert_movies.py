#!/usr/bin/env python3
"""Convert supplied original cutscenes to streamed PSP frames and MP3.
Usage: python3 tools/convert_movies.py INPUT_DIRECTORY OUTPUT_DIRECTORY
Requires ffmpeg, ffprobe. Does not modify source .m4v files.
"""
from pathlib import Path
import subprocess, tempfile, struct, sys, json
NAMES=('bio4','buki','kuro','res4')
FPS=20
MAX_FRAME=262144
def run(cmd):subprocess.run(cmd,check=True,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
def convert(src,out):
 out.mkdir(parents=True,exist_ok=True)
 for name in NAMES:
  movie=src/(name+'.m4v')
  if not movie.exists(): print('Missing:',movie);continue
  meta=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries','stream=codec_type','-of','json',str(movie)]))
  with tempfile.TemporaryDirectory() as td:
   pattern=str(Path(td)/'%06d.jpg')
   run(['ffmpeg','-nostdin','-v','error','-i',str(movie),'-map','0:v:0','-vf',f'fps={FPS},scale=480:272,setsar=1','-c:v','mjpeg','-pix_fmt','yuvj420p','-q:v','6','-threads','1',pattern])
   frames=sorted(Path(td).glob('*.jpg'))
   if not frames:raise RuntimeError(f'{name}: no frames')
   mx=max(f.stat().st_size for f in frames)
   if mx>MAX_FRAME:raise RuntimeError(f'{name}: JPEG frame exceeds {MAX_FRAME}: {mx}')
   with (out/(name+'.r4v')).open('wb') as f:
    f.write(struct.pack('<8s6I',b'RE4MV01\0',480,272,FPS,1,len(frames),mx))
    for frame in frames:
     data=frame.read_bytes();f.write(struct.pack('<I',len(data)));f.write(data)
  aud=out/(name+'.mp3')
  if any(s['codec_type']=='audio' for s in meta['streams']):
   run(['ffmpeg','-nostdin','-v','error','-i',str(movie),'-map','0:a:0','-vn','-ac','2','-ar','44100','-c:a','libmp3lame','-b:a','128k','-y',str(aud)])
  elif aud.exists():aud.unlink()
  print(name,'frames',len(frames),'max JPEG',mx,'video bytes',(out/(name+'.r4v')).stat().st_size,'audio',aud.exists(),flush=True)
if __name__=='__main__':
 if len(sys.argv)!=3:raise SystemExit(__doc__)
 convert(Path(sys.argv[1]),Path(sys.argv[2]))
