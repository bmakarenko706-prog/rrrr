#!/usr/bin/env python3
"""Convert any image to the encrypted RE4 PSP intro asset. Requires Pillow.
Usage: python3 tools/encode_intro.py image.jpg assets/mis_data_m25.bin
The compiled key is public: this hides the asset, it does not provide secrecy.
"""
from PIL import Image, ImageOps
import os, struct, sys, zlib
from pathlib import Path
KEY=bytes.fromhex('d38c21645a94b7e01f439b3570226cf1802dbb7ac350169e0fa14bd76992553e')
MASK=0xffffffff
def rot(v,n):return ((v<<n)|(v>>(32-n)))&MASK
def crypt(data,nonce):
 s=list(struct.unpack('<4I',b'expand 32-byte k'))+list(struct.unpack('<8I',KEY))+[0,0]+list(struct.unpack('<2I',nonce));out=bytearray(data)
 def qr(x,a,b,c,d):
  x[a]=(x[a]+x[b])&MASK;x[d]=rot(x[d]^x[a],16);x[c]=(x[c]+x[d])&MASK;x[b]=rot(x[b]^x[c],12)
  x[a]=(x[a]+x[b])&MASK;x[d]=rot(x[d]^x[a],8);x[c]=(x[c]+x[d])&MASK;x[b]=rot(x[b]^x[c],7)
 for off in range(0,len(out),64):
  x=s.copy()
  for _ in range(10):
   for q in ((0,4,8,12),(1,5,9,13),(2,6,10,14),(3,7,11,15),(0,5,10,15),(1,6,11,12),(2,7,8,13),(3,4,9,14)):qr(x,*q)
  stream=struct.pack('<16I',*((x[i]+s[i])&MASK for i in range(16)))
  for i in range(min(64,len(out)-off)):out[off+i]^=stream[i]
  s[12]=(s[12]+1)&MASK
  if not s[12]:s[13]=(s[13]+1)&MASK
 return bytes(out)
def encode(src,dst):
 img=ImageOps.exif_transpose(Image.open(src)).convert('RGB')
 scaled=ImageOps.contain(img,(480,272),Image.Resampling.LANCZOS)
 canvas=Image.new('RGB',(480,272));canvas.paste(scaled,((480-scaled.width)//2,(272-scaled.height)//2))
 raw=bytearray()
 for r,g,b in canvas.getdata():raw.extend(struct.pack('<H',(r>>3)|((g>>2)<<5)|((b>>3)<<11)))
 nonce=os.urandom(8); payload=struct.pack('<I',zlib.crc32(raw))+raw
 Path(dst).write_bytes(nonce+crypt(payload,nonce))
if __name__=='__main__':
 if len(sys.argv)!=3:raise SystemExit(__doc__)
 encode(sys.argv[1],sys.argv[2])
