#!/usr/bin/env python3
"""Build optional startup pack from original game files; no originals modified."""
from pathlib import Path
import argparse,struct
p=argparse.ArgumentParser();p.add_argument('bundle',type=Path);p.add_argument('output',type=Path);p.add_argument('--list',type=Path,default=Path(__file__).resolve().parents[1]/'assets/startup_pack_files.txt');a=p.parse_args()
names=[x.strip() for x in a.list.read_text(encoding='utf8').splitlines() if x.strip() and not x.startswith('#')]
if len(names)>128 or len(set(names))!=len(names):raise ValueError('invalid entry count or duplicate')
files=[]; offset=8+108*len(names)
for name in names:
 if '/' in name or '\\' in name or len(name.encode())>=96 or name in ('.','..'):raise ValueError(name)
 file=a.bundle/name; st=file.stat();data=file.read_bytes();
 if len(data)!=st.st_size or not 0<=int(st.st_mtime)<2**32:raise ValueError(name)
 files.append((name.encode().ljust(96,b'\0'),offset,len(data),int(st.st_mtime),data));offset+=len(data)
with a.output.open('wb') as f:
 f.write(struct.pack('<4sI',b'R4P1',len(files)))
 for name,off,size,mtime,data in files:f.write(struct.pack('<96sIII',name,off,size,mtime))
 for _,_,_,_,data in files:f.write(data)
print(f'{len(files)} files, {offset} bytes: {a.output}')
